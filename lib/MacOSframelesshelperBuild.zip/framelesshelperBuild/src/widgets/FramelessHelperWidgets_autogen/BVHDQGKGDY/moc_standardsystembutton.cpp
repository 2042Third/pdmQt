/****************************************************************************
** Meta object code from reading C++ file 'standardsystembutton.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../framelesshelper/include/FramelessHelper/Widgets/standardsystembutton.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'standardsystembutton.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardSystemButtonENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardSystemButtonENDCLASS = QtMocHelpers::stringData(
    "wangwenx190::FramelessHelper::StandardSystemButton",
    "buttonTypeChanged",
    "",
    "glyphChanged",
    "hoveredChanged",
    "pressedChanged",
    "hoverColorChanged",
    "pressColorChanged",
    "normalColorChanged",
    "activeForegroundColorChanged",
    "inactiveForegroundColorChanged",
    "activeChanged",
    "iconSize2Changed",
    "setButtonType",
    "Global::SystemButtonType",
    "value",
    "setGlyph",
    "glyph",
    "setHovered",
    "setPressed",
    "setHoverColor",
    "setPressColor",
    "setNormalColor",
    "setActiveForegroundColor",
    "setInactiveForegroundColor",
    "setActive",
    "setIconSize2",
    "buttonType",
    "hovered",
    "pressed",
    "hoverColor",
    "pressColor",
    "normalColor",
    "activeForegroundColor",
    "inactiveForegroundColor",
    "active",
    "iconSize2"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardSystemButtonENDCLASS_t {
    uint offsetsAndSizes[74];
    char stringdata0[51];
    char stringdata1[18];
    char stringdata2[1];
    char stringdata3[13];
    char stringdata4[15];
    char stringdata5[15];
    char stringdata6[18];
    char stringdata7[18];
    char stringdata8[19];
    char stringdata9[29];
    char stringdata10[31];
    char stringdata11[14];
    char stringdata12[17];
    char stringdata13[14];
    char stringdata14[25];
    char stringdata15[6];
    char stringdata16[9];
    char stringdata17[6];
    char stringdata18[11];
    char stringdata19[11];
    char stringdata20[14];
    char stringdata21[14];
    char stringdata22[15];
    char stringdata23[25];
    char stringdata24[27];
    char stringdata25[10];
    char stringdata26[13];
    char stringdata27[11];
    char stringdata28[8];
    char stringdata29[8];
    char stringdata30[11];
    char stringdata31[11];
    char stringdata32[12];
    char stringdata33[22];
    char stringdata34[24];
    char stringdata35[7];
    char stringdata36[10];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardSystemButtonENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardSystemButtonENDCLASS_t qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardSystemButtonENDCLASS = {
    {
        QT_MOC_LITERAL(0, 50),  // "wangwenx190::FramelessHelper:..."
        QT_MOC_LITERAL(51, 17),  // "buttonTypeChanged"
        QT_MOC_LITERAL(69, 0),  // ""
        QT_MOC_LITERAL(70, 12),  // "glyphChanged"
        QT_MOC_LITERAL(83, 14),  // "hoveredChanged"
        QT_MOC_LITERAL(98, 14),  // "pressedChanged"
        QT_MOC_LITERAL(113, 17),  // "hoverColorChanged"
        QT_MOC_LITERAL(131, 17),  // "pressColorChanged"
        QT_MOC_LITERAL(149, 18),  // "normalColorChanged"
        QT_MOC_LITERAL(168, 28),  // "activeForegroundColorChanged"
        QT_MOC_LITERAL(197, 30),  // "inactiveForegroundColorChanged"
        QT_MOC_LITERAL(228, 13),  // "activeChanged"
        QT_MOC_LITERAL(242, 16),  // "iconSize2Changed"
        QT_MOC_LITERAL(259, 13),  // "setButtonType"
        QT_MOC_LITERAL(273, 24),  // "Global::SystemButtonType"
        QT_MOC_LITERAL(298, 5),  // "value"
        QT_MOC_LITERAL(304, 8),  // "setGlyph"
        QT_MOC_LITERAL(313, 5),  // "glyph"
        QT_MOC_LITERAL(319, 10),  // "setHovered"
        QT_MOC_LITERAL(330, 10),  // "setPressed"
        QT_MOC_LITERAL(341, 13),  // "setHoverColor"
        QT_MOC_LITERAL(355, 13),  // "setPressColor"
        QT_MOC_LITERAL(369, 14),  // "setNormalColor"
        QT_MOC_LITERAL(384, 24),  // "setActiveForegroundColor"
        QT_MOC_LITERAL(409, 26),  // "setInactiveForegroundColor"
        QT_MOC_LITERAL(436, 9),  // "setActive"
        QT_MOC_LITERAL(446, 12),  // "setIconSize2"
        QT_MOC_LITERAL(459, 10),  // "buttonType"
        QT_MOC_LITERAL(470, 7),  // "hovered"
        QT_MOC_LITERAL(478, 7),  // "pressed"
        QT_MOC_LITERAL(486, 10),  // "hoverColor"
        QT_MOC_LITERAL(497, 10),  // "pressColor"
        QT_MOC_LITERAL(508, 11),  // "normalColor"
        QT_MOC_LITERAL(520, 21),  // "activeForegroundColor"
        QT_MOC_LITERAL(542, 23),  // "inactiveForegroundColor"
        QT_MOC_LITERAL(566, 6),  // "active"
        QT_MOC_LITERAL(573, 9)   // "iconSize2"
    },
    "wangwenx190::FramelessHelper::StandardSystemButton",
    "buttonTypeChanged",
    "",
    "glyphChanged",
    "hoveredChanged",
    "pressedChanged",
    "hoverColorChanged",
    "pressColorChanged",
    "normalColorChanged",
    "activeForegroundColorChanged",
    "inactiveForegroundColorChanged",
    "activeChanged",
    "iconSize2Changed",
    "setButtonType",
    "Global::SystemButtonType",
    "value",
    "setGlyph",
    "glyph",
    "setHovered",
    "setPressed",
    "setHoverColor",
    "setPressColor",
    "setNormalColor",
    "setActiveForegroundColor",
    "setInactiveForegroundColor",
    "setActive",
    "setIconSize2",
    "buttonType",
    "hovered",
    "pressed",
    "hoverColor",
    "pressColor",
    "normalColor",
    "activeForegroundColor",
    "inactiveForegroundColor",
    "active",
    "iconSize2"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardSystemButtonENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      22,   14, // methods
      11,  190, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      11,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  146,    2, 0x06,   12 /* Public */,
       3,    0,  147,    2, 0x06,   13 /* Public */,
       4,    0,  148,    2, 0x06,   14 /* Public */,
       5,    0,  149,    2, 0x06,   15 /* Public */,
       6,    0,  150,    2, 0x06,   16 /* Public */,
       7,    0,  151,    2, 0x06,   17 /* Public */,
       8,    0,  152,    2, 0x06,   18 /* Public */,
       9,    0,  153,    2, 0x06,   19 /* Public */,
      10,    0,  154,    2, 0x06,   20 /* Public */,
      11,    0,  155,    2, 0x06,   21 /* Public */,
      12,    0,  156,    2, 0x06,   22 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      13,    1,  157,    2, 0x0a,   23 /* Public */,
      16,    1,  160,    2, 0x0a,   25 /* Public */,
      18,    1,  163,    2, 0x0a,   27 /* Public */,
      19,    1,  166,    2, 0x0a,   29 /* Public */,
      20,    1,  169,    2, 0x0a,   31 /* Public */,
      21,    1,  172,    2, 0x0a,   33 /* Public */,
      22,    1,  175,    2, 0x0a,   35 /* Public */,
      23,    1,  178,    2, 0x0a,   37 /* Public */,
      24,    1,  181,    2, 0x0a,   39 /* Public */,
      25,    1,  184,    2, 0x0a,   41 /* Public */,
      26,    1,  187,    2, 0x0a,   43 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 14,   15,
    QMetaType::Void, QMetaType::QString,   17,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void, QMetaType::QColor,   15,
    QMetaType::Void, QMetaType::QColor,   15,
    QMetaType::Void, QMetaType::QColor,   15,
    QMetaType::Void, QMetaType::QColor,   15,
    QMetaType::Void, QMetaType::QColor,   15,
    QMetaType::Void, QMetaType::Bool,   15,
    QMetaType::Void, QMetaType::Int,   15,

 // properties: name, type, flags
      27, 0x80000000 | 14, 0x0001590b, uint(0), 0,
      17, QMetaType::QString, 0x00015903, uint(1), 0,
      28, QMetaType::Bool, 0x00015903, uint(2), 0,
      29, QMetaType::Bool, 0x00015903, uint(3), 0,
      30, QMetaType::QColor, 0x00015903, uint(4), 0,
      31, QMetaType::QColor, 0x00015903, uint(5), 0,
      32, QMetaType::QColor, 0x00015903, uint(6), 0,
      33, QMetaType::QColor, 0x00015903, uint(7), 0,
      34, QMetaType::QColor, 0x00015903, uint(8), 0,
      35, QMetaType::Bool, 0x00015903, uint(9), 0,
      36, QMetaType::Int, 0x00015903, uint(10), 0,

       0        // eod
};

Q_CONSTINIT static const QMetaObject::SuperData qt_meta_extradata_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardSystemButtonENDCLASS[] = {
    QMetaObject::SuperData::link<wangwenx190::FramelessHelper::Global::staticMetaObject>(),
    nullptr
};

Q_CONSTINIT const QMetaObject wangwenx190::FramelessHelper::StandardSystemButton::staticMetaObject = { {
    QMetaObject::SuperData::link<QAbstractButton::staticMetaObject>(),
    qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardSystemButtonENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardSystemButtonENDCLASS,
    qt_static_metacall,
    qt_meta_extradata_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardSystemButtonENDCLASS,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardSystemButtonENDCLASS_t,
        // property 'buttonType'
        QtPrivate::TypeAndForceComplete<Global::SystemButtonType, std::true_type>,
        // property 'glyph'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'hovered'
        QtPrivate::TypeAndForceComplete<bool, std::true_type>,
        // property 'pressed'
        QtPrivate::TypeAndForceComplete<bool, std::true_type>,
        // property 'hoverColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'pressColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'normalColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'activeForegroundColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'inactiveForegroundColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'active'
        QtPrivate::TypeAndForceComplete<bool, std::true_type>,
        // property 'iconSize2'
        QtPrivate::TypeAndForceComplete<int, std::true_type>,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<StandardSystemButton, std::true_type>,
        // method 'buttonTypeChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'glyphChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'hoveredChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'pressedChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'hoverColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'pressColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'normalColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'activeForegroundColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'inactiveForegroundColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'activeChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'iconSize2Changed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setButtonType'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const Global::SystemButtonType, std::false_type>,
        // method 'setGlyph'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QString &, std::false_type>,
        // method 'setHovered'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const bool, std::false_type>,
        // method 'setPressed'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const bool, std::false_type>,
        // method 'setHoverColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QColor &, std::false_type>,
        // method 'setPressColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QColor &, std::false_type>,
        // method 'setNormalColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QColor &, std::false_type>,
        // method 'setActiveForegroundColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QColor &, std::false_type>,
        // method 'setInactiveForegroundColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QColor &, std::false_type>,
        // method 'setActive'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const bool, std::false_type>,
        // method 'setIconSize2'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const int, std::false_type>
    >,
    nullptr
} };

void wangwenx190::FramelessHelper::StandardSystemButton::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<StandardSystemButton *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->buttonTypeChanged(); break;
        case 1: _t->glyphChanged(); break;
        case 2: _t->hoveredChanged(); break;
        case 3: _t->pressedChanged(); break;
        case 4: _t->hoverColorChanged(); break;
        case 5: _t->pressColorChanged(); break;
        case 6: _t->normalColorChanged(); break;
        case 7: _t->activeForegroundColorChanged(); break;
        case 8: _t->inactiveForegroundColorChanged(); break;
        case 9: _t->activeChanged(); break;
        case 10: _t->iconSize2Changed(); break;
        case 11: _t->setButtonType((*reinterpret_cast< std::add_pointer_t<Global::SystemButtonType>>(_a[1]))); break;
        case 12: _t->setGlyph((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 13: _t->setHovered((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 14: _t->setPressed((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 15: _t->setHoverColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 16: _t->setPressColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 17: _t->setNormalColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 18: _t->setActiveForegroundColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 19: _t->setInactiveForegroundColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 20: _t->setActive((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 21: _t->setIconSize2((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (StandardSystemButton::*)();
            if (_t _q_method = &StandardSystemButton::buttonTypeChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (StandardSystemButton::*)();
            if (_t _q_method = &StandardSystemButton::glyphChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (StandardSystemButton::*)();
            if (_t _q_method = &StandardSystemButton::hoveredChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (StandardSystemButton::*)();
            if (_t _q_method = &StandardSystemButton::pressedChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (StandardSystemButton::*)();
            if (_t _q_method = &StandardSystemButton::hoverColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (StandardSystemButton::*)();
            if (_t _q_method = &StandardSystemButton::pressColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (StandardSystemButton::*)();
            if (_t _q_method = &StandardSystemButton::normalColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (StandardSystemButton::*)();
            if (_t _q_method = &StandardSystemButton::activeForegroundColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (StandardSystemButton::*)();
            if (_t _q_method = &StandardSystemButton::inactiveForegroundColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (StandardSystemButton::*)();
            if (_t _q_method = &StandardSystemButton::activeChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (StandardSystemButton::*)();
            if (_t _q_method = &StandardSystemButton::iconSize2Changed; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 10;
                return;
            }
        }
    }else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<StandardSystemButton *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< Global::SystemButtonType*>(_v) = _t->buttonType(); break;
        case 1: *reinterpret_cast< QString*>(_v) = _t->glyph(); break;
        case 2: *reinterpret_cast< bool*>(_v) = _t->isHovered(); break;
        case 3: *reinterpret_cast< bool*>(_v) = _t->isPressed(); break;
        case 4: *reinterpret_cast< QColor*>(_v) = _t->hoverColor(); break;
        case 5: *reinterpret_cast< QColor*>(_v) = _t->pressColor(); break;
        case 6: *reinterpret_cast< QColor*>(_v) = _t->normalColor(); break;
        case 7: *reinterpret_cast< QColor*>(_v) = _t->activeForegroundColor(); break;
        case 8: *reinterpret_cast< QColor*>(_v) = _t->inactiveForegroundColor(); break;
        case 9: *reinterpret_cast< bool*>(_v) = _t->isActive(); break;
        case 10: *reinterpret_cast< int*>(_v) = _t->iconSize2(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<StandardSystemButton *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setButtonType(*reinterpret_cast< Global::SystemButtonType*>(_v)); break;
        case 1: _t->setGlyph(*reinterpret_cast< QString*>(_v)); break;
        case 2: _t->setHovered(*reinterpret_cast< bool*>(_v)); break;
        case 3: _t->setPressed(*reinterpret_cast< bool*>(_v)); break;
        case 4: _t->setHoverColor(*reinterpret_cast< QColor*>(_v)); break;
        case 5: _t->setPressColor(*reinterpret_cast< QColor*>(_v)); break;
        case 6: _t->setNormalColor(*reinterpret_cast< QColor*>(_v)); break;
        case 7: _t->setActiveForegroundColor(*reinterpret_cast< QColor*>(_v)); break;
        case 8: _t->setInactiveForegroundColor(*reinterpret_cast< QColor*>(_v)); break;
        case 9: _t->setActive(*reinterpret_cast< bool*>(_v)); break;
        case 10: _t->setIconSize2(*reinterpret_cast< int*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    } else if (_c == QMetaObject::BindableProperty) {
    }
}

const QMetaObject *wangwenx190::FramelessHelper::StandardSystemButton::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *wangwenx190::FramelessHelper::StandardSystemButton::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardSystemButtonENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QAbstractButton::qt_metacast(_clname);
}

int wangwenx190::FramelessHelper::StandardSystemButton::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QAbstractButton::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 22)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 22;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 22)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 22;
    }else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    }
    return _id;
}

// SIGNAL 0
void wangwenx190::FramelessHelper::StandardSystemButton::buttonTypeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void wangwenx190::FramelessHelper::StandardSystemButton::glyphChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void wangwenx190::FramelessHelper::StandardSystemButton::hoveredChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void wangwenx190::FramelessHelper::StandardSystemButton::pressedChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void wangwenx190::FramelessHelper::StandardSystemButton::hoverColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void wangwenx190::FramelessHelper::StandardSystemButton::pressColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void wangwenx190::FramelessHelper::StandardSystemButton::normalColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void wangwenx190::FramelessHelper::StandardSystemButton::activeForegroundColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void wangwenx190::FramelessHelper::StandardSystemButton::inactiveForegroundColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void wangwenx190::FramelessHelper::StandardSystemButton::activeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
void wangwenx190::FramelessHelper::StandardSystemButton::iconSize2Changed()
{
    QMetaObject::activate(this, &staticMetaObject, 10, nullptr);
}
QT_WARNING_POP
