/****************************************************************************
** Meta object code from reading C++ file 'framelesswidgetshelper.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../framelesshelper/include/FramelessHelper/Widgets/framelesswidgetshelper.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'framelesswidgetshelper.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessWidgetsHelperENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessWidgetsHelperENDCLASS = QtMocHelpers::stringData(
    "wangwenx190::FramelessHelper::FramelessWidgetsHelper",
    "extendsContentIntoTitleBarChanged",
    "",
    "titleBarWidgetChanged",
    "windowFixedSizeChanged",
    "blurBehindWindowEnabledChanged",
    "windowChanged",
    "ready",
    "extendsContentIntoTitleBar",
    "value",
    "setTitleBarWidget",
    "QWidget*",
    "widget",
    "setSystemButton",
    "Global::SystemButtonType",
    "buttonType",
    "setHitTestVisible",
    "visible",
    "rect",
    "object",
    "showSystemMenu",
    "pos",
    "windowStartSystemMove2",
    "windowStartSystemResize2",
    "Qt::Edges",
    "edges",
    "moveWindowToDesktopCenter",
    "bringWindowToFront",
    "setWindowFixedSize",
    "setBlurBehindWindowEnabled",
    "titleBarWidget",
    "windowFixedSize",
    "blurBehindWindowEnabled",
    "window"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessWidgetsHelperENDCLASS_t {
    uint offsetsAndSizes[68];
    char stringdata0[53];
    char stringdata1[34];
    char stringdata2[1];
    char stringdata3[22];
    char stringdata4[23];
    char stringdata5[31];
    char stringdata6[14];
    char stringdata7[6];
    char stringdata8[27];
    char stringdata9[6];
    char stringdata10[18];
    char stringdata11[9];
    char stringdata12[7];
    char stringdata13[16];
    char stringdata14[25];
    char stringdata15[11];
    char stringdata16[18];
    char stringdata17[8];
    char stringdata18[5];
    char stringdata19[7];
    char stringdata20[15];
    char stringdata21[4];
    char stringdata22[23];
    char stringdata23[25];
    char stringdata24[10];
    char stringdata25[6];
    char stringdata26[26];
    char stringdata27[19];
    char stringdata28[19];
    char stringdata29[27];
    char stringdata30[15];
    char stringdata31[16];
    char stringdata32[24];
    char stringdata33[7];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessWidgetsHelperENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessWidgetsHelperENDCLASS_t qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessWidgetsHelperENDCLASS = {
    {
        QT_MOC_LITERAL(0, 52),  // "wangwenx190::FramelessHelper:..."
        QT_MOC_LITERAL(53, 33),  // "extendsContentIntoTitleBarCha..."
        QT_MOC_LITERAL(87, 0),  // ""
        QT_MOC_LITERAL(88, 21),  // "titleBarWidgetChanged"
        QT_MOC_LITERAL(110, 22),  // "windowFixedSizeChanged"
        QT_MOC_LITERAL(133, 30),  // "blurBehindWindowEnabledChanged"
        QT_MOC_LITERAL(164, 13),  // "windowChanged"
        QT_MOC_LITERAL(178, 5),  // "ready"
        QT_MOC_LITERAL(184, 26),  // "extendsContentIntoTitleBar"
        QT_MOC_LITERAL(211, 5),  // "value"
        QT_MOC_LITERAL(217, 17),  // "setTitleBarWidget"
        QT_MOC_LITERAL(235, 8),  // "QWidget*"
        QT_MOC_LITERAL(244, 6),  // "widget"
        QT_MOC_LITERAL(251, 15),  // "setSystemButton"
        QT_MOC_LITERAL(267, 24),  // "Global::SystemButtonType"
        QT_MOC_LITERAL(292, 10),  // "buttonType"
        QT_MOC_LITERAL(303, 17),  // "setHitTestVisible"
        QT_MOC_LITERAL(321, 7),  // "visible"
        QT_MOC_LITERAL(329, 4),  // "rect"
        QT_MOC_LITERAL(334, 6),  // "object"
        QT_MOC_LITERAL(341, 14),  // "showSystemMenu"
        QT_MOC_LITERAL(356, 3),  // "pos"
        QT_MOC_LITERAL(360, 22),  // "windowStartSystemMove2"
        QT_MOC_LITERAL(383, 24),  // "windowStartSystemResize2"
        QT_MOC_LITERAL(408, 9),  // "Qt::Edges"
        QT_MOC_LITERAL(418, 5),  // "edges"
        QT_MOC_LITERAL(424, 25),  // "moveWindowToDesktopCenter"
        QT_MOC_LITERAL(450, 18),  // "bringWindowToFront"
        QT_MOC_LITERAL(469, 18),  // "setWindowFixedSize"
        QT_MOC_LITERAL(488, 26),  // "setBlurBehindWindowEnabled"
        QT_MOC_LITERAL(515, 14),  // "titleBarWidget"
        QT_MOC_LITERAL(530, 15),  // "windowFixedSize"
        QT_MOC_LITERAL(546, 23),  // "blurBehindWindowEnabled"
        QT_MOC_LITERAL(570, 6)   // "window"
    },
    "wangwenx190::FramelessHelper::FramelessWidgetsHelper",
    "extendsContentIntoTitleBarChanged",
    "",
    "titleBarWidgetChanged",
    "windowFixedSizeChanged",
    "blurBehindWindowEnabledChanged",
    "windowChanged",
    "ready",
    "extendsContentIntoTitleBar",
    "value",
    "setTitleBarWidget",
    "QWidget*",
    "widget",
    "setSystemButton",
    "Global::SystemButtonType",
    "buttonType",
    "setHitTestVisible",
    "visible",
    "rect",
    "object",
    "showSystemMenu",
    "pos",
    "windowStartSystemMove2",
    "windowStartSystemResize2",
    "Qt::Edges",
    "edges",
    "moveWindowToDesktopCenter",
    "bringWindowToFront",
    "setWindowFixedSize",
    "setBlurBehindWindowEnabled",
    "titleBarWidget",
    "windowFixedSize",
    "blurBehindWindowEnabled",
    "window"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessWidgetsHelperENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       5,  213, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  152,    2, 0x06,    6 /* Public */,
       3,    0,  153,    2, 0x06,    7 /* Public */,
       4,    0,  154,    2, 0x06,    8 /* Public */,
       5,    0,  155,    2, 0x06,    9 /* Public */,
       6,    0,  156,    2, 0x06,   10 /* Public */,
       7,    0,  157,    2, 0x06,   11 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       8,    1,  158,    2, 0x0a,   12 /* Public */,
       8,    0,  161,    2, 0x2a,   14 /* Public | MethodCloned */,
      10,    1,  162,    2, 0x0a,   15 /* Public */,
      13,    2,  165,    2, 0x0a,   17 /* Public */,
      16,    2,  170,    2, 0x0a,   20 /* Public */,
      16,    1,  175,    2, 0x2a,   23 /* Public | MethodCloned */,
      16,    2,  178,    2, 0x0a,   25 /* Public */,
      16,    1,  183,    2, 0x2a,   28 /* Public | MethodCloned */,
      16,    2,  186,    2, 0x0a,   30 /* Public */,
      16,    1,  191,    2, 0x2a,   33 /* Public | MethodCloned */,
      20,    1,  194,    2, 0x0a,   35 /* Public */,
      22,    1,  197,    2, 0x0a,   37 /* Public */,
      23,    2,  200,    2, 0x0a,   39 /* Public */,
      26,    0,  205,    2, 0x0a,   42 /* Public */,
      27,    0,  206,    2, 0x0a,   43 /* Public */,
      28,    1,  207,    2, 0x0a,   44 /* Public */,
      29,    1,  210,    2, 0x0a,   46 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 11,   12,
    QMetaType::Void, 0x80000000 | 11, 0x80000000 | 14,   12,   15,
    QMetaType::Void, 0x80000000 | 11, QMetaType::Bool,   12,   17,
    QMetaType::Void, 0x80000000 | 11,   12,
    QMetaType::Void, QMetaType::QRect, QMetaType::Bool,   18,   17,
    QMetaType::Void, QMetaType::QRect,   18,
    QMetaType::Void, QMetaType::QObjectStar, QMetaType::Bool,   19,   17,
    QMetaType::Void, QMetaType::QObjectStar,   19,
    QMetaType::Void, QMetaType::QPoint,   21,
    QMetaType::Void, QMetaType::QPoint,   21,
    QMetaType::Void, 0x80000000 | 24, QMetaType::QPoint,   25,   21,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    9,
    QMetaType::Void, QMetaType::Bool,    9,

 // properties: name, type, flags
      30, 0x80000000 | 11, 0x0001590b, uint(1), 0,
      31, QMetaType::Bool, 0x00015903, uint(2), 0,
      32, QMetaType::Bool, 0x00015903, uint(3), 0,
      33, 0x80000000 | 11, 0x00015809, uint(4), 0,
       8, QMetaType::Bool, 0x00015803, uint(0), 0,

       0        // eod
};

Q_CONSTINIT const QMetaObject wangwenx190::FramelessHelper::FramelessWidgetsHelper::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessWidgetsHelperENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessWidgetsHelperENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessWidgetsHelperENDCLASS_t,
        // property 'titleBarWidget'
        QtPrivate::TypeAndForceComplete<QWidget*, std::true_type>,
        // property 'windowFixedSize'
        QtPrivate::TypeAndForceComplete<bool, std::true_type>,
        // property 'blurBehindWindowEnabled'
        QtPrivate::TypeAndForceComplete<bool, std::true_type>,
        // property 'window'
        QtPrivate::TypeAndForceComplete<QWidget*, std::true_type>,
        // property 'extendsContentIntoTitleBar'
        QtPrivate::TypeAndForceComplete<bool, std::true_type>,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<FramelessWidgetsHelper, std::true_type>,
        // method 'extendsContentIntoTitleBarChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'titleBarWidgetChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'windowFixedSizeChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'blurBehindWindowEnabledChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'windowChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'ready'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'extendsContentIntoTitleBar'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const bool, std::false_type>,
        // method 'extendsContentIntoTitleBar'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setTitleBarWidget'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QWidget *, std::false_type>,
        // method 'setSystemButton'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QWidget *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const Global::SystemButtonType, std::false_type>,
        // method 'setHitTestVisible'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QWidget *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const bool, std::false_type>,
        // method 'setHitTestVisible'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QWidget *, std::false_type>,
        // method 'setHitTestVisible'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QRect &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const bool, std::false_type>,
        // method 'setHitTestVisible'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QRect &, std::false_type>,
        // method 'setHitTestVisible'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QObject *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const bool, std::false_type>,
        // method 'setHitTestVisible'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QObject *, std::false_type>,
        // method 'showSystemMenu'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QPoint &, std::false_type>,
        // method 'windowStartSystemMove2'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QPoint &, std::false_type>,
        // method 'windowStartSystemResize2'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const Qt::Edges, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QPoint &, std::false_type>,
        // method 'moveWindowToDesktopCenter'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'bringWindowToFront'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setWindowFixedSize'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const bool, std::false_type>,
        // method 'setBlurBehindWindowEnabled'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const bool, std::false_type>
    >,
    nullptr
} };

void wangwenx190::FramelessHelper::FramelessWidgetsHelper::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<FramelessWidgetsHelper *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->extendsContentIntoTitleBarChanged(); break;
        case 1: _t->titleBarWidgetChanged(); break;
        case 2: _t->windowFixedSizeChanged(); break;
        case 3: _t->blurBehindWindowEnabledChanged(); break;
        case 4: _t->windowChanged(); break;
        case 5: _t->ready(); break;
        case 6: _t->extendsContentIntoTitleBar((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 7: _t->extendsContentIntoTitleBar(); break;
        case 8: _t->setTitleBarWidget((*reinterpret_cast< std::add_pointer_t<QWidget*>>(_a[1]))); break;
        case 9: _t->setSystemButton((*reinterpret_cast< std::add_pointer_t<QWidget*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<Global::SystemButtonType>>(_a[2]))); break;
        case 10: _t->setHitTestVisible((*reinterpret_cast< std::add_pointer_t<QWidget*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 11: _t->setHitTestVisible((*reinterpret_cast< std::add_pointer_t<QWidget*>>(_a[1]))); break;
        case 12: _t->setHitTestVisible((*reinterpret_cast< std::add_pointer_t<QRect>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 13: _t->setHitTestVisible((*reinterpret_cast< std::add_pointer_t<QRect>>(_a[1]))); break;
        case 14: _t->setHitTestVisible((*reinterpret_cast< std::add_pointer_t<QObject*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 15: _t->setHitTestVisible((*reinterpret_cast< std::add_pointer_t<QObject*>>(_a[1]))); break;
        case 16: _t->showSystemMenu((*reinterpret_cast< std::add_pointer_t<QPoint>>(_a[1]))); break;
        case 17: _t->windowStartSystemMove2((*reinterpret_cast< std::add_pointer_t<QPoint>>(_a[1]))); break;
        case 18: _t->windowStartSystemResize2((*reinterpret_cast< std::add_pointer_t<Qt::Edges>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QPoint>>(_a[2]))); break;
        case 19: _t->moveWindowToDesktopCenter(); break;
        case 20: _t->bringWindowToFront(); break;
        case 21: _t->setWindowFixedSize((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 22: _t->setBlurBehindWindowEnabled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 8:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QWidget* >(); break;
            }
            break;
        case 9:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QWidget* >(); break;
            }
            break;
        case 10:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QWidget* >(); break;
            }
            break;
        case 11:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QWidget* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (FramelessWidgetsHelper::*)();
            if (_t _q_method = &FramelessWidgetsHelper::extendsContentIntoTitleBarChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (FramelessWidgetsHelper::*)();
            if (_t _q_method = &FramelessWidgetsHelper::titleBarWidgetChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (FramelessWidgetsHelper::*)();
            if (_t _q_method = &FramelessWidgetsHelper::windowFixedSizeChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (FramelessWidgetsHelper::*)();
            if (_t _q_method = &FramelessWidgetsHelper::blurBehindWindowEnabledChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (FramelessWidgetsHelper::*)();
            if (_t _q_method = &FramelessWidgetsHelper::windowChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (FramelessWidgetsHelper::*)();
            if (_t _q_method = &FramelessWidgetsHelper::ready; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 3:
        case 0:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QWidget* >(); break;
        }
    } else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<FramelessWidgetsHelper *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QWidget**>(_v) = _t->titleBarWidget(); break;
        case 1: *reinterpret_cast< bool*>(_v) = _t->isWindowFixedSize(); break;
        case 2: *reinterpret_cast< bool*>(_v) = _t->isBlurBehindWindowEnabled(); break;
        case 3: *reinterpret_cast< QWidget**>(_v) = _t->window(); break;
        case 4: *reinterpret_cast< bool*>(_v) = _t->isContentExtendedIntoTitleBar(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<FramelessWidgetsHelper *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setTitleBarWidget(*reinterpret_cast< QWidget**>(_v)); break;
        case 1: _t->setWindowFixedSize(*reinterpret_cast< bool*>(_v)); break;
        case 2: _t->setBlurBehindWindowEnabled(*reinterpret_cast< bool*>(_v)); break;
        case 4: _t->extendsContentIntoTitleBar(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    } else if (_c == QMetaObject::BindableProperty) {
    }
}

const QMetaObject *wangwenx190::FramelessHelper::FramelessWidgetsHelper::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *wangwenx190::FramelessHelper::FramelessWidgetsHelper::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessWidgetsHelperENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int wangwenx190::FramelessHelper::FramelessWidgetsHelper::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    }else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void wangwenx190::FramelessHelper::FramelessWidgetsHelper::extendsContentIntoTitleBarChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void wangwenx190::FramelessHelper::FramelessWidgetsHelper::titleBarWidgetChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void wangwenx190::FramelessHelper::FramelessWidgetsHelper::windowFixedSizeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void wangwenx190::FramelessHelper::FramelessWidgetsHelper::blurBehindWindowEnabledChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void wangwenx190::FramelessHelper::FramelessWidgetsHelper::windowChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void wangwenx190::FramelessHelper::FramelessWidgetsHelper::ready()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}
QT_WARNING_POP
