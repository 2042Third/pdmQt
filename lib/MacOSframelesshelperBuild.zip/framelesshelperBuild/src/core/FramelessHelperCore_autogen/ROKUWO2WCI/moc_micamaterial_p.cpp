/****************************************************************************
** Meta object code from reading C++ file 'micamaterial_p.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../framelesshelper/include/FramelessHelper/Core/private/micamaterial_p.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'micamaterial_p.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialPrivateENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialPrivateENDCLASS = QtMocHelpers::stringData(
    "wangwenx190::FramelessHelper::MicaMaterialPrivate",
    "maybeGenerateBlurredWallpaper",
    "",
    "force",
    "updateMaterialBrush",
    "paint",
    "QPainter*",
    "painter",
    "rect",
    "active",
    "forceRebuildWallpaper"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialPrivateENDCLASS_t {
    uint offsetsAndSizes[22];
    char stringdata0[50];
    char stringdata1[30];
    char stringdata2[1];
    char stringdata3[6];
    char stringdata4[20];
    char stringdata5[6];
    char stringdata6[10];
    char stringdata7[8];
    char stringdata8[5];
    char stringdata9[7];
    char stringdata10[22];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialPrivateENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialPrivateENDCLASS_t qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialPrivateENDCLASS = {
    {
        QT_MOC_LITERAL(0, 49),  // "wangwenx190::FramelessHelper:..."
        QT_MOC_LITERAL(50, 29),  // "maybeGenerateBlurredWallpaper"
        QT_MOC_LITERAL(80, 0),  // ""
        QT_MOC_LITERAL(81, 5),  // "force"
        QT_MOC_LITERAL(87, 19),  // "updateMaterialBrush"
        QT_MOC_LITERAL(107, 5),  // "paint"
        QT_MOC_LITERAL(113, 9),  // "QPainter*"
        QT_MOC_LITERAL(123, 7),  // "painter"
        QT_MOC_LITERAL(131, 4),  // "rect"
        QT_MOC_LITERAL(136, 6),  // "active"
        QT_MOC_LITERAL(143, 21)   // "forceRebuildWallpaper"
    },
    "wangwenx190::FramelessHelper::MicaMaterialPrivate",
    "maybeGenerateBlurredWallpaper",
    "",
    "force",
    "updateMaterialBrush",
    "paint",
    "QPainter*",
    "painter",
    "rect",
    "active",
    "forceRebuildWallpaper"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialPrivateENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   50,    2, 0x0a,    1 /* Public */,
       1,    0,   53,    2, 0x2a,    3 /* Public | MethodCloned */,
       4,    0,   54,    2, 0x0a,    4 /* Public */,
       5,    3,   55,    2, 0x0a,    5 /* Public */,
       5,    2,   62,    2, 0x2a,    9 /* Public | MethodCloned */,
      10,    0,   67,    2, 0x0a,   12 /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 6, QMetaType::QRect, QMetaType::Bool,    7,    8,    9,
    QMetaType::Void, 0x80000000 | 6, QMetaType::QRect,    7,    8,
    QMetaType::Void,

       0        // eod
};

Q_CONSTINIT const QMetaObject wangwenx190::FramelessHelper::MicaMaterialPrivate::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialPrivateENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialPrivateENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialPrivateENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MicaMaterialPrivate, std::true_type>,
        // method 'maybeGenerateBlurredWallpaper'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const bool, std::false_type>,
        // method 'maybeGenerateBlurredWallpaper'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'updateMaterialBrush'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'paint'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPainter *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QRect &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const bool, std::false_type>,
        // method 'paint'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPainter *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QRect &, std::false_type>,
        // method 'forceRebuildWallpaper'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void wangwenx190::FramelessHelper::MicaMaterialPrivate::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MicaMaterialPrivate *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->maybeGenerateBlurredWallpaper((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 1: _t->maybeGenerateBlurredWallpaper(); break;
        case 2: _t->updateMaterialBrush(); break;
        case 3: _t->paint((*reinterpret_cast< std::add_pointer_t<QPainter*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QRect>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[3]))); break;
        case 4: _t->paint((*reinterpret_cast< std::add_pointer_t<QPainter*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QRect>>(_a[2]))); break;
        case 5: _t->forceRebuildWallpaper(); break;
        default: ;
        }
    }
}

const QMetaObject *wangwenx190::FramelessHelper::MicaMaterialPrivate::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *wangwenx190::FramelessHelper::MicaMaterialPrivate::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialPrivateENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int wangwenx190::FramelessHelper::MicaMaterialPrivate::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 6;
    }
    return _id;
}
QT_WARNING_POP
