/****************************************************************************
** Meta object code from reading C++ file 'chromepalette.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../framelesshelper/include/FramelessHelper/Core/chromepalette.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'chromepalette.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEChromePaletteENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEChromePaletteENDCLASS = QtMocHelpers::stringData(
    "wangwenx190::FramelessHelper::ChromePalette",
    "titleBarActiveBackgroundColorChanged",
    "",
    "titleBarInactiveBackgroundColorChanged",
    "titleBarActiveForegroundColorChanged",
    "titleBarInactiveForegroundColorChanged",
    "chromeButtonNormalColorChanged",
    "chromeButtonHoverColorChanged",
    "chromeButtonPressColorChanged",
    "closeButtonNormalColorChanged",
    "closeButtonHoverColorChanged",
    "closeButtonPressColorChanged",
    "titleBarColorChanged",
    "chromeButtonColorChanged",
    "setTitleBarActiveBackgroundColor",
    "value",
    "resetTitleBarActiveBackgroundColor",
    "setTitleBarInactiveBackgroundColor",
    "resetTitleBarInactiveBackgroundColor",
    "setTitleBarActiveForegroundColor",
    "resetTitleBarActiveForegroundColor",
    "setTitleBarInactiveForegroundColor",
    "resetTitleBarInactiveForegroundColor",
    "setChromeButtonNormalColor",
    "resetChromeButtonNormalColor",
    "setChromeButtonHoverColor",
    "resetChromeButtonHoverColor",
    "setChromeButtonPressColor",
    "resetChromeButtonPressColor",
    "setCloseButtonNormalColor",
    "resetCloseButtonNormalColor",
    "setCloseButtonHoverColor",
    "resetCloseButtonHoverColor",
    "setCloseButtonPressColor",
    "resetCloseButtonPressColor",
    "titleBarActiveBackgroundColor",
    "titleBarInactiveBackgroundColor",
    "titleBarActiveForegroundColor",
    "titleBarInactiveForegroundColor",
    "chromeButtonNormalColor",
    "chromeButtonHoverColor",
    "chromeButtonPressColor",
    "closeButtonNormalColor",
    "closeButtonHoverColor",
    "closeButtonPressColor"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEChromePaletteENDCLASS_t {
    uint offsetsAndSizes[90];
    char stringdata0[44];
    char stringdata1[37];
    char stringdata2[1];
    char stringdata3[39];
    char stringdata4[37];
    char stringdata5[39];
    char stringdata6[31];
    char stringdata7[30];
    char stringdata8[30];
    char stringdata9[30];
    char stringdata10[29];
    char stringdata11[29];
    char stringdata12[21];
    char stringdata13[25];
    char stringdata14[33];
    char stringdata15[6];
    char stringdata16[35];
    char stringdata17[35];
    char stringdata18[37];
    char stringdata19[33];
    char stringdata20[35];
    char stringdata21[35];
    char stringdata22[37];
    char stringdata23[27];
    char stringdata24[29];
    char stringdata25[26];
    char stringdata26[28];
    char stringdata27[26];
    char stringdata28[28];
    char stringdata29[26];
    char stringdata30[28];
    char stringdata31[25];
    char stringdata32[27];
    char stringdata33[25];
    char stringdata34[27];
    char stringdata35[30];
    char stringdata36[32];
    char stringdata37[30];
    char stringdata38[32];
    char stringdata39[24];
    char stringdata40[23];
    char stringdata41[23];
    char stringdata42[23];
    char stringdata43[22];
    char stringdata44[22];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEChromePaletteENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEChromePaletteENDCLASS_t qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEChromePaletteENDCLASS = {
    {
        QT_MOC_LITERAL(0, 43),  // "wangwenx190::FramelessHelper:..."
        QT_MOC_LITERAL(44, 36),  // "titleBarActiveBackgroundColor..."
        QT_MOC_LITERAL(81, 0),  // ""
        QT_MOC_LITERAL(82, 38),  // "titleBarInactiveBackgroundCol..."
        QT_MOC_LITERAL(121, 36),  // "titleBarActiveForegroundColor..."
        QT_MOC_LITERAL(158, 38),  // "titleBarInactiveForegroundCol..."
        QT_MOC_LITERAL(197, 30),  // "chromeButtonNormalColorChanged"
        QT_MOC_LITERAL(228, 29),  // "chromeButtonHoverColorChanged"
        QT_MOC_LITERAL(258, 29),  // "chromeButtonPressColorChanged"
        QT_MOC_LITERAL(288, 29),  // "closeButtonNormalColorChanged"
        QT_MOC_LITERAL(318, 28),  // "closeButtonHoverColorChanged"
        QT_MOC_LITERAL(347, 28),  // "closeButtonPressColorChanged"
        QT_MOC_LITERAL(376, 20),  // "titleBarColorChanged"
        QT_MOC_LITERAL(397, 24),  // "chromeButtonColorChanged"
        QT_MOC_LITERAL(422, 32),  // "setTitleBarActiveBackgroundColor"
        QT_MOC_LITERAL(455, 5),  // "value"
        QT_MOC_LITERAL(461, 34),  // "resetTitleBarActiveBackground..."
        QT_MOC_LITERAL(496, 34),  // "setTitleBarInactiveBackground..."
        QT_MOC_LITERAL(531, 36),  // "resetTitleBarInactiveBackgrou..."
        QT_MOC_LITERAL(568, 32),  // "setTitleBarActiveForegroundColor"
        QT_MOC_LITERAL(601, 34),  // "resetTitleBarActiveForeground..."
        QT_MOC_LITERAL(636, 34),  // "setTitleBarInactiveForeground..."
        QT_MOC_LITERAL(671, 36),  // "resetTitleBarInactiveForegrou..."
        QT_MOC_LITERAL(708, 26),  // "setChromeButtonNormalColor"
        QT_MOC_LITERAL(735, 28),  // "resetChromeButtonNormalColor"
        QT_MOC_LITERAL(764, 25),  // "setChromeButtonHoverColor"
        QT_MOC_LITERAL(790, 27),  // "resetChromeButtonHoverColor"
        QT_MOC_LITERAL(818, 25),  // "setChromeButtonPressColor"
        QT_MOC_LITERAL(844, 27),  // "resetChromeButtonPressColor"
        QT_MOC_LITERAL(872, 25),  // "setCloseButtonNormalColor"
        QT_MOC_LITERAL(898, 27),  // "resetCloseButtonNormalColor"
        QT_MOC_LITERAL(926, 24),  // "setCloseButtonHoverColor"
        QT_MOC_LITERAL(951, 26),  // "resetCloseButtonHoverColor"
        QT_MOC_LITERAL(978, 24),  // "setCloseButtonPressColor"
        QT_MOC_LITERAL(1003, 26),  // "resetCloseButtonPressColor"
        QT_MOC_LITERAL(1030, 29),  // "titleBarActiveBackgroundColor"
        QT_MOC_LITERAL(1060, 31),  // "titleBarInactiveBackgroundColor"
        QT_MOC_LITERAL(1092, 29),  // "titleBarActiveForegroundColor"
        QT_MOC_LITERAL(1122, 31),  // "titleBarInactiveForegroundColor"
        QT_MOC_LITERAL(1154, 23),  // "chromeButtonNormalColor"
        QT_MOC_LITERAL(1178, 22),  // "chromeButtonHoverColor"
        QT_MOC_LITERAL(1201, 22),  // "chromeButtonPressColor"
        QT_MOC_LITERAL(1224, 22),  // "closeButtonNormalColor"
        QT_MOC_LITERAL(1247, 21),  // "closeButtonHoverColor"
        QT_MOC_LITERAL(1269, 21)   // "closeButtonPressColor"
    },
    "wangwenx190::FramelessHelper::ChromePalette",
    "titleBarActiveBackgroundColorChanged",
    "",
    "titleBarInactiveBackgroundColorChanged",
    "titleBarActiveForegroundColorChanged",
    "titleBarInactiveForegroundColorChanged",
    "chromeButtonNormalColorChanged",
    "chromeButtonHoverColorChanged",
    "chromeButtonPressColorChanged",
    "closeButtonNormalColorChanged",
    "closeButtonHoverColorChanged",
    "closeButtonPressColorChanged",
    "titleBarColorChanged",
    "chromeButtonColorChanged",
    "setTitleBarActiveBackgroundColor",
    "value",
    "resetTitleBarActiveBackgroundColor",
    "setTitleBarInactiveBackgroundColor",
    "resetTitleBarInactiveBackgroundColor",
    "setTitleBarActiveForegroundColor",
    "resetTitleBarActiveForegroundColor",
    "setTitleBarInactiveForegroundColor",
    "resetTitleBarInactiveForegroundColor",
    "setChromeButtonNormalColor",
    "resetChromeButtonNormalColor",
    "setChromeButtonHoverColor",
    "resetChromeButtonHoverColor",
    "setChromeButtonPressColor",
    "resetChromeButtonPressColor",
    "setCloseButtonNormalColor",
    "resetCloseButtonNormalColor",
    "setCloseButtonHoverColor",
    "resetCloseButtonHoverColor",
    "setCloseButtonPressColor",
    "resetCloseButtonPressColor",
    "titleBarActiveBackgroundColor",
    "titleBarInactiveBackgroundColor",
    "titleBarActiveForegroundColor",
    "titleBarInactiveForegroundColor",
    "chromeButtonNormalColor",
    "chromeButtonHoverColor",
    "chromeButtonPressColor",
    "closeButtonNormalColor",
    "closeButtonHoverColor",
    "closeButtonPressColor"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEChromePaletteENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      32,   14, // methods
      10,  258, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      12,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  206,    2, 0x06,   11 /* Public */,
       3,    0,  207,    2, 0x06,   12 /* Public */,
       4,    0,  208,    2, 0x06,   13 /* Public */,
       5,    0,  209,    2, 0x06,   14 /* Public */,
       6,    0,  210,    2, 0x06,   15 /* Public */,
       7,    0,  211,    2, 0x06,   16 /* Public */,
       8,    0,  212,    2, 0x06,   17 /* Public */,
       9,    0,  213,    2, 0x06,   18 /* Public */,
      10,    0,  214,    2, 0x06,   19 /* Public */,
      11,    0,  215,    2, 0x06,   20 /* Public */,
      12,    0,  216,    2, 0x06,   21 /* Public */,
      13,    0,  217,    2, 0x06,   22 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      14,    1,  218,    2, 0x0a,   23 /* Public */,
      16,    0,  221,    2, 0x0a,   25 /* Public */,
      17,    1,  222,    2, 0x0a,   26 /* Public */,
      18,    0,  225,    2, 0x0a,   28 /* Public */,
      19,    1,  226,    2, 0x0a,   29 /* Public */,
      20,    0,  229,    2, 0x0a,   31 /* Public */,
      21,    1,  230,    2, 0x0a,   32 /* Public */,
      22,    0,  233,    2, 0x0a,   34 /* Public */,
      23,    1,  234,    2, 0x0a,   35 /* Public */,
      24,    0,  237,    2, 0x0a,   37 /* Public */,
      25,    1,  238,    2, 0x0a,   38 /* Public */,
      26,    0,  241,    2, 0x0a,   40 /* Public */,
      27,    1,  242,    2, 0x0a,   41 /* Public */,
      28,    0,  245,    2, 0x0a,   43 /* Public */,
      29,    1,  246,    2, 0x0a,   44 /* Public */,
      30,    0,  249,    2, 0x0a,   46 /* Public */,
      31,    1,  250,    2, 0x0a,   47 /* Public */,
      32,    0,  253,    2, 0x0a,   49 /* Public */,
      33,    1,  254,    2, 0x0a,   50 /* Public */,
      34,    0,  257,    2, 0x0a,   52 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::QColor,   15,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QColor,   15,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QColor,   15,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QColor,   15,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QColor,   15,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QColor,   15,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QColor,   15,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QColor,   15,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QColor,   15,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QColor,   15,
    QMetaType::Void,

 // properties: name, type, flags
      35, QMetaType::QColor, 0x00015907, uint(0), 0,
      36, QMetaType::QColor, 0x00015907, uint(1), 0,
      37, QMetaType::QColor, 0x00015907, uint(2), 0,
      38, QMetaType::QColor, 0x00015907, uint(3), 0,
      39, QMetaType::QColor, 0x00015907, uint(4), 0,
      40, QMetaType::QColor, 0x00015907, uint(5), 0,
      41, QMetaType::QColor, 0x00015907, uint(6), 0,
      42, QMetaType::QColor, 0x00015907, uint(7), 0,
      43, QMetaType::QColor, 0x00015907, uint(8), 0,
      44, QMetaType::QColor, 0x00015907, uint(9), 0,

       0        // eod
};

Q_CONSTINIT const QMetaObject wangwenx190::FramelessHelper::ChromePalette::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEChromePaletteENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEChromePaletteENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEChromePaletteENDCLASS_t,
        // property 'titleBarActiveBackgroundColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'titleBarInactiveBackgroundColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'titleBarActiveForegroundColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'titleBarInactiveForegroundColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'chromeButtonNormalColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'chromeButtonHoverColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'chromeButtonPressColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'closeButtonNormalColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'closeButtonHoverColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'closeButtonPressColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<ChromePalette, std::true_type>,
        // method 'titleBarActiveBackgroundColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'titleBarInactiveBackgroundColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'titleBarActiveForegroundColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'titleBarInactiveForegroundColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'chromeButtonNormalColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'chromeButtonHoverColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'chromeButtonPressColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'closeButtonNormalColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'closeButtonHoverColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'closeButtonPressColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'titleBarColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'chromeButtonColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setTitleBarActiveBackgroundColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QColor &, std::false_type>,
        // method 'resetTitleBarActiveBackgroundColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setTitleBarInactiveBackgroundColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QColor &, std::false_type>,
        // method 'resetTitleBarInactiveBackgroundColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setTitleBarActiveForegroundColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QColor &, std::false_type>,
        // method 'resetTitleBarActiveForegroundColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setTitleBarInactiveForegroundColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QColor &, std::false_type>,
        // method 'resetTitleBarInactiveForegroundColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setChromeButtonNormalColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QColor &, std::false_type>,
        // method 'resetChromeButtonNormalColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setChromeButtonHoverColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QColor &, std::false_type>,
        // method 'resetChromeButtonHoverColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setChromeButtonPressColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QColor &, std::false_type>,
        // method 'resetChromeButtonPressColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setCloseButtonNormalColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QColor &, std::false_type>,
        // method 'resetCloseButtonNormalColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setCloseButtonHoverColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QColor &, std::false_type>,
        // method 'resetCloseButtonHoverColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'setCloseButtonPressColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QColor &, std::false_type>,
        // method 'resetCloseButtonPressColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void wangwenx190::FramelessHelper::ChromePalette::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<ChromePalette *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->titleBarActiveBackgroundColorChanged(); break;
        case 1: _t->titleBarInactiveBackgroundColorChanged(); break;
        case 2: _t->titleBarActiveForegroundColorChanged(); break;
        case 3: _t->titleBarInactiveForegroundColorChanged(); break;
        case 4: _t->chromeButtonNormalColorChanged(); break;
        case 5: _t->chromeButtonHoverColorChanged(); break;
        case 6: _t->chromeButtonPressColorChanged(); break;
        case 7: _t->closeButtonNormalColorChanged(); break;
        case 8: _t->closeButtonHoverColorChanged(); break;
        case 9: _t->closeButtonPressColorChanged(); break;
        case 10: _t->titleBarColorChanged(); break;
        case 11: _t->chromeButtonColorChanged(); break;
        case 12: _t->setTitleBarActiveBackgroundColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 13: _t->resetTitleBarActiveBackgroundColor(); break;
        case 14: _t->setTitleBarInactiveBackgroundColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 15: _t->resetTitleBarInactiveBackgroundColor(); break;
        case 16: _t->setTitleBarActiveForegroundColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 17: _t->resetTitleBarActiveForegroundColor(); break;
        case 18: _t->setTitleBarInactiveForegroundColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 19: _t->resetTitleBarInactiveForegroundColor(); break;
        case 20: _t->setChromeButtonNormalColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 21: _t->resetChromeButtonNormalColor(); break;
        case 22: _t->setChromeButtonHoverColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 23: _t->resetChromeButtonHoverColor(); break;
        case 24: _t->setChromeButtonPressColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 25: _t->resetChromeButtonPressColor(); break;
        case 26: _t->setCloseButtonNormalColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 27: _t->resetCloseButtonNormalColor(); break;
        case 28: _t->setCloseButtonHoverColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 29: _t->resetCloseButtonHoverColor(); break;
        case 30: _t->setCloseButtonPressColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 31: _t->resetCloseButtonPressColor(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (ChromePalette::*)();
            if (_t _q_method = &ChromePalette::titleBarActiveBackgroundColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (ChromePalette::*)();
            if (_t _q_method = &ChromePalette::titleBarInactiveBackgroundColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (ChromePalette::*)();
            if (_t _q_method = &ChromePalette::titleBarActiveForegroundColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (ChromePalette::*)();
            if (_t _q_method = &ChromePalette::titleBarInactiveForegroundColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (ChromePalette::*)();
            if (_t _q_method = &ChromePalette::chromeButtonNormalColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (ChromePalette::*)();
            if (_t _q_method = &ChromePalette::chromeButtonHoverColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (ChromePalette::*)();
            if (_t _q_method = &ChromePalette::chromeButtonPressColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (ChromePalette::*)();
            if (_t _q_method = &ChromePalette::closeButtonNormalColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (ChromePalette::*)();
            if (_t _q_method = &ChromePalette::closeButtonHoverColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (ChromePalette::*)();
            if (_t _q_method = &ChromePalette::closeButtonPressColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (ChromePalette::*)();
            if (_t _q_method = &ChromePalette::titleBarColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (ChromePalette::*)();
            if (_t _q_method = &ChromePalette::chromeButtonColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 11;
                return;
            }
        }
    }else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<ChromePalette *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QColor*>(_v) = _t->titleBarActiveBackgroundColor(); break;
        case 1: *reinterpret_cast< QColor*>(_v) = _t->titleBarInactiveBackgroundColor(); break;
        case 2: *reinterpret_cast< QColor*>(_v) = _t->titleBarActiveForegroundColor(); break;
        case 3: *reinterpret_cast< QColor*>(_v) = _t->titleBarInactiveForegroundColor(); break;
        case 4: *reinterpret_cast< QColor*>(_v) = _t->chromeButtonNormalColor(); break;
        case 5: *reinterpret_cast< QColor*>(_v) = _t->chromeButtonHoverColor(); break;
        case 6: *reinterpret_cast< QColor*>(_v) = _t->chromeButtonPressColor(); break;
        case 7: *reinterpret_cast< QColor*>(_v) = _t->closeButtonNormalColor(); break;
        case 8: *reinterpret_cast< QColor*>(_v) = _t->closeButtonHoverColor(); break;
        case 9: *reinterpret_cast< QColor*>(_v) = _t->closeButtonPressColor(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<ChromePalette *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setTitleBarActiveBackgroundColor(*reinterpret_cast< QColor*>(_v)); break;
        case 1: _t->setTitleBarInactiveBackgroundColor(*reinterpret_cast< QColor*>(_v)); break;
        case 2: _t->setTitleBarActiveForegroundColor(*reinterpret_cast< QColor*>(_v)); break;
        case 3: _t->setTitleBarInactiveForegroundColor(*reinterpret_cast< QColor*>(_v)); break;
        case 4: _t->setChromeButtonNormalColor(*reinterpret_cast< QColor*>(_v)); break;
        case 5: _t->setChromeButtonHoverColor(*reinterpret_cast< QColor*>(_v)); break;
        case 6: _t->setChromeButtonPressColor(*reinterpret_cast< QColor*>(_v)); break;
        case 7: _t->setCloseButtonNormalColor(*reinterpret_cast< QColor*>(_v)); break;
        case 8: _t->setCloseButtonHoverColor(*reinterpret_cast< QColor*>(_v)); break;
        case 9: _t->setCloseButtonPressColor(*reinterpret_cast< QColor*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
        auto *_t = static_cast<ChromePalette *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->resetTitleBarActiveBackgroundColor(); break;
        case 1: _t->resetTitleBarInactiveBackgroundColor(); break;
        case 2: _t->resetTitleBarActiveForegroundColor(); break;
        case 3: _t->resetTitleBarInactiveForegroundColor(); break;
        case 4: _t->resetChromeButtonNormalColor(); break;
        case 5: _t->resetChromeButtonHoverColor(); break;
        case 6: _t->resetChromeButtonPressColor(); break;
        case 7: _t->resetCloseButtonNormalColor(); break;
        case 8: _t->resetCloseButtonHoverColor(); break;
        case 9: _t->resetCloseButtonPressColor(); break;
        default: break;
        }
    } else if (_c == QMetaObject::BindableProperty) {
    }
}

const QMetaObject *wangwenx190::FramelessHelper::ChromePalette::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *wangwenx190::FramelessHelper::ChromePalette::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEChromePaletteENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int wangwenx190::FramelessHelper::ChromePalette::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 32)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 32;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 32)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 32;
    }else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    }
    return _id;
}

// SIGNAL 0
void wangwenx190::FramelessHelper::ChromePalette::titleBarActiveBackgroundColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void wangwenx190::FramelessHelper::ChromePalette::titleBarInactiveBackgroundColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void wangwenx190::FramelessHelper::ChromePalette::titleBarActiveForegroundColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void wangwenx190::FramelessHelper::ChromePalette::titleBarInactiveForegroundColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void wangwenx190::FramelessHelper::ChromePalette::chromeButtonNormalColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void wangwenx190::FramelessHelper::ChromePalette::chromeButtonHoverColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void wangwenx190::FramelessHelper::ChromePalette::chromeButtonPressColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void wangwenx190::FramelessHelper::ChromePalette::closeButtonNormalColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}

// SIGNAL 8
void wangwenx190::FramelessHelper::ChromePalette::closeButtonHoverColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 8, nullptr);
}

// SIGNAL 9
void wangwenx190::FramelessHelper::ChromePalette::closeButtonPressColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 9, nullptr);
}

// SIGNAL 10
void wangwenx190::FramelessHelper::ChromePalette::titleBarColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 10, nullptr);
}

// SIGNAL 11
void wangwenx190::FramelessHelper::ChromePalette::chromeButtonColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 11, nullptr);
}
QT_WARNING_POP
