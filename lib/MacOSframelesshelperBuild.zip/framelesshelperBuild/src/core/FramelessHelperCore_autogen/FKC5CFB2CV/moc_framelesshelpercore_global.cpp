/****************************************************************************
** Meta object code from reading C++ file 'framelesshelpercore_global.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../framelesshelper/include/FramelessHelper/Core/framelesshelpercore_global.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'framelesshelpercore_global.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEGlobalENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEGlobalENDCLASS = QtMocHelpers::stringData(
    "wangwenx190::FramelessHelper::Global",
    "Option",
    "UseCrossPlatformQtImplementation",
    "ForceHideWindowFrameBorder",
    "ForceShowWindowFrameBorder",
    "DisableWindowsSnapLayout",
    "WindowUseRoundCorners",
    "CenterWindowBeforeShow",
    "EnableBlurBehindWindow",
    "ForceNonNativeBackgroundBlur",
    "DisableLazyInitializationForMicaMaterial",
    "ForceNativeBackgroundBlur",
    "Last",
    "SystemTheme",
    "Unknown",
    "Light",
    "Dark",
    "HighContrast",
    "SystemButtonType",
    "WindowIcon",
    "Help",
    "Minimize",
    "Maximize",
    "Restore",
    "Close",
    "ButtonState",
    "Normal",
    "Hovered",
    "Pressed",
    "Released",
    "BlurMode",
    "Disable",
    "Default",
    "Windows_Aero",
    "Windows_Acrylic",
    "Windows_Mica",
    "Windows_MicaAlt",
    "WallpaperAspectStyle",
    "Fill",
    "Fit",
    "Stretch",
    "Tile",
    "Center",
    "Span",
    "WindowEdge",
    "Left",
    "Top",
    "Right",
    "Bottom",
    "WindowEdges",
    "WindowCornerStyle",
    "Square",
    "Round"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEGlobalENDCLASS_t {
    uint offsetsAndSizes[106];
    char stringdata0[37];
    char stringdata1[7];
    char stringdata2[33];
    char stringdata3[27];
    char stringdata4[27];
    char stringdata5[25];
    char stringdata6[22];
    char stringdata7[23];
    char stringdata8[23];
    char stringdata9[29];
    char stringdata10[41];
    char stringdata11[26];
    char stringdata12[5];
    char stringdata13[12];
    char stringdata14[8];
    char stringdata15[6];
    char stringdata16[5];
    char stringdata17[13];
    char stringdata18[17];
    char stringdata19[11];
    char stringdata20[5];
    char stringdata21[9];
    char stringdata22[9];
    char stringdata23[8];
    char stringdata24[6];
    char stringdata25[12];
    char stringdata26[7];
    char stringdata27[8];
    char stringdata28[8];
    char stringdata29[9];
    char stringdata30[9];
    char stringdata31[8];
    char stringdata32[8];
    char stringdata33[13];
    char stringdata34[16];
    char stringdata35[13];
    char stringdata36[16];
    char stringdata37[21];
    char stringdata38[5];
    char stringdata39[4];
    char stringdata40[8];
    char stringdata41[5];
    char stringdata42[7];
    char stringdata43[5];
    char stringdata44[11];
    char stringdata45[5];
    char stringdata46[4];
    char stringdata47[6];
    char stringdata48[7];
    char stringdata49[12];
    char stringdata50[18];
    char stringdata51[7];
    char stringdata52[6];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEGlobalENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEGlobalENDCLASS_t qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEGlobalENDCLASS = {
    {
        QT_MOC_LITERAL(0, 36),  // "wangwenx190::FramelessHelper:..."
        QT_MOC_LITERAL(37, 6),  // "Option"
        QT_MOC_LITERAL(44, 32),  // "UseCrossPlatformQtImplementation"
        QT_MOC_LITERAL(77, 26),  // "ForceHideWindowFrameBorder"
        QT_MOC_LITERAL(104, 26),  // "ForceShowWindowFrameBorder"
        QT_MOC_LITERAL(131, 24),  // "DisableWindowsSnapLayout"
        QT_MOC_LITERAL(156, 21),  // "WindowUseRoundCorners"
        QT_MOC_LITERAL(178, 22),  // "CenterWindowBeforeShow"
        QT_MOC_LITERAL(201, 22),  // "EnableBlurBehindWindow"
        QT_MOC_LITERAL(224, 28),  // "ForceNonNativeBackgroundBlur"
        QT_MOC_LITERAL(253, 40),  // "DisableLazyInitializationForM..."
        QT_MOC_LITERAL(294, 25),  // "ForceNativeBackgroundBlur"
        QT_MOC_LITERAL(320, 4),  // "Last"
        QT_MOC_LITERAL(325, 11),  // "SystemTheme"
        QT_MOC_LITERAL(337, 7),  // "Unknown"
        QT_MOC_LITERAL(345, 5),  // "Light"
        QT_MOC_LITERAL(351, 4),  // "Dark"
        QT_MOC_LITERAL(356, 12),  // "HighContrast"
        QT_MOC_LITERAL(369, 16),  // "SystemButtonType"
        QT_MOC_LITERAL(386, 10),  // "WindowIcon"
        QT_MOC_LITERAL(397, 4),  // "Help"
        QT_MOC_LITERAL(402, 8),  // "Minimize"
        QT_MOC_LITERAL(411, 8),  // "Maximize"
        QT_MOC_LITERAL(420, 7),  // "Restore"
        QT_MOC_LITERAL(428, 5),  // "Close"
        QT_MOC_LITERAL(434, 11),  // "ButtonState"
        QT_MOC_LITERAL(446, 6),  // "Normal"
        QT_MOC_LITERAL(453, 7),  // "Hovered"
        QT_MOC_LITERAL(461, 7),  // "Pressed"
        QT_MOC_LITERAL(469, 8),  // "Released"
        QT_MOC_LITERAL(478, 8),  // "BlurMode"
        QT_MOC_LITERAL(487, 7),  // "Disable"
        QT_MOC_LITERAL(495, 7),  // "Default"
        QT_MOC_LITERAL(503, 12),  // "Windows_Aero"
        QT_MOC_LITERAL(516, 15),  // "Windows_Acrylic"
        QT_MOC_LITERAL(532, 12),  // "Windows_Mica"
        QT_MOC_LITERAL(545, 15),  // "Windows_MicaAlt"
        QT_MOC_LITERAL(561, 20),  // "WallpaperAspectStyle"
        QT_MOC_LITERAL(582, 4),  // "Fill"
        QT_MOC_LITERAL(587, 3),  // "Fit"
        QT_MOC_LITERAL(591, 7),  // "Stretch"
        QT_MOC_LITERAL(599, 4),  // "Tile"
        QT_MOC_LITERAL(604, 6),  // "Center"
        QT_MOC_LITERAL(611, 4),  // "Span"
        QT_MOC_LITERAL(616, 10),  // "WindowEdge"
        QT_MOC_LITERAL(627, 4),  // "Left"
        QT_MOC_LITERAL(632, 3),  // "Top"
        QT_MOC_LITERAL(636, 5),  // "Right"
        QT_MOC_LITERAL(642, 6),  // "Bottom"
        QT_MOC_LITERAL(649, 11),  // "WindowEdges"
        QT_MOC_LITERAL(661, 17),  // "WindowCornerStyle"
        QT_MOC_LITERAL(679, 6),  // "Square"
        QT_MOC_LITERAL(686, 5)   // "Round"
    },
    "wangwenx190::FramelessHelper::Global",
    "Option",
    "UseCrossPlatformQtImplementation",
    "ForceHideWindowFrameBorder",
    "ForceShowWindowFrameBorder",
    "DisableWindowsSnapLayout",
    "WindowUseRoundCorners",
    "CenterWindowBeforeShow",
    "EnableBlurBehindWindow",
    "ForceNonNativeBackgroundBlur",
    "DisableLazyInitializationForMicaMaterial",
    "ForceNativeBackgroundBlur",
    "Last",
    "SystemTheme",
    "Unknown",
    "Light",
    "Dark",
    "HighContrast",
    "SystemButtonType",
    "WindowIcon",
    "Help",
    "Minimize",
    "Maximize",
    "Restore",
    "Close",
    "ButtonState",
    "Normal",
    "Hovered",
    "Pressed",
    "Released",
    "BlurMode",
    "Disable",
    "Default",
    "Windows_Aero",
    "Windows_Acrylic",
    "Windows_Mica",
    "Windows_MicaAlt",
    "WallpaperAspectStyle",
    "Fill",
    "Fit",
    "Stretch",
    "Tile",
    "Center",
    "Span",
    "WindowEdge",
    "Left",
    "Top",
    "Right",
    "Bottom",
    "WindowEdges",
    "WindowCornerStyle",
    "Square",
    "Round"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEGlobalENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       9,   14, // enums/sets
       0,    0, // constructors
       4,       // flags
       0,       // signalCount

 // enums: name, alias, flags, count, data
       1,    1, 0x2,   11,   59,
      13,   13, 0x2,    4,   81,
      18,   18, 0x2,    8,   89,
      25,   25, 0x2,    4,  105,
      30,   30, 0x2,    6,  113,
      37,   37, 0x2,    6,  125,
      44,   44, 0x2,    4,  137,
      49,   44, 0x3,    4,  145,
      50,   50, 0x2,    3,  153,

 // enum data: key, value
       2, uint(wangwenx190::FramelessHelper::Global::Option::UseCrossPlatformQtImplementation),
       3, uint(wangwenx190::FramelessHelper::Global::Option::ForceHideWindowFrameBorder),
       4, uint(wangwenx190::FramelessHelper::Global::Option::ForceShowWindowFrameBorder),
       5, uint(wangwenx190::FramelessHelper::Global::Option::DisableWindowsSnapLayout),
       6, uint(wangwenx190::FramelessHelper::Global::Option::WindowUseRoundCorners),
       7, uint(wangwenx190::FramelessHelper::Global::Option::CenterWindowBeforeShow),
       8, uint(wangwenx190::FramelessHelper::Global::Option::EnableBlurBehindWindow),
       9, uint(wangwenx190::FramelessHelper::Global::Option::ForceNonNativeBackgroundBlur),
      10, uint(wangwenx190::FramelessHelper::Global::Option::DisableLazyInitializationForMicaMaterial),
      11, uint(wangwenx190::FramelessHelper::Global::Option::ForceNativeBackgroundBlur),
      12, uint(wangwenx190::FramelessHelper::Global::Option::Last),
      14, uint(wangwenx190::FramelessHelper::Global::SystemTheme::Unknown),
      15, uint(wangwenx190::FramelessHelper::Global::SystemTheme::Light),
      16, uint(wangwenx190::FramelessHelper::Global::SystemTheme::Dark),
      17, uint(wangwenx190::FramelessHelper::Global::SystemTheme::HighContrast),
      14, uint(wangwenx190::FramelessHelper::Global::SystemButtonType::Unknown),
      19, uint(wangwenx190::FramelessHelper::Global::SystemButtonType::WindowIcon),
      20, uint(wangwenx190::FramelessHelper::Global::SystemButtonType::Help),
      21, uint(wangwenx190::FramelessHelper::Global::SystemButtonType::Minimize),
      22, uint(wangwenx190::FramelessHelper::Global::SystemButtonType::Maximize),
      23, uint(wangwenx190::FramelessHelper::Global::SystemButtonType::Restore),
      24, uint(wangwenx190::FramelessHelper::Global::SystemButtonType::Close),
      12, uint(wangwenx190::FramelessHelper::Global::SystemButtonType::Last),
      26, uint(wangwenx190::FramelessHelper::Global::ButtonState::Normal),
      27, uint(wangwenx190::FramelessHelper::Global::ButtonState::Hovered),
      28, uint(wangwenx190::FramelessHelper::Global::ButtonState::Pressed),
      29, uint(wangwenx190::FramelessHelper::Global::ButtonState::Released),
      31, uint(wangwenx190::FramelessHelper::Global::BlurMode::Disable),
      32, uint(wangwenx190::FramelessHelper::Global::BlurMode::Default),
      33, uint(wangwenx190::FramelessHelper::Global::BlurMode::Windows_Aero),
      34, uint(wangwenx190::FramelessHelper::Global::BlurMode::Windows_Acrylic),
      35, uint(wangwenx190::FramelessHelper::Global::BlurMode::Windows_Mica),
      36, uint(wangwenx190::FramelessHelper::Global::BlurMode::Windows_MicaAlt),
      38, uint(wangwenx190::FramelessHelper::Global::WallpaperAspectStyle::Fill),
      39, uint(wangwenx190::FramelessHelper::Global::WallpaperAspectStyle::Fit),
      40, uint(wangwenx190::FramelessHelper::Global::WallpaperAspectStyle::Stretch),
      41, uint(wangwenx190::FramelessHelper::Global::WallpaperAspectStyle::Tile),
      42, uint(wangwenx190::FramelessHelper::Global::WallpaperAspectStyle::Center),
      43, uint(wangwenx190::FramelessHelper::Global::WallpaperAspectStyle::Span),
      45, uint(wangwenx190::FramelessHelper::Global::WindowEdge::Left),
      46, uint(wangwenx190::FramelessHelper::Global::WindowEdge::Top),
      47, uint(wangwenx190::FramelessHelper::Global::WindowEdge::Right),
      48, uint(wangwenx190::FramelessHelper::Global::WindowEdge::Bottom),
      45, uint(wangwenx190::FramelessHelper::Global::WindowEdge::Left),
      46, uint(wangwenx190::FramelessHelper::Global::WindowEdge::Top),
      47, uint(wangwenx190::FramelessHelper::Global::WindowEdge::Right),
      48, uint(wangwenx190::FramelessHelper::Global::WindowEdge::Bottom),
      32, uint(wangwenx190::FramelessHelper::Global::WindowCornerStyle::Default),
      51, uint(wangwenx190::FramelessHelper::Global::WindowCornerStyle::Square),
      52, uint(wangwenx190::FramelessHelper::Global::WindowCornerStyle::Round),

       0        // eod
};

Q_CONSTINIT const QMetaObject wangwenx190::FramelessHelper::Global::staticMetaObject = { {
    nullptr,
    qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEGlobalENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEGlobalENDCLASS,
    nullptr,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEGlobalENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<void, std::true_type>
    >,
    nullptr
} };

QT_WARNING_POP
