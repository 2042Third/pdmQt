/****************************************************************************
** Meta object code from reading C++ file 'micamaterial.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../framelesshelper/include/FramelessHelper/Core/micamaterial.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'micamaterial.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS = QtMocHelpers::stringData(
    "wangwenx190::FramelessHelper::MicaMaterial",
    "tintColorChanged",
    "",
    "tintOpacityChanged",
    "fallbackColorChanged",
    "noiseOpacityChanged",
    "fallbackEnabledChanged",
    "shouldRedraw",
    "paint",
    "QPainter*",
    "painter",
    "rect",
    "active",
    "size",
    "pos",
    "tintColor",
    "tintOpacity",
    "fallbackColor",
    "noiseOpacity",
    "fallbackEnabled"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS_t {
    uint offsetsAndSizes[40];
    char stringdata0[43];
    char stringdata1[17];
    char stringdata2[1];
    char stringdata3[19];
    char stringdata4[21];
    char stringdata5[20];
    char stringdata6[23];
    char stringdata7[13];
    char stringdata8[6];
    char stringdata9[10];
    char stringdata10[8];
    char stringdata11[5];
    char stringdata12[7];
    char stringdata13[5];
    char stringdata14[4];
    char stringdata15[10];
    char stringdata16[12];
    char stringdata17[14];
    char stringdata18[13];
    char stringdata19[16];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS_t qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS = {
    {
        QT_MOC_LITERAL(0, 42),  // "wangwenx190::FramelessHelper:..."
        QT_MOC_LITERAL(43, 16),  // "tintColorChanged"
        QT_MOC_LITERAL(60, 0),  // ""
        QT_MOC_LITERAL(61, 18),  // "tintOpacityChanged"
        QT_MOC_LITERAL(80, 20),  // "fallbackColorChanged"
        QT_MOC_LITERAL(101, 19),  // "noiseOpacityChanged"
        QT_MOC_LITERAL(121, 22),  // "fallbackEnabledChanged"
        QT_MOC_LITERAL(144, 12),  // "shouldRedraw"
        QT_MOC_LITERAL(157, 5),  // "paint"
        QT_MOC_LITERAL(163, 9),  // "QPainter*"
        QT_MOC_LITERAL(173, 7),  // "painter"
        QT_MOC_LITERAL(181, 4),  // "rect"
        QT_MOC_LITERAL(186, 6),  // "active"
        QT_MOC_LITERAL(193, 4),  // "size"
        QT_MOC_LITERAL(198, 3),  // "pos"
        QT_MOC_LITERAL(202, 9),  // "tintColor"
        QT_MOC_LITERAL(212, 11),  // "tintOpacity"
        QT_MOC_LITERAL(224, 13),  // "fallbackColor"
        QT_MOC_LITERAL(238, 12),  // "noiseOpacity"
        QT_MOC_LITERAL(251, 15)   // "fallbackEnabled"
    },
    "wangwenx190::FramelessHelper::MicaMaterial",
    "tintColorChanged",
    "",
    "tintOpacityChanged",
    "fallbackColorChanged",
    "noiseOpacityChanged",
    "fallbackEnabledChanged",
    "shouldRedraw",
    "paint",
    "QPainter*",
    "painter",
    "rect",
    "active",
    "size",
    "pos",
    "tintColor",
    "tintOpacity",
    "fallbackColor",
    "noiseOpacity",
    "fallbackEnabled"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       5,  108, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   74,    2, 0x06,    6 /* Public */,
       3,    0,   75,    2, 0x06,    7 /* Public */,
       4,    0,   76,    2, 0x06,    8 /* Public */,
       5,    0,   77,    2, 0x06,    9 /* Public */,
       6,    0,   78,    2, 0x06,   10 /* Public */,
       7,    0,   79,    2, 0x06,   11 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       8,    3,   80,    2, 0x0a,   12 /* Public */,
       8,    2,   87,    2, 0x2a,   16 /* Public | MethodCloned */,
       8,    4,   92,    2, 0x0a,   19 /* Public */,
       8,    3,  101,    2, 0x2a,   24 /* Public | MethodCloned */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 9, QMetaType::QRect, QMetaType::Bool,   10,   11,   12,
    QMetaType::Void, 0x80000000 | 9, QMetaType::QRect,   10,   11,
    QMetaType::Void, 0x80000000 | 9, QMetaType::QSize, QMetaType::QPoint, QMetaType::Bool,   10,   13,   14,   12,
    QMetaType::Void, 0x80000000 | 9, QMetaType::QSize, QMetaType::QPoint,   10,   13,   14,

 // properties: name, type, flags
      15, QMetaType::QColor, 0x00015903, uint(0), 0,
      16, QMetaType::QReal, 0x00015903, uint(1), 0,
      17, QMetaType::QColor, 0x00015903, uint(2), 0,
      18, QMetaType::QReal, 0x00015903, uint(3), 0,
      19, QMetaType::Bool, 0x00015903, uint(4), 0,

       0        // eod
};

Q_CONSTINIT const QMetaObject wangwenx190::FramelessHelper::MicaMaterial::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS_t,
        // property 'tintColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'tintOpacity'
        QtPrivate::TypeAndForceComplete<qreal, std::true_type>,
        // property 'fallbackColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'noiseOpacity'
        QtPrivate::TypeAndForceComplete<qreal, std::true_type>,
        // property 'fallbackEnabled'
        QtPrivate::TypeAndForceComplete<bool, std::true_type>,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MicaMaterial, std::true_type>,
        // method 'tintColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'tintOpacityChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'fallbackColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'noiseOpacityChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'fallbackEnabledChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'shouldRedraw'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'paint'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPainter *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QRect &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const bool, std::false_type>,
        // method 'paint'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPainter *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QRect &, std::false_type>,
        // method 'paint'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPainter *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QSize &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QPoint &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const bool, std::false_type>,
        // method 'paint'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPainter *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QSize &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QPoint &, std::false_type>
    >,
    nullptr
} };

void wangwenx190::FramelessHelper::MicaMaterial::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MicaMaterial *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->tintColorChanged(); break;
        case 1: _t->tintOpacityChanged(); break;
        case 2: _t->fallbackColorChanged(); break;
        case 3: _t->noiseOpacityChanged(); break;
        case 4: _t->fallbackEnabledChanged(); break;
        case 5: _t->shouldRedraw(); break;
        case 6: _t->paint((*reinterpret_cast< std::add_pointer_t<QPainter*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QRect>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[3]))); break;
        case 7: _t->paint((*reinterpret_cast< std::add_pointer_t<QPainter*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QRect>>(_a[2]))); break;
        case 8: _t->paint((*reinterpret_cast< std::add_pointer_t<QPainter*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QSize>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QPoint>>(_a[3])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[4]))); break;
        case 9: _t->paint((*reinterpret_cast< std::add_pointer_t<QPainter*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QSize>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QPoint>>(_a[3]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MicaMaterial::*)();
            if (_t _q_method = &MicaMaterial::tintColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (MicaMaterial::*)();
            if (_t _q_method = &MicaMaterial::tintOpacityChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (MicaMaterial::*)();
            if (_t _q_method = &MicaMaterial::fallbackColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (MicaMaterial::*)();
            if (_t _q_method = &MicaMaterial::noiseOpacityChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (MicaMaterial::*)();
            if (_t _q_method = &MicaMaterial::fallbackEnabledChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (MicaMaterial::*)();
            if (_t _q_method = &MicaMaterial::shouldRedraw; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
    }else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<MicaMaterial *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QColor*>(_v) = _t->tintColor(); break;
        case 1: *reinterpret_cast< qreal*>(_v) = _t->tintOpacity(); break;
        case 2: *reinterpret_cast< QColor*>(_v) = _t->fallbackColor(); break;
        case 3: *reinterpret_cast< qreal*>(_v) = _t->noiseOpacity(); break;
        case 4: *reinterpret_cast< bool*>(_v) = _t->isFallbackEnabled(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<MicaMaterial *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setTintColor(*reinterpret_cast< QColor*>(_v)); break;
        case 1: _t->setTintOpacity(*reinterpret_cast< qreal*>(_v)); break;
        case 2: _t->setFallbackColor(*reinterpret_cast< QColor*>(_v)); break;
        case 3: _t->setNoiseOpacity(*reinterpret_cast< qreal*>(_v)); break;
        case 4: _t->setFallbackEnabled(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    } else if (_c == QMetaObject::BindableProperty) {
    }
}

const QMetaObject *wangwenx190::FramelessHelper::MicaMaterial::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *wangwenx190::FramelessHelper::MicaMaterial::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int wangwenx190::FramelessHelper::MicaMaterial::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 10;
    }else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void wangwenx190::FramelessHelper::MicaMaterial::tintColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void wangwenx190::FramelessHelper::MicaMaterial::tintOpacityChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void wangwenx190::FramelessHelper::MicaMaterial::fallbackColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void wangwenx190::FramelessHelper::MicaMaterial::noiseOpacityChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void wangwenx190::FramelessHelper::MicaMaterial::fallbackEnabledChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void wangwenx190::FramelessHelper::MicaMaterial::shouldRedraw()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}
QT_WARNING_POP
