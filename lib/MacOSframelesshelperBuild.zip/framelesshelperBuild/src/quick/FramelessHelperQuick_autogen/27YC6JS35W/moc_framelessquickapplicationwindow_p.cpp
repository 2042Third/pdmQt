/****************************************************************************
** Meta object code from reading C++ file 'framelessquickapplicationwindow_p.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../framelesshelper/include/FramelessHelper/Quick/private/framelessquickapplicationwindow_p.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'framelessquickapplicationwindow_p.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickApplicationWindowENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickApplicationWindowENDCLASS = QtMocHelpers::stringData(
    "wangwenx190::FramelessHelper::FramelessQuickApplicationWindow",
    "QML.Element",
    "FramelessApplicationWindow",
    "hiddenChanged",
    "",
    "normalChanged",
    "minimizedChanged",
    "maximizedChanged",
    "zoomedChanged",
    "fullScreenChanged",
    "showMinimized2",
    "toggleMaximized",
    "toggleFullScreen",
    "hidden",
    "normal",
    "minimized",
    "maximized",
    "zoomed",
    "fullScreen"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickApplicationWindowENDCLASS_t {
    uint offsetsAndSizes[38];
    char stringdata0[62];
    char stringdata1[12];
    char stringdata2[27];
    char stringdata3[14];
    char stringdata4[1];
    char stringdata5[14];
    char stringdata6[17];
    char stringdata7[17];
    char stringdata8[14];
    char stringdata9[18];
    char stringdata10[15];
    char stringdata11[16];
    char stringdata12[17];
    char stringdata13[7];
    char stringdata14[7];
    char stringdata15[10];
    char stringdata16[10];
    char stringdata17[7];
    char stringdata18[11];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickApplicationWindowENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickApplicationWindowENDCLASS_t qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickApplicationWindowENDCLASS = {
    {
        QT_MOC_LITERAL(0, 61),  // "wangwenx190::FramelessHelper:..."
        QT_MOC_LITERAL(62, 11),  // "QML.Element"
        QT_MOC_LITERAL(74, 26),  // "FramelessApplicationWindow"
        QT_MOC_LITERAL(101, 13),  // "hiddenChanged"
        QT_MOC_LITERAL(115, 0),  // ""
        QT_MOC_LITERAL(116, 13),  // "normalChanged"
        QT_MOC_LITERAL(130, 16),  // "minimizedChanged"
        QT_MOC_LITERAL(147, 16),  // "maximizedChanged"
        QT_MOC_LITERAL(164, 13),  // "zoomedChanged"
        QT_MOC_LITERAL(178, 17),  // "fullScreenChanged"
        QT_MOC_LITERAL(196, 14),  // "showMinimized2"
        QT_MOC_LITERAL(211, 15),  // "toggleMaximized"
        QT_MOC_LITERAL(227, 16),  // "toggleFullScreen"
        QT_MOC_LITERAL(244, 6),  // "hidden"
        QT_MOC_LITERAL(251, 6),  // "normal"
        QT_MOC_LITERAL(258, 9),  // "minimized"
        QT_MOC_LITERAL(268, 9),  // "maximized"
        QT_MOC_LITERAL(278, 6),  // "zoomed"
        QT_MOC_LITERAL(285, 10)   // "fullScreen"
    },
    "wangwenx190::FramelessHelper::FramelessQuickApplicationWindow",
    "QML.Element",
    "FramelessApplicationWindow",
    "hiddenChanged",
    "",
    "normalChanged",
    "minimizedChanged",
    "maximizedChanged",
    "zoomedChanged",
    "fullScreenChanged",
    "showMinimized2",
    "toggleMaximized",
    "toggleFullScreen",
    "hidden",
    "normal",
    "minimized",
    "maximized",
    "zoomed",
    "fullScreen"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickApplicationWindowENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       1,   14, // classinfo
       9,   16, // methods
       6,   79, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // classinfo: key, value
       1,    2,

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       3,    0,   70,    4, 0x06,    7 /* Public */,
       5,    0,   71,    4, 0x06,    8 /* Public */,
       6,    0,   72,    4, 0x06,    9 /* Public */,
       7,    0,   73,    4, 0x06,   10 /* Public */,
       8,    0,   74,    4, 0x06,   11 /* Public */,
       9,    0,   75,    4, 0x06,   12 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      10,    0,   76,    4, 0x0a,   13 /* Public */,
      11,    0,   77,    4, 0x0a,   14 /* Public */,
      12,    0,   78,    4, 0x0a,   15 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // properties: name, type, flags
      13, QMetaType::Bool, 0x00015801, uint(0), 0,
      14, QMetaType::Bool, 0x00015801, uint(1), 0,
      15, QMetaType::Bool, 0x00015801, uint(2), 0,
      16, QMetaType::Bool, 0x00015801, uint(3), 0,
      17, QMetaType::Bool, 0x00015801, uint(4), 0,
      18, QMetaType::Bool, 0x00015801, uint(5), 0,

       0        // eod
};

Q_CONSTINIT const QMetaObject wangwenx190::FramelessHelper::FramelessQuickApplicationWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QQuickApplicationWindow::staticMetaObject>(),
    qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickApplicationWindowENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickApplicationWindowENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_metaTypeArray<
        // property 'hidden'
        bool,
        // property 'normal'
        bool,
        // property 'minimized'
        bool,
        // property 'maximized'
        bool,
        // property 'zoomed'
        bool,
        // property 'fullScreen'
        bool,
        // Q_OBJECT / Q_GADGET
        FramelessQuickApplicationWindow,
        // method 'hiddenChanged'
        void,
        // method 'normalChanged'
        void,
        // method 'minimizedChanged'
        void,
        // method 'maximizedChanged'
        void,
        // method 'zoomedChanged'
        void,
        // method 'fullScreenChanged'
        void,
        // method 'showMinimized2'
        void,
        // method 'toggleMaximized'
        void,
        // method 'toggleFullScreen'
        void
    >,
    nullptr
} };

void wangwenx190::FramelessHelper::FramelessQuickApplicationWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<FramelessQuickApplicationWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->hiddenChanged(); break;
        case 1: _t->normalChanged(); break;
        case 2: _t->minimizedChanged(); break;
        case 3: _t->maximizedChanged(); break;
        case 4: _t->zoomedChanged(); break;
        case 5: _t->fullScreenChanged(); break;
        case 6: _t->showMinimized2(); break;
        case 7: _t->toggleMaximized(); break;
        case 8: _t->toggleFullScreen(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (FramelessQuickApplicationWindow::*)();
            if (_t _q_method = &FramelessQuickApplicationWindow::hiddenChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (FramelessQuickApplicationWindow::*)();
            if (_t _q_method = &FramelessQuickApplicationWindow::normalChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (FramelessQuickApplicationWindow::*)();
            if (_t _q_method = &FramelessQuickApplicationWindow::minimizedChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (FramelessQuickApplicationWindow::*)();
            if (_t _q_method = &FramelessQuickApplicationWindow::maximizedChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (FramelessQuickApplicationWindow::*)();
            if (_t _q_method = &FramelessQuickApplicationWindow::zoomedChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (FramelessQuickApplicationWindow::*)();
            if (_t _q_method = &FramelessQuickApplicationWindow::fullScreenChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
    }else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<FramelessQuickApplicationWindow *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = _t->isHidden(); break;
        case 1: *reinterpret_cast< bool*>(_v) = _t->isNormal(); break;
        case 2: *reinterpret_cast< bool*>(_v) = _t->isMinimized(); break;
        case 3: *reinterpret_cast< bool*>(_v) = _t->isMaximized(); break;
        case 4: *reinterpret_cast< bool*>(_v) = _t->isZoomed(); break;
        case 5: *reinterpret_cast< bool*>(_v) = _t->isFullScreen(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
    } else if (_c == QMetaObject::ResetProperty) {
    } else if (_c == QMetaObject::BindableProperty) {
    }
    (void)_a;
}

const QMetaObject *wangwenx190::FramelessHelper::FramelessQuickApplicationWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *wangwenx190::FramelessHelper::FramelessQuickApplicationWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickApplicationWindowENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QQuickApplicationWindow::qt_metacast(_clname);
}

int wangwenx190::FramelessHelper::FramelessQuickApplicationWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QQuickApplicationWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 9;
    }else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    }
    return _id;
}

// SIGNAL 0
void wangwenx190::FramelessHelper::FramelessQuickApplicationWindow::hiddenChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void wangwenx190::FramelessHelper::FramelessQuickApplicationWindow::normalChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void wangwenx190::FramelessHelper::FramelessQuickApplicationWindow::minimizedChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void wangwenx190::FramelessHelper::FramelessQuickApplicationWindow::maximizedChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void wangwenx190::FramelessHelper::FramelessQuickApplicationWindow::zoomedChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void wangwenx190::FramelessHelper::FramelessQuickApplicationWindow::fullScreenChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}
QT_WARNING_POP
