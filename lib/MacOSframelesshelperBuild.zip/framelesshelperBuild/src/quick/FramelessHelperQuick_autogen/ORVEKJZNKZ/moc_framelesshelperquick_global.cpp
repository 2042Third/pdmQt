/****************************************************************************
** Meta object code from reading C++ file 'framelesshelperquick_global.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../framelesshelper/include/FramelessHelper/Quick/framelesshelperquick_global.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'framelesshelperquick_global.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickGlobalENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickGlobalENDCLASS = QtMocHelpers::stringData(
    "wangwenx190::FramelessHelper::QuickGlobal",
    "QML.Element",
    "FramelessHelperConstants",
    "QML.Creatable",
    "false",
    "QML.UncreatableReason",
    "The FramelessHelperConstants namespace is not creatable, you can only "
    "use it to access it's enums.",
    "SystemTheme",
    "Unknown",
    "Light",
    "Dark",
    "HighContrast",
    "SystemButtonType",
    "WindowIcon",
    "Help",
    "Minimize",
    "Maximize",
    "Restore",
    "Close",
    "ButtonState",
    "Normal",
    "Hovered",
    "Pressed",
    "Released",
    "BlurMode",
    "Disable",
    "Default",
    "Windows_Aero",
    "Windows_Acrylic",
    "Windows_Mica",
    "Windows_MicaAlt",
    "WindowEdge",
    "Left",
    "Top",
    "Right",
    "Bottom",
    "WindowEdges"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickGlobalENDCLASS_t {
    uint offsetsAndSizes[74];
    char stringdata0[42];
    char stringdata1[12];
    char stringdata2[25];
    char stringdata3[14];
    char stringdata4[6];
    char stringdata5[22];
    char stringdata6[99];
    char stringdata7[12];
    char stringdata8[8];
    char stringdata9[6];
    char stringdata10[5];
    char stringdata11[13];
    char stringdata12[17];
    char stringdata13[11];
    char stringdata14[5];
    char stringdata15[9];
    char stringdata16[9];
    char stringdata17[8];
    char stringdata18[6];
    char stringdata19[12];
    char stringdata20[7];
    char stringdata21[8];
    char stringdata22[8];
    char stringdata23[9];
    char stringdata24[9];
    char stringdata25[8];
    char stringdata26[8];
    char stringdata27[13];
    char stringdata28[16];
    char stringdata29[13];
    char stringdata30[16];
    char stringdata31[11];
    char stringdata32[5];
    char stringdata33[4];
    char stringdata34[6];
    char stringdata35[7];
    char stringdata36[12];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickGlobalENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickGlobalENDCLASS_t qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickGlobalENDCLASS = {
    {
        QT_MOC_LITERAL(0, 41),  // "wangwenx190::FramelessHelper:..."
        QT_MOC_LITERAL(42, 11),  // "QML.Element"
        QT_MOC_LITERAL(54, 24),  // "FramelessHelperConstants"
        QT_MOC_LITERAL(79, 13),  // "QML.Creatable"
        QT_MOC_LITERAL(93, 5),  // "false"
        QT_MOC_LITERAL(99, 21),  // "QML.UncreatableReason"
        QT_MOC_LITERAL(121, 98),  // "The FramelessHelperConstants ..."
        QT_MOC_LITERAL(220, 11),  // "SystemTheme"
        QT_MOC_LITERAL(232, 7),  // "Unknown"
        QT_MOC_LITERAL(240, 5),  // "Light"
        QT_MOC_LITERAL(246, 4),  // "Dark"
        QT_MOC_LITERAL(251, 12),  // "HighContrast"
        QT_MOC_LITERAL(264, 16),  // "SystemButtonType"
        QT_MOC_LITERAL(281, 10),  // "WindowIcon"
        QT_MOC_LITERAL(292, 4),  // "Help"
        QT_MOC_LITERAL(297, 8),  // "Minimize"
        QT_MOC_LITERAL(306, 8),  // "Maximize"
        QT_MOC_LITERAL(315, 7),  // "Restore"
        QT_MOC_LITERAL(323, 5),  // "Close"
        QT_MOC_LITERAL(329, 11),  // "ButtonState"
        QT_MOC_LITERAL(341, 6),  // "Normal"
        QT_MOC_LITERAL(348, 7),  // "Hovered"
        QT_MOC_LITERAL(356, 7),  // "Pressed"
        QT_MOC_LITERAL(364, 8),  // "Released"
        QT_MOC_LITERAL(373, 8),  // "BlurMode"
        QT_MOC_LITERAL(382, 7),  // "Disable"
        QT_MOC_LITERAL(390, 7),  // "Default"
        QT_MOC_LITERAL(398, 12),  // "Windows_Aero"
        QT_MOC_LITERAL(411, 15),  // "Windows_Acrylic"
        QT_MOC_LITERAL(427, 12),  // "Windows_Mica"
        QT_MOC_LITERAL(440, 15),  // "Windows_MicaAlt"
        QT_MOC_LITERAL(456, 10),  // "WindowEdge"
        QT_MOC_LITERAL(467, 4),  // "Left"
        QT_MOC_LITERAL(472, 3),  // "Top"
        QT_MOC_LITERAL(476, 5),  // "Right"
        QT_MOC_LITERAL(482, 6),  // "Bottom"
        QT_MOC_LITERAL(489, 11)   // "WindowEdges"
    },
    "wangwenx190::FramelessHelper::QuickGlobal",
    "QML.Element",
    "FramelessHelperConstants",
    "QML.Creatable",
    "false",
    "QML.UncreatableReason",
    "The FramelessHelperConstants namespace is not creatable, you can only "
    "use it to access it's enums.",
    "SystemTheme",
    "Unknown",
    "Light",
    "Dark",
    "HighContrast",
    "SystemButtonType",
    "WindowIcon",
    "Help",
    "Minimize",
    "Maximize",
    "Restore",
    "Close",
    "ButtonState",
    "Normal",
    "Hovered",
    "Pressed",
    "Released",
    "BlurMode",
    "Disable",
    "Default",
    "Windows_Aero",
    "Windows_Acrylic",
    "Windows_Mica",
    "Windows_MicaAlt",
    "WindowEdge",
    "Left",
    "Top",
    "Right",
    "Bottom",
    "WindowEdges"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickGlobalENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       3,   14, // classinfo
       0,    0, // methods
       0,    0, // properties
       6,   20, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // classinfo: key, value
       1,    2,
       3,    4,
       5,    6,

 // enums: name, alias, flags, count, data
       7,    7, 0x2,    4,   50,
      12,   12, 0x2,    7,   58,
      19,   19, 0x2,    4,   72,
      24,   24, 0x2,    6,   80,
      31,   31, 0x2,    4,   92,
      36,   31, 0x3,    4,  100,

 // enum data: key, value
       8, uint(wangwenx190::FramelessHelper::QuickGlobal::SystemTheme::Unknown),
       9, uint(wangwenx190::FramelessHelper::QuickGlobal::SystemTheme::Light),
      10, uint(wangwenx190::FramelessHelper::QuickGlobal::SystemTheme::Dark),
      11, uint(wangwenx190::FramelessHelper::QuickGlobal::SystemTheme::HighContrast),
       8, uint(wangwenx190::FramelessHelper::QuickGlobal::SystemButtonType::Unknown),
      13, uint(wangwenx190::FramelessHelper::QuickGlobal::SystemButtonType::WindowIcon),
      14, uint(wangwenx190::FramelessHelper::QuickGlobal::SystemButtonType::Help),
      15, uint(wangwenx190::FramelessHelper::QuickGlobal::SystemButtonType::Minimize),
      16, uint(wangwenx190::FramelessHelper::QuickGlobal::SystemButtonType::Maximize),
      17, uint(wangwenx190::FramelessHelper::QuickGlobal::SystemButtonType::Restore),
      18, uint(wangwenx190::FramelessHelper::QuickGlobal::SystemButtonType::Close),
      20, uint(wangwenx190::FramelessHelper::QuickGlobal::ButtonState::Normal),
      21, uint(wangwenx190::FramelessHelper::QuickGlobal::ButtonState::Hovered),
      22, uint(wangwenx190::FramelessHelper::QuickGlobal::ButtonState::Pressed),
      23, uint(wangwenx190::FramelessHelper::QuickGlobal::ButtonState::Released),
      25, uint(wangwenx190::FramelessHelper::QuickGlobal::BlurMode::Disable),
      26, uint(wangwenx190::FramelessHelper::QuickGlobal::BlurMode::Default),
      27, uint(wangwenx190::FramelessHelper::QuickGlobal::BlurMode::Windows_Aero),
      28, uint(wangwenx190::FramelessHelper::QuickGlobal::BlurMode::Windows_Acrylic),
      29, uint(wangwenx190::FramelessHelper::QuickGlobal::BlurMode::Windows_Mica),
      30, uint(wangwenx190::FramelessHelper::QuickGlobal::BlurMode::Windows_MicaAlt),
      32, uint(wangwenx190::FramelessHelper::QuickGlobal::WindowEdge::Left),
      33, uint(wangwenx190::FramelessHelper::QuickGlobal::WindowEdge::Top),
      34, uint(wangwenx190::FramelessHelper::QuickGlobal::WindowEdge::Right),
      35, uint(wangwenx190::FramelessHelper::QuickGlobal::WindowEdge::Bottom),
      32, uint(wangwenx190::FramelessHelper::QuickGlobal::WindowEdge::Left),
      33, uint(wangwenx190::FramelessHelper::QuickGlobal::WindowEdge::Top),
      34, uint(wangwenx190::FramelessHelper::QuickGlobal::WindowEdge::Right),
      35, uint(wangwenx190::FramelessHelper::QuickGlobal::WindowEdge::Bottom),

       0        // eod
};

Q_CONSTINIT const QMetaObject wangwenx190::FramelessHelper::QuickGlobal::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickGlobalENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickGlobalENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_metaTypeArray<
        // Q_OBJECT / Q_GADGET
        QuickGlobal
    >,
    nullptr
} };

void wangwenx190::FramelessHelper::QuickGlobal::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    (void)_o;
    (void)_id;
    (void)_c;
    (void)_a;
}

const QMetaObject *wangwenx190::FramelessHelper::QuickGlobal::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *wangwenx190::FramelessHelper::QuickGlobal::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickGlobalENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int wangwenx190::FramelessHelper::QuickGlobal::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    return _id;
}
QT_WARNING_POP
