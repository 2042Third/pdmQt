/****************************************************************************
** Meta object code from reading C++ file 'quickmicamaterial.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../framelesshelper/include/FramelessHelper/Quick/quickmicamaterial.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'quickmicamaterial.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickMicaMaterialENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickMicaMaterialENDCLASS = QtMocHelpers::stringData(
    "wangwenx190::FramelessHelper::QuickMicaMaterial",
    "QML.Element",
    "MicaMaterial",
    "tintColorChanged",
    "",
    "tintOpacityChanged",
    "fallbackColorChanged",
    "noiseOpacityChanged",
    "fallbackEnabledChanged",
    "tintColor",
    "tintOpacity",
    "fallbackColor",
    "noiseOpacity",
    "fallbackEnabled"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickMicaMaterialENDCLASS_t {
    uint offsetsAndSizes[28];
    char stringdata0[48];
    char stringdata1[12];
    char stringdata2[13];
    char stringdata3[17];
    char stringdata4[1];
    char stringdata5[19];
    char stringdata6[21];
    char stringdata7[20];
    char stringdata8[23];
    char stringdata9[10];
    char stringdata10[12];
    char stringdata11[14];
    char stringdata12[13];
    char stringdata13[16];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickMicaMaterialENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickMicaMaterialENDCLASS_t qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickMicaMaterialENDCLASS = {
    {
        QT_MOC_LITERAL(0, 47),  // "wangwenx190::FramelessHelper:..."
        QT_MOC_LITERAL(48, 11),  // "QML.Element"
        QT_MOC_LITERAL(60, 12),  // "MicaMaterial"
        QT_MOC_LITERAL(73, 16),  // "tintColorChanged"
        QT_MOC_LITERAL(90, 0),  // ""
        QT_MOC_LITERAL(91, 18),  // "tintOpacityChanged"
        QT_MOC_LITERAL(110, 20),  // "fallbackColorChanged"
        QT_MOC_LITERAL(131, 19),  // "noiseOpacityChanged"
        QT_MOC_LITERAL(151, 22),  // "fallbackEnabledChanged"
        QT_MOC_LITERAL(174, 9),  // "tintColor"
        QT_MOC_LITERAL(184, 11),  // "tintOpacity"
        QT_MOC_LITERAL(196, 13),  // "fallbackColor"
        QT_MOC_LITERAL(210, 12),  // "noiseOpacity"
        QT_MOC_LITERAL(223, 15)   // "fallbackEnabled"
    },
    "wangwenx190::FramelessHelper::QuickMicaMaterial",
    "QML.Element",
    "MicaMaterial",
    "tintColorChanged",
    "",
    "tintOpacityChanged",
    "fallbackColorChanged",
    "noiseOpacityChanged",
    "fallbackEnabledChanged",
    "tintColor",
    "tintOpacity",
    "fallbackColor",
    "noiseOpacity",
    "fallbackEnabled"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickMicaMaterialENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       1,   14, // classinfo
       5,   16, // methods
       5,   51, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // classinfo: key, value
       1,    2,

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       3,    0,   46,    4, 0x06,    6 /* Public */,
       5,    0,   47,    4, 0x06,    7 /* Public */,
       6,    0,   48,    4, 0x06,    8 /* Public */,
       7,    0,   49,    4, 0x06,    9 /* Public */,
       8,    0,   50,    4, 0x06,   10 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // properties: name, type, flags
       9, QMetaType::QColor, 0x00015903, uint(0), 0,
      10, QMetaType::QReal, 0x00015903, uint(1), 0,
      11, QMetaType::QColor, 0x00015903, uint(2), 0,
      12, QMetaType::QReal, 0x00015903, uint(3), 0,
      13, QMetaType::Bool, 0x00015903, uint(4), 0,

       0        // eod
};

Q_CONSTINIT const QMetaObject wangwenx190::FramelessHelper::QuickMicaMaterial::staticMetaObject = { {
    QMetaObject::SuperData::link<QQuickPaintedItem::staticMetaObject>(),
    qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickMicaMaterialENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickMicaMaterialENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_metaTypeArray<
        // property 'tintColor'
        QColor,
        // property 'tintOpacity'
        qreal,
        // property 'fallbackColor'
        QColor,
        // property 'noiseOpacity'
        qreal,
        // property 'fallbackEnabled'
        bool,
        // Q_OBJECT / Q_GADGET
        QuickMicaMaterial,
        // method 'tintColorChanged'
        void,
        // method 'tintOpacityChanged'
        void,
        // method 'fallbackColorChanged'
        void,
        // method 'noiseOpacityChanged'
        void,
        // method 'fallbackEnabledChanged'
        void
    >,
    nullptr
} };

void wangwenx190::FramelessHelper::QuickMicaMaterial::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<QuickMicaMaterial *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->tintColorChanged(); break;
        case 1: _t->tintOpacityChanged(); break;
        case 2: _t->fallbackColorChanged(); break;
        case 3: _t->noiseOpacityChanged(); break;
        case 4: _t->fallbackEnabledChanged(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (QuickMicaMaterial::*)();
            if (_t _q_method = &QuickMicaMaterial::tintColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (QuickMicaMaterial::*)();
            if (_t _q_method = &QuickMicaMaterial::tintOpacityChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (QuickMicaMaterial::*)();
            if (_t _q_method = &QuickMicaMaterial::fallbackColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (QuickMicaMaterial::*)();
            if (_t _q_method = &QuickMicaMaterial::noiseOpacityChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (QuickMicaMaterial::*)();
            if (_t _q_method = &QuickMicaMaterial::fallbackEnabledChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
    }else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<QuickMicaMaterial *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QColor*>(_v) = _t->tintColor(); break;
        case 1: *reinterpret_cast< qreal*>(_v) = _t->tintOpacity(); break;
        case 2: *reinterpret_cast< QColor*>(_v) = _t->fallbackColor(); break;
        case 3: *reinterpret_cast< qreal*>(_v) = _t->noiseOpacity(); break;
        case 4: *reinterpret_cast< bool*>(_v) = _t->isFallbackEnabled(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<QuickMicaMaterial *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setTintColor(*reinterpret_cast< QColor*>(_v)); break;
        case 1: _t->setTintOpacity(*reinterpret_cast< qreal*>(_v)); break;
        case 2: _t->setFallbackColor(*reinterpret_cast< QColor*>(_v)); break;
        case 3: _t->setNoiseOpacity(*reinterpret_cast< qreal*>(_v)); break;
        case 4: _t->setFallbackEnabled(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    } else if (_c == QMetaObject::BindableProperty) {
    }
    (void)_a;
}

const QMetaObject *wangwenx190::FramelessHelper::QuickMicaMaterial::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *wangwenx190::FramelessHelper::QuickMicaMaterial::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickMicaMaterialENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QQuickPaintedItem::qt_metacast(_clname);
}

int wangwenx190::FramelessHelper::QuickMicaMaterial::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QQuickPaintedItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 5)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 5;
    }else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void wangwenx190::FramelessHelper::QuickMicaMaterial::tintColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void wangwenx190::FramelessHelper::QuickMicaMaterial::tintOpacityChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void wangwenx190::FramelessHelper::QuickMicaMaterial::fallbackColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void wangwenx190::FramelessHelper::QuickMicaMaterial::noiseOpacityChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void wangwenx190::FramelessHelper::QuickMicaMaterial::fallbackEnabledChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}
QT_WARNING_POP
