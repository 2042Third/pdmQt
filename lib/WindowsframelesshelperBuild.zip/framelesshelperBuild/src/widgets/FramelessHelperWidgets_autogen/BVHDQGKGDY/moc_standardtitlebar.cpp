/****************************************************************************
** Meta object code from reading C++ file 'standardtitlebar.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../framelesshelper-2.3.6/include/FramelessHelper/Widgets/standardtitlebar.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'standardtitlebar.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardTitleBarENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardTitleBarENDCLASS = QtMocHelpers::stringData(
    "wangwenx190::FramelessHelper::StandardTitleBar",
    "extendedChanged",
    "",
    "titleLabelAlignmentChanged",
    "hideWhenCloseChanged",
    "titleLabelVisibleChanged",
    "windowIconSizeChanged",
    "windowIconVisibleChanged",
    "titleFontChanged",
    "titleLabelAlignment",
    "Qt::Alignment",
    "minimizeButton",
    "StandardSystemButton*",
    "maximizeButton",
    "closeButton",
    "extended",
    "hideWhenClose",
    "chromePalette",
    "ChromePalette*",
    "titleLabelVisible",
    "windowIconSize",
    "windowIconVisible",
    "titleFont"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardTitleBarENDCLASS_t {
    uint offsetsAndSizes[46];
    char stringdata0[47];
    char stringdata1[16];
    char stringdata2[1];
    char stringdata3[27];
    char stringdata4[21];
    char stringdata5[25];
    char stringdata6[22];
    char stringdata7[25];
    char stringdata8[17];
    char stringdata9[20];
    char stringdata10[14];
    char stringdata11[15];
    char stringdata12[22];
    char stringdata13[15];
    char stringdata14[12];
    char stringdata15[9];
    char stringdata16[14];
    char stringdata17[14];
    char stringdata18[15];
    char stringdata19[18];
    char stringdata20[15];
    char stringdata21[18];
    char stringdata22[10];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardTitleBarENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardTitleBarENDCLASS_t qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardTitleBarENDCLASS = {
    {
        QT_MOC_LITERAL(0, 46),  // "wangwenx190::FramelessHelper:..."
        QT_MOC_LITERAL(47, 15),  // "extendedChanged"
        QT_MOC_LITERAL(63, 0),  // ""
        QT_MOC_LITERAL(64, 26),  // "titleLabelAlignmentChanged"
        QT_MOC_LITERAL(91, 20),  // "hideWhenCloseChanged"
        QT_MOC_LITERAL(112, 24),  // "titleLabelVisibleChanged"
        QT_MOC_LITERAL(137, 21),  // "windowIconSizeChanged"
        QT_MOC_LITERAL(159, 24),  // "windowIconVisibleChanged"
        QT_MOC_LITERAL(184, 16),  // "titleFontChanged"
        QT_MOC_LITERAL(201, 19),  // "titleLabelAlignment"
        QT_MOC_LITERAL(221, 13),  // "Qt::Alignment"
        QT_MOC_LITERAL(235, 14),  // "minimizeButton"
        QT_MOC_LITERAL(250, 21),  // "StandardSystemButton*"
        QT_MOC_LITERAL(272, 14),  // "maximizeButton"
        QT_MOC_LITERAL(287, 11),  // "closeButton"
        QT_MOC_LITERAL(299, 8),  // "extended"
        QT_MOC_LITERAL(308, 13),  // "hideWhenClose"
        QT_MOC_LITERAL(322, 13),  // "chromePalette"
        QT_MOC_LITERAL(336, 14),  // "ChromePalette*"
        QT_MOC_LITERAL(351, 17),  // "titleLabelVisible"
        QT_MOC_LITERAL(369, 14),  // "windowIconSize"
        QT_MOC_LITERAL(384, 17),  // "windowIconVisible"
        QT_MOC_LITERAL(402, 9)   // "titleFont"
    },
    "wangwenx190::FramelessHelper::StandardTitleBar",
    "extendedChanged",
    "",
    "titleLabelAlignmentChanged",
    "hideWhenCloseChanged",
    "titleLabelVisibleChanged",
    "windowIconSizeChanged",
    "windowIconVisibleChanged",
    "titleFontChanged",
    "titleLabelAlignment",
    "Qt::Alignment",
    "minimizeButton",
    "StandardSystemButton*",
    "maximizeButton",
    "closeButton",
    "extended",
    "hideWhenClose",
    "chromePalette",
    "ChromePalette*",
    "titleLabelVisible",
    "windowIconSize",
    "windowIconVisible",
    "titleFont"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardTitleBarENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
      11,   63, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   56,    2, 0x06,   12 /* Public */,
       3,    0,   57,    2, 0x06,   13 /* Public */,
       4,    0,   58,    2, 0x06,   14 /* Public */,
       5,    0,   59,    2, 0x06,   15 /* Public */,
       6,    0,   60,    2, 0x06,   16 /* Public */,
       7,    0,   61,    2, 0x06,   17 /* Public */,
       8,    0,   62,    2, 0x06,   18 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // properties: name, type, flags
       9, 0x80000000 | 10, 0x0001590b, uint(1), 0,
      11, 0x80000000 | 12, 0x00015c09, uint(-1), 0,
      13, 0x80000000 | 12, 0x00015c09, uint(-1), 0,
      14, 0x80000000 | 12, 0x00015c09, uint(-1), 0,
      15, QMetaType::Bool, 0x00015903, uint(0), 0,
      16, QMetaType::Bool, 0x00015903, uint(2), 0,
      17, 0x80000000 | 18, 0x00015c09, uint(-1), 0,
      19, QMetaType::Bool, 0x00015903, uint(3), 0,
      20, QMetaType::QSize, 0x00015903, uint(4), 0,
      21, QMetaType::Bool, 0x00015903, uint(5), 0,
      22, QMetaType::QFont, 0x00015903, uint(6), 0,

       0        // eod
};

Q_CONSTINIT const QMetaObject wangwenx190::FramelessHelper::StandardTitleBar::staticMetaObject = { {
    QMetaObject::SuperData::link<QWidget::staticMetaObject>(),
    qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardTitleBarENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardTitleBarENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardTitleBarENDCLASS_t,
        // property 'titleLabelAlignment'
        QtPrivate::TypeAndForceComplete<Qt::Alignment, std::true_type>,
        // property 'minimizeButton'
        QtPrivate::TypeAndForceComplete<StandardSystemButton*, std::true_type>,
        // property 'maximizeButton'
        QtPrivate::TypeAndForceComplete<StandardSystemButton*, std::true_type>,
        // property 'closeButton'
        QtPrivate::TypeAndForceComplete<StandardSystemButton*, std::true_type>,
        // property 'extended'
        QtPrivate::TypeAndForceComplete<bool, std::true_type>,
        // property 'hideWhenClose'
        QtPrivate::TypeAndForceComplete<bool, std::true_type>,
        // property 'chromePalette'
        QtPrivate::TypeAndForceComplete<ChromePalette*, std::true_type>,
        // property 'titleLabelVisible'
        QtPrivate::TypeAndForceComplete<bool, std::true_type>,
        // property 'windowIconSize'
        QtPrivate::TypeAndForceComplete<QSize, std::true_type>,
        // property 'windowIconVisible'
        QtPrivate::TypeAndForceComplete<bool, std::true_type>,
        // property 'titleFont'
        QtPrivate::TypeAndForceComplete<QFont, std::true_type>,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<StandardTitleBar, std::true_type>,
        // method 'extendedChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'titleLabelAlignmentChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'hideWhenCloseChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'titleLabelVisibleChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'windowIconSizeChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'windowIconVisibleChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'titleFontChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>
    >,
    nullptr
} };

void wangwenx190::FramelessHelper::StandardTitleBar::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<StandardTitleBar *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->extendedChanged(); break;
        case 1: _t->titleLabelAlignmentChanged(); break;
        case 2: _t->hideWhenCloseChanged(); break;
        case 3: _t->titleLabelVisibleChanged(); break;
        case 4: _t->windowIconSizeChanged(); break;
        case 5: _t->windowIconVisibleChanged(); break;
        case 6: _t->titleFontChanged(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (StandardTitleBar::*)();
            if (_t _q_method = &StandardTitleBar::extendedChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (StandardTitleBar::*)();
            if (_t _q_method = &StandardTitleBar::titleLabelAlignmentChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (StandardTitleBar::*)();
            if (_t _q_method = &StandardTitleBar::hideWhenCloseChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (StandardTitleBar::*)();
            if (_t _q_method = &StandardTitleBar::titleLabelVisibleChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (StandardTitleBar::*)();
            if (_t _q_method = &StandardTitleBar::windowIconSizeChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (StandardTitleBar::*)();
            if (_t _q_method = &StandardTitleBar::windowIconVisibleChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (StandardTitleBar::*)();
            if (_t _q_method = &StandardTitleBar::titleFontChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 6;
                return;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 6:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< ChromePalette* >(); break;
        case 3:
        case 2:
        case 1:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< StandardSystemButton* >(); break;
        }
    } else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<StandardTitleBar *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< Qt::Alignment*>(_v) = _t->titleLabelAlignment(); break;
        case 1: *reinterpret_cast< StandardSystemButton**>(_v) = _t->minimizeButton(); break;
        case 2: *reinterpret_cast< StandardSystemButton**>(_v) = _t->maximizeButton(); break;
        case 3: *reinterpret_cast< StandardSystemButton**>(_v) = _t->closeButton(); break;
        case 4: *reinterpret_cast< bool*>(_v) = _t->isExtended(); break;
        case 5: *reinterpret_cast< bool*>(_v) = _t->isHideWhenClose(); break;
        case 6: *reinterpret_cast< ChromePalette**>(_v) = _t->chromePalette(); break;
        case 7: *reinterpret_cast< bool*>(_v) = _t->titleLabelVisible(); break;
        case 8: *reinterpret_cast< QSize*>(_v) = _t->windowIconSize(); break;
        case 9: *reinterpret_cast< bool*>(_v) = _t->windowIconVisible(); break;
        case 10: *reinterpret_cast< QFont*>(_v) = _t->titleFont(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<StandardTitleBar *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setTitleLabelAlignment(*reinterpret_cast< Qt::Alignment*>(_v)); break;
        case 4: _t->setExtended(*reinterpret_cast< bool*>(_v)); break;
        case 5: _t->setHideWhenClose(*reinterpret_cast< bool*>(_v)); break;
        case 7: _t->setTitleLabelVisible(*reinterpret_cast< bool*>(_v)); break;
        case 8: _t->setWindowIconSize(*reinterpret_cast< QSize*>(_v)); break;
        case 9: _t->setWindowIconVisible(*reinterpret_cast< bool*>(_v)); break;
        case 10: _t->setTitleFont(*reinterpret_cast< QFont*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    } else if (_c == QMetaObject::BindableProperty) {
    }
}

const QMetaObject *wangwenx190::FramelessHelper::StandardTitleBar::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *wangwenx190::FramelessHelper::StandardTitleBar::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEStandardTitleBarENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int wangwenx190::FramelessHelper::StandardTitleBar::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 7;
    }else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    }
    return _id;
}

// SIGNAL 0
void wangwenx190::FramelessHelper::StandardTitleBar::extendedChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void wangwenx190::FramelessHelper::StandardTitleBar::titleLabelAlignmentChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void wangwenx190::FramelessHelper::StandardTitleBar::hideWhenCloseChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void wangwenx190::FramelessHelper::StandardTitleBar::titleLabelVisibleChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void wangwenx190::FramelessHelper::StandardTitleBar::windowIconSizeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void wangwenx190::FramelessHelper::StandardTitleBar::windowIconVisibleChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void wangwenx190::FramelessHelper::StandardTitleBar::titleFontChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}
QT_WARNING_POP
