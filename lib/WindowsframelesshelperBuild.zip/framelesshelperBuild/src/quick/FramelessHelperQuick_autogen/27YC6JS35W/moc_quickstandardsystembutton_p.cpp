/****************************************************************************
** Meta object code from reading C++ file 'quickstandardsystembutton_p.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../framelesshelper-2.3.6/include/FramelessHelper/Quick/private/quickstandardsystembutton_p.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'quickstandardsystembutton_p.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardSystemButtonENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardSystemButtonENDCLASS = QtMocHelpers::stringData(
    "wangwenx190::FramelessHelper::QuickStandardSystemButton",
    "QML.Element",
    "StandardSystemButton",
    "buttonTypeChanged",
    "",
    "glyphChanged",
    "normalColorChanged",
    "hoverColorChanged",
    "pressColorChanged",
    "activeForegroundColorChanged",
    "inactiveForegroundColorChanged",
    "iconSizeChanged",
    "updateColor",
    "setButtonType",
    "QuickGlobal::SystemButtonType",
    "type",
    "setGlyph",
    "value",
    "setNormalColor",
    "setHoverColor",
    "setPressColor",
    "setActiveForegroundColor",
    "setInactiveForegroundColor",
    "setIconSize",
    "buttonType",
    "glyph",
    "hoverColor",
    "pressColor",
    "normalColor",
    "activeForegroundColor",
    "inactiveForegroundColor",
    "iconSize"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardSystemButtonENDCLASS_t {
    uint offsetsAndSizes[64];
    char stringdata0[56];
    char stringdata1[12];
    char stringdata2[21];
    char stringdata3[18];
    char stringdata4[1];
    char stringdata5[13];
    char stringdata6[19];
    char stringdata7[18];
    char stringdata8[18];
    char stringdata9[29];
    char stringdata10[31];
    char stringdata11[16];
    char stringdata12[12];
    char stringdata13[14];
    char stringdata14[30];
    char stringdata15[5];
    char stringdata16[9];
    char stringdata17[6];
    char stringdata18[15];
    char stringdata19[14];
    char stringdata20[14];
    char stringdata21[25];
    char stringdata22[27];
    char stringdata23[12];
    char stringdata24[11];
    char stringdata25[6];
    char stringdata26[11];
    char stringdata27[11];
    char stringdata28[12];
    char stringdata29[22];
    char stringdata30[24];
    char stringdata31[9];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardSystemButtonENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardSystemButtonENDCLASS_t qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardSystemButtonENDCLASS = {
    {
        QT_MOC_LITERAL(0, 55),  // "wangwenx190::FramelessHelper:..."
        QT_MOC_LITERAL(56, 11),  // "QML.Element"
        QT_MOC_LITERAL(68, 20),  // "StandardSystemButton"
        QT_MOC_LITERAL(89, 17),  // "buttonTypeChanged"
        QT_MOC_LITERAL(107, 0),  // ""
        QT_MOC_LITERAL(108, 12),  // "glyphChanged"
        QT_MOC_LITERAL(121, 18),  // "normalColorChanged"
        QT_MOC_LITERAL(140, 17),  // "hoverColorChanged"
        QT_MOC_LITERAL(158, 17),  // "pressColorChanged"
        QT_MOC_LITERAL(176, 28),  // "activeForegroundColorChanged"
        QT_MOC_LITERAL(205, 30),  // "inactiveForegroundColorChanged"
        QT_MOC_LITERAL(236, 15),  // "iconSizeChanged"
        QT_MOC_LITERAL(252, 11),  // "updateColor"
        QT_MOC_LITERAL(264, 13),  // "setButtonType"
        QT_MOC_LITERAL(278, 29),  // "QuickGlobal::SystemButtonType"
        QT_MOC_LITERAL(308, 4),  // "type"
        QT_MOC_LITERAL(313, 8),  // "setGlyph"
        QT_MOC_LITERAL(322, 5),  // "value"
        QT_MOC_LITERAL(328, 14),  // "setNormalColor"
        QT_MOC_LITERAL(343, 13),  // "setHoverColor"
        QT_MOC_LITERAL(357, 13),  // "setPressColor"
        QT_MOC_LITERAL(371, 24),  // "setActiveForegroundColor"
        QT_MOC_LITERAL(396, 26),  // "setInactiveForegroundColor"
        QT_MOC_LITERAL(423, 11),  // "setIconSize"
        QT_MOC_LITERAL(435, 10),  // "buttonType"
        QT_MOC_LITERAL(446, 5),  // "glyph"
        QT_MOC_LITERAL(452, 10),  // "hoverColor"
        QT_MOC_LITERAL(463, 10),  // "pressColor"
        QT_MOC_LITERAL(474, 11),  // "normalColor"
        QT_MOC_LITERAL(486, 21),  // "activeForegroundColor"
        QT_MOC_LITERAL(508, 23),  // "inactiveForegroundColor"
        QT_MOC_LITERAL(532, 8)   // "iconSize"
    },
    "wangwenx190::FramelessHelper::QuickStandardSystemButton",
    "QML.Element",
    "StandardSystemButton",
    "buttonTypeChanged",
    "",
    "glyphChanged",
    "normalColorChanged",
    "hoverColorChanged",
    "pressColorChanged",
    "activeForegroundColorChanged",
    "inactiveForegroundColorChanged",
    "iconSizeChanged",
    "updateColor",
    "setButtonType",
    "QuickGlobal::SystemButtonType",
    "type",
    "setGlyph",
    "value",
    "setNormalColor",
    "setHoverColor",
    "setPressColor",
    "setActiveForegroundColor",
    "setInactiveForegroundColor",
    "setIconSize",
    "buttonType",
    "glyph",
    "hoverColor",
    "pressColor",
    "normalColor",
    "activeForegroundColor",
    "inactiveForegroundColor",
    "iconSize"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardSystemButtonENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       1,   14, // classinfo
      17,   16, // methods
       8,  151, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       8,       // signalCount

 // classinfo: key, value
       1,    2,

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       3,    0,  118,    4, 0x06,    9 /* Public */,
       5,    0,  119,    4, 0x06,   10 /* Public */,
       6,    0,  120,    4, 0x06,   11 /* Public */,
       7,    0,  121,    4, 0x06,   12 /* Public */,
       8,    0,  122,    4, 0x06,   13 /* Public */,
       9,    0,  123,    4, 0x06,   14 /* Public */,
      10,    0,  124,    4, 0x06,   15 /* Public */,
      11,    0,  125,    4, 0x06,   16 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      12,    0,  126,    4, 0x0a,   17 /* Public */,
      13,    1,  127,    4, 0x0a,   18 /* Public */,
      16,    1,  130,    4, 0x0a,   20 /* Public */,
      18,    1,  133,    4, 0x0a,   22 /* Public */,
      19,    1,  136,    4, 0x0a,   24 /* Public */,
      20,    1,  139,    4, 0x0a,   26 /* Public */,
      21,    1,  142,    4, 0x0a,   28 /* Public */,
      22,    1,  145,    4, 0x0a,   30 /* Public */,
      23,    1,  148,    4, 0x0a,   32 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 14,   15,
    QMetaType::Void, QMetaType::QString,   17,
    QMetaType::Void, QMetaType::QColor,   17,
    QMetaType::Void, QMetaType::QColor,   17,
    QMetaType::Void, QMetaType::QColor,   17,
    QMetaType::Void, QMetaType::QColor,   17,
    QMetaType::Void, QMetaType::QColor,   17,
    QMetaType::Void, QMetaType::QReal,   17,

 // properties: name, type, flags
      24, 0x80000000 | 14, 0x0001590b, uint(0), 0,
      25, QMetaType::QString, 0x00015903, uint(1), 0,
      26, QMetaType::QColor, 0x00015903, uint(3), 0,
      27, QMetaType::QColor, 0x00015903, uint(4), 0,
      28, QMetaType::QColor, 0x00015903, uint(2), 0,
      29, QMetaType::QColor, 0x00015903, uint(5), 0,
      30, QMetaType::QColor, 0x00015903, uint(6), 0,
      31, QMetaType::QReal, 0x00015903, uint(7), 0,

       0        // eod
};

Q_CONSTINIT static const QMetaObject::SuperData qt_meta_extradata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardSystemButtonENDCLASS[] = {
    QMetaObject::SuperData::link<wangwenx190::FramelessHelper::QuickGlobal::staticMetaObject>(),
    nullptr
};

Q_CONSTINIT const QMetaObject wangwenx190::FramelessHelper::QuickStandardSystemButton::staticMetaObject = { {
    QMetaObject::SuperData::link<QQuickButton::staticMetaObject>(),
    qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardSystemButtonENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardSystemButtonENDCLASS,
    qt_static_metacall,
    qt_meta_extradata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardSystemButtonENDCLASS,
    qt_metaTypeArray<
        // property 'buttonType'
        QuickGlobal::SystemButtonType,
        // property 'glyph'
        QString,
        // property 'hoverColor'
        QColor,
        // property 'pressColor'
        QColor,
        // property 'normalColor'
        QColor,
        // property 'activeForegroundColor'
        QColor,
        // property 'inactiveForegroundColor'
        QColor,
        // property 'iconSize'
        qreal,
        // Q_OBJECT / Q_GADGET
        QuickStandardSystemButton,
        // method 'buttonTypeChanged'
        void,
        // method 'glyphChanged'
        void,
        // method 'normalColorChanged'
        void,
        // method 'hoverColorChanged'
        void,
        // method 'pressColorChanged'
        void,
        // method 'activeForegroundColorChanged'
        void,
        // method 'inactiveForegroundColorChanged'
        void,
        // method 'iconSizeChanged'
        void,
        // method 'updateColor'
        void,
        // method 'setButtonType'
        void,
        const QuickGlobal::SystemButtonType,
        // method 'setGlyph'
        void,
        const QString &,
        // method 'setNormalColor'
        void,
        const QColor &,
        // method 'setHoverColor'
        void,
        const QColor &,
        // method 'setPressColor'
        void,
        const QColor &,
        // method 'setActiveForegroundColor'
        void,
        const QColor &,
        // method 'setInactiveForegroundColor'
        void,
        const QColor &,
        // method 'setIconSize'
        void,
        const qreal
    >,
    nullptr
} };

void wangwenx190::FramelessHelper::QuickStandardSystemButton::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<QuickStandardSystemButton *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->buttonTypeChanged(); break;
        case 1: _t->glyphChanged(); break;
        case 2: _t->normalColorChanged(); break;
        case 3: _t->hoverColorChanged(); break;
        case 4: _t->pressColorChanged(); break;
        case 5: _t->activeForegroundColorChanged(); break;
        case 6: _t->inactiveForegroundColorChanged(); break;
        case 7: _t->iconSizeChanged(); break;
        case 8: _t->updateColor(); break;
        case 9: _t->setButtonType((*reinterpret_cast< std::add_pointer_t<QuickGlobal::SystemButtonType>>(_a[1]))); break;
        case 10: _t->setGlyph((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 11: _t->setNormalColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 12: _t->setHoverColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 13: _t->setPressColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 14: _t->setActiveForegroundColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 15: _t->setInactiveForegroundColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 16: _t->setIconSize((*reinterpret_cast< std::add_pointer_t<qreal>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (QuickStandardSystemButton::*)();
            if (_t _q_method = &QuickStandardSystemButton::buttonTypeChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (QuickStandardSystemButton::*)();
            if (_t _q_method = &QuickStandardSystemButton::glyphChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (QuickStandardSystemButton::*)();
            if (_t _q_method = &QuickStandardSystemButton::normalColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (QuickStandardSystemButton::*)();
            if (_t _q_method = &QuickStandardSystemButton::hoverColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (QuickStandardSystemButton::*)();
            if (_t _q_method = &QuickStandardSystemButton::pressColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (QuickStandardSystemButton::*)();
            if (_t _q_method = &QuickStandardSystemButton::activeForegroundColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (QuickStandardSystemButton::*)();
            if (_t _q_method = &QuickStandardSystemButton::inactiveForegroundColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (QuickStandardSystemButton::*)();
            if (_t _q_method = &QuickStandardSystemButton::iconSizeChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 7;
                return;
            }
        }
    }else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<QuickStandardSystemButton *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QuickGlobal::SystemButtonType*>(_v) = _t->buttonType(); break;
        case 1: *reinterpret_cast< QString*>(_v) = _t->glyph(); break;
        case 2: *reinterpret_cast< QColor*>(_v) = _t->hoverColor(); break;
        case 3: *reinterpret_cast< QColor*>(_v) = _t->pressColor(); break;
        case 4: *reinterpret_cast< QColor*>(_v) = _t->normalColor(); break;
        case 5: *reinterpret_cast< QColor*>(_v) = _t->activeForegroundColor(); break;
        case 6: *reinterpret_cast< QColor*>(_v) = _t->inactiveForegroundColor(); break;
        case 7: *reinterpret_cast< qreal*>(_v) = _t->iconSize(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<QuickStandardSystemButton *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setButtonType(*reinterpret_cast< QuickGlobal::SystemButtonType*>(_v)); break;
        case 1: _t->setGlyph(*reinterpret_cast< QString*>(_v)); break;
        case 2: _t->setHoverColor(*reinterpret_cast< QColor*>(_v)); break;
        case 3: _t->setPressColor(*reinterpret_cast< QColor*>(_v)); break;
        case 4: _t->setNormalColor(*reinterpret_cast< QColor*>(_v)); break;
        case 5: _t->setActiveForegroundColor(*reinterpret_cast< QColor*>(_v)); break;
        case 6: _t->setInactiveForegroundColor(*reinterpret_cast< QColor*>(_v)); break;
        case 7: _t->setIconSize(*reinterpret_cast< qreal*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    } else if (_c == QMetaObject::BindableProperty) {
    }
}

const QMetaObject *wangwenx190::FramelessHelper::QuickStandardSystemButton::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *wangwenx190::FramelessHelper::QuickStandardSystemButton::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardSystemButtonENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QQuickButton::qt_metacast(_clname);
}

int wangwenx190::FramelessHelper::QuickStandardSystemButton::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QQuickButton::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 17)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 17;
    }else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void wangwenx190::FramelessHelper::QuickStandardSystemButton::buttonTypeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void wangwenx190::FramelessHelper::QuickStandardSystemButton::glyphChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void wangwenx190::FramelessHelper::QuickStandardSystemButton::normalColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void wangwenx190::FramelessHelper::QuickStandardSystemButton::hoverColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void wangwenx190::FramelessHelper::QuickStandardSystemButton::pressColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void wangwenx190::FramelessHelper::QuickStandardSystemButton::activeForegroundColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}

// SIGNAL 6
void wangwenx190::FramelessHelper::QuickStandardSystemButton::inactiveForegroundColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 6, nullptr);
}

// SIGNAL 7
void wangwenx190::FramelessHelper::QuickStandardSystemButton::iconSizeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 7, nullptr);
}
QT_WARNING_POP
