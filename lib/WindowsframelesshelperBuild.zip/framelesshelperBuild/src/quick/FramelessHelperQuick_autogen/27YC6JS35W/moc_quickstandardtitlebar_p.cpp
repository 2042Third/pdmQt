/****************************************************************************
** Meta object code from reading C++ file 'quickstandardtitlebar_p.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../framelesshelper-2.3.6/include/FramelessHelper/Quick/private/quickstandardtitlebar_p.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'quickstandardtitlebar_p.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardTitleBarENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardTitleBarENDCLASS = QtMocHelpers::stringData(
    "wangwenx190::FramelessHelper::QuickStandardTitleBar",
    "QML.Element",
    "StandardTitleBar",
    "titleLabelAlignmentChanged",
    "",
    "extendedChanged",
    "hideWhenCloseChanged",
    "windowIconSizeChanged",
    "windowIconVisibleChanged",
    "windowIconChanged",
    "updateMaximizeButton",
    "updateTitleLabelText",
    "updateTitleBarColor",
    "updateChromeButtonColor",
    "clickMinimizeButton",
    "clickMaximizeButton",
    "clickCloseButton",
    "retranslateUi",
    "updateWindowIcon",
    "titleLabelAlignment",
    "Qt::Alignment",
    "titleLabel",
    "QQuickLabel*",
    "minimizeButton",
    "QuickStandardSystemButton*",
    "maximizeButton",
    "closeButton",
    "extended",
    "hideWhenClose",
    "chromePalette",
    "QuickChromePalette*",
    "windowIconSize",
    "windowIconVisible",
    "windowIcon"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardTitleBarENDCLASS_t {
    uint offsetsAndSizes[68];
    char stringdata0[52];
    char stringdata1[12];
    char stringdata2[17];
    char stringdata3[27];
    char stringdata4[1];
    char stringdata5[16];
    char stringdata6[21];
    char stringdata7[22];
    char stringdata8[25];
    char stringdata9[18];
    char stringdata10[21];
    char stringdata11[21];
    char stringdata12[20];
    char stringdata13[24];
    char stringdata14[20];
    char stringdata15[20];
    char stringdata16[17];
    char stringdata17[14];
    char stringdata18[17];
    char stringdata19[20];
    char stringdata20[14];
    char stringdata21[11];
    char stringdata22[13];
    char stringdata23[15];
    char stringdata24[27];
    char stringdata25[15];
    char stringdata26[12];
    char stringdata27[9];
    char stringdata28[14];
    char stringdata29[14];
    char stringdata30[20];
    char stringdata31[15];
    char stringdata32[18];
    char stringdata33[11];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardTitleBarENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardTitleBarENDCLASS_t qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardTitleBarENDCLASS = {
    {
        QT_MOC_LITERAL(0, 51),  // "wangwenx190::FramelessHelper:..."
        QT_MOC_LITERAL(52, 11),  // "QML.Element"
        QT_MOC_LITERAL(64, 16),  // "StandardTitleBar"
        QT_MOC_LITERAL(81, 26),  // "titleLabelAlignmentChanged"
        QT_MOC_LITERAL(108, 0),  // ""
        QT_MOC_LITERAL(109, 15),  // "extendedChanged"
        QT_MOC_LITERAL(125, 20),  // "hideWhenCloseChanged"
        QT_MOC_LITERAL(146, 21),  // "windowIconSizeChanged"
        QT_MOC_LITERAL(168, 24),  // "windowIconVisibleChanged"
        QT_MOC_LITERAL(193, 17),  // "windowIconChanged"
        QT_MOC_LITERAL(211, 20),  // "updateMaximizeButton"
        QT_MOC_LITERAL(232, 20),  // "updateTitleLabelText"
        QT_MOC_LITERAL(253, 19),  // "updateTitleBarColor"
        QT_MOC_LITERAL(273, 23),  // "updateChromeButtonColor"
        QT_MOC_LITERAL(297, 19),  // "clickMinimizeButton"
        QT_MOC_LITERAL(317, 19),  // "clickMaximizeButton"
        QT_MOC_LITERAL(337, 16),  // "clickCloseButton"
        QT_MOC_LITERAL(354, 13),  // "retranslateUi"
        QT_MOC_LITERAL(368, 16),  // "updateWindowIcon"
        QT_MOC_LITERAL(385, 19),  // "titleLabelAlignment"
        QT_MOC_LITERAL(405, 13),  // "Qt::Alignment"
        QT_MOC_LITERAL(419, 10),  // "titleLabel"
        QT_MOC_LITERAL(430, 12),  // "QQuickLabel*"
        QT_MOC_LITERAL(443, 14),  // "minimizeButton"
        QT_MOC_LITERAL(458, 26),  // "QuickStandardSystemButton*"
        QT_MOC_LITERAL(485, 14),  // "maximizeButton"
        QT_MOC_LITERAL(500, 11),  // "closeButton"
        QT_MOC_LITERAL(512, 8),  // "extended"
        QT_MOC_LITERAL(521, 13),  // "hideWhenClose"
        QT_MOC_LITERAL(535, 13),  // "chromePalette"
        QT_MOC_LITERAL(549, 19),  // "QuickChromePalette*"
        QT_MOC_LITERAL(569, 14),  // "windowIconSize"
        QT_MOC_LITERAL(584, 17),  // "windowIconVisible"
        QT_MOC_LITERAL(602, 10)   // "windowIcon"
    },
    "wangwenx190::FramelessHelper::QuickStandardTitleBar",
    "QML.Element",
    "StandardTitleBar",
    "titleLabelAlignmentChanged",
    "",
    "extendedChanged",
    "hideWhenCloseChanged",
    "windowIconSizeChanged",
    "windowIconVisibleChanged",
    "windowIconChanged",
    "updateMaximizeButton",
    "updateTitleLabelText",
    "updateTitleBarColor",
    "updateChromeButtonColor",
    "clickMinimizeButton",
    "clickMaximizeButton",
    "clickCloseButton",
    "retranslateUi",
    "updateWindowIcon",
    "titleLabelAlignment",
    "Qt::Alignment",
    "titleLabel",
    "QQuickLabel*",
    "minimizeButton",
    "QuickStandardSystemButton*",
    "maximizeButton",
    "closeButton",
    "extended",
    "hideWhenClose",
    "chromePalette",
    "QuickChromePalette*",
    "windowIconSize",
    "windowIconVisible",
    "windowIcon"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardTitleBarENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       1,   14, // classinfo
      15,   16, // methods
      11,  121, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // classinfo: key, value
       1,    2,

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       3,    0,  106,    4, 0x06,   12 /* Public */,
       5,    0,  107,    4, 0x06,   13 /* Public */,
       6,    0,  108,    4, 0x06,   14 /* Public */,
       7,    0,  109,    4, 0x06,   15 /* Public */,
       8,    0,  110,    4, 0x06,   16 /* Public */,
       9,    0,  111,    4, 0x06,   17 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      10,    0,  112,    4, 0x08,   18 /* Private */,
      11,    0,  113,    4, 0x08,   19 /* Private */,
      12,    0,  114,    4, 0x08,   20 /* Private */,
      13,    0,  115,    4, 0x08,   21 /* Private */,
      14,    0,  116,    4, 0x08,   22 /* Private */,
      15,    0,  117,    4, 0x08,   23 /* Private */,
      16,    0,  118,    4, 0x08,   24 /* Private */,
      17,    0,  119,    4, 0x08,   25 /* Private */,
      18,    0,  120,    4, 0x08,   26 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // properties: name, type, flags
      19, 0x80000000 | 20, 0x0001590b, uint(0), 0,
      21, 0x80000000 | 22, 0x00015c09, uint(-1), 0,
      23, 0x80000000 | 24, 0x00015c09, uint(-1), 0,
      25, 0x80000000 | 24, 0x00015c09, uint(-1), 0,
      26, 0x80000000 | 24, 0x00015c09, uint(-1), 0,
      27, QMetaType::Bool, 0x00015903, uint(1), 0,
      28, QMetaType::Bool, 0x00015903, uint(2), 0,
      29, 0x80000000 | 30, 0x00015c09, uint(-1), 0,
      31, QMetaType::QSizeF, 0x00015903, uint(3), 0,
      32, QMetaType::Bool, 0x00015903, uint(4), 0,
      33, QMetaType::QVariant, 0x00015903, uint(5), 0,

       0        // eod
};

Q_CONSTINIT const QMetaObject wangwenx190::FramelessHelper::QuickStandardTitleBar::staticMetaObject = { {
    QMetaObject::SuperData::link<QQuickRectangle::staticMetaObject>(),
    qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardTitleBarENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardTitleBarENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_metaTypeArray<
        // property 'titleLabelAlignment'
        Qt::Alignment,
        // property 'titleLabel'
        QQuickLabel*,
        // property 'minimizeButton'
        QuickStandardSystemButton*,
        // property 'maximizeButton'
        QuickStandardSystemButton*,
        // property 'closeButton'
        QuickStandardSystemButton*,
        // property 'extended'
        bool,
        // property 'hideWhenClose'
        bool,
        // property 'chromePalette'
        QuickChromePalette*,
        // property 'windowIconSize'
        QSizeF,
        // property 'windowIconVisible'
        bool,
        // property 'windowIcon'
        QVariant,
        // Q_OBJECT / Q_GADGET
        QuickStandardTitleBar,
        // method 'titleLabelAlignmentChanged'
        void,
        // method 'extendedChanged'
        void,
        // method 'hideWhenCloseChanged'
        void,
        // method 'windowIconSizeChanged'
        void,
        // method 'windowIconVisibleChanged'
        void,
        // method 'windowIconChanged'
        void,
        // method 'updateMaximizeButton'
        void,
        // method 'updateTitleLabelText'
        void,
        // method 'updateTitleBarColor'
        void,
        // method 'updateChromeButtonColor'
        void,
        // method 'clickMinimizeButton'
        void,
        // method 'clickMaximizeButton'
        void,
        // method 'clickCloseButton'
        void,
        // method 'retranslateUi'
        void,
        // method 'updateWindowIcon'
        void
    >,
    nullptr
} };

void wangwenx190::FramelessHelper::QuickStandardTitleBar::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<QuickStandardTitleBar *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->titleLabelAlignmentChanged(); break;
        case 1: _t->extendedChanged(); break;
        case 2: _t->hideWhenCloseChanged(); break;
        case 3: _t->windowIconSizeChanged(); break;
        case 4: _t->windowIconVisibleChanged(); break;
        case 5: _t->windowIconChanged(); break;
        case 6: _t->updateMaximizeButton(); break;
        case 7: _t->updateTitleLabelText(); break;
        case 8: _t->updateTitleBarColor(); break;
        case 9: _t->updateChromeButtonColor(); break;
        case 10: _t->clickMinimizeButton(); break;
        case 11: _t->clickMaximizeButton(); break;
        case 12: _t->clickCloseButton(); break;
        case 13: _t->retranslateUi(); break;
        case 14: _t->updateWindowIcon(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (QuickStandardTitleBar::*)();
            if (_t _q_method = &QuickStandardTitleBar::titleLabelAlignmentChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (QuickStandardTitleBar::*)();
            if (_t _q_method = &QuickStandardTitleBar::extendedChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (QuickStandardTitleBar::*)();
            if (_t _q_method = &QuickStandardTitleBar::hideWhenCloseChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (QuickStandardTitleBar::*)();
            if (_t _q_method = &QuickStandardTitleBar::windowIconSizeChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (QuickStandardTitleBar::*)();
            if (_t _q_method = &QuickStandardTitleBar::windowIconVisibleChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (QuickStandardTitleBar::*)();
            if (_t _q_method = &QuickStandardTitleBar::windowIconChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 1:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QQuickLabel* >(); break;
        case 7:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QuickChromePalette* >(); break;
        case 4:
        case 3:
        case 2:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QuickStandardSystemButton* >(); break;
        }
    } else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<QuickStandardTitleBar *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< Qt::Alignment*>(_v) = _t->titleLabelAlignment(); break;
        case 1: *reinterpret_cast< QQuickLabel**>(_v) = _t->titleLabel(); break;
        case 2: *reinterpret_cast< QuickStandardSystemButton**>(_v) = _t->minimizeButton(); break;
        case 3: *reinterpret_cast< QuickStandardSystemButton**>(_v) = _t->maximizeButton(); break;
        case 4: *reinterpret_cast< QuickStandardSystemButton**>(_v) = _t->closeButton(); break;
        case 5: *reinterpret_cast< bool*>(_v) = _t->isExtended(); break;
        case 6: *reinterpret_cast< bool*>(_v) = _t->isHideWhenClose(); break;
        case 7: *reinterpret_cast< QuickChromePalette**>(_v) = _t->chromePalette(); break;
        case 8: *reinterpret_cast< QSizeF*>(_v) = _t->windowIconSize(); break;
        case 9: *reinterpret_cast< bool*>(_v) = _t->windowIconVisible(); break;
        case 10: *reinterpret_cast< QVariant*>(_v) = _t->windowIcon(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<QuickStandardTitleBar *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setTitleLabelAlignment(*reinterpret_cast< Qt::Alignment*>(_v)); break;
        case 5: _t->setExtended(*reinterpret_cast< bool*>(_v)); break;
        case 6: _t->setHideWhenClose(*reinterpret_cast< bool*>(_v)); break;
        case 8: _t->setWindowIconSize(*reinterpret_cast< QSizeF*>(_v)); break;
        case 9: _t->setWindowIconVisible(*reinterpret_cast< bool*>(_v)); break;
        case 10: _t->setWindowIcon(*reinterpret_cast< QVariant*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    } else if (_c == QMetaObject::BindableProperty) {
    }
}

const QMetaObject *wangwenx190::FramelessHelper::QuickStandardTitleBar::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *wangwenx190::FramelessHelper::QuickStandardTitleBar::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickStandardTitleBarENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QQuickRectangle::qt_metacast(_clname);
}

int wangwenx190::FramelessHelper::QuickStandardTitleBar::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QQuickRectangle::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 15;
    }else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    }
    return _id;
}

// SIGNAL 0
void wangwenx190::FramelessHelper::QuickStandardTitleBar::titleLabelAlignmentChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void wangwenx190::FramelessHelper::QuickStandardTitleBar::extendedChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void wangwenx190::FramelessHelper::QuickStandardTitleBar::hideWhenCloseChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void wangwenx190::FramelessHelper::QuickStandardTitleBar::windowIconSizeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void wangwenx190::FramelessHelper::QuickStandardTitleBar::windowIconVisibleChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void wangwenx190::FramelessHelper::QuickStandardTitleBar::windowIconChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}
QT_WARNING_POP
