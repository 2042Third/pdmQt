/****************************************************************************
** Meta object code from reading C++ file 'framelessquickapplicationwindow_p_p.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../framelesshelper-2.3.6/include/FramelessHelper/Quick/private/framelessquickapplicationwindow_p_p.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'framelessquickapplicationwindow_p_p.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickApplicationWindowPrivateENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickApplicationWindowPrivateENDCLASS = QtMocHelpers::stringData(
    "wangwenx190::FramelessHelper::FramelessQuickApplicationWindowPrivate",
    "showMinimized2",
    "",
    "toggleMaximized",
    "toggleFullScreen",
    "isHidden",
    "isNormal",
    "isMinimized",
    "isMaximized",
    "isZoomed",
    "isFullScreen"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickApplicationWindowPrivateENDCLASS_t {
    uint offsetsAndSizes[22];
    char stringdata0[69];
    char stringdata1[15];
    char stringdata2[1];
    char stringdata3[16];
    char stringdata4[17];
    char stringdata5[9];
    char stringdata6[9];
    char stringdata7[12];
    char stringdata8[12];
    char stringdata9[9];
    char stringdata10[13];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickApplicationWindowPrivateENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickApplicationWindowPrivateENDCLASS_t qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickApplicationWindowPrivateENDCLASS = {
    {
        QT_MOC_LITERAL(0, 68),  // "wangwenx190::FramelessHelper:..."
        QT_MOC_LITERAL(69, 14),  // "showMinimized2"
        QT_MOC_LITERAL(84, 0),  // ""
        QT_MOC_LITERAL(85, 15),  // "toggleMaximized"
        QT_MOC_LITERAL(101, 16),  // "toggleFullScreen"
        QT_MOC_LITERAL(118, 8),  // "isHidden"
        QT_MOC_LITERAL(127, 8),  // "isNormal"
        QT_MOC_LITERAL(136, 11),  // "isMinimized"
        QT_MOC_LITERAL(148, 11),  // "isMaximized"
        QT_MOC_LITERAL(160, 8),  // "isZoomed"
        QT_MOC_LITERAL(169, 12)   // "isFullScreen"
    },
    "wangwenx190::FramelessHelper::FramelessQuickApplicationWindowPrivate",
    "showMinimized2",
    "",
    "toggleMaximized",
    "toggleFullScreen",
    "isHidden",
    "isNormal",
    "isMinimized",
    "isMaximized",
    "isZoomed",
    "isFullScreen"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickApplicationWindowPrivateENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   68,    2, 0x0a,    1 /* Public */,
       3,    0,   69,    2, 0x0a,    2 /* Public */,
       4,    0,   70,    2, 0x0a,    3 /* Public */,

 // methods: name, argc, parameters, tag, flags, initial metatype offsets
       5,    0,   71,    2, 0x102,    4 /* Public | MethodIsConst  */,
       6,    0,   72,    2, 0x102,    5 /* Public | MethodIsConst  */,
       7,    0,   73,    2, 0x102,    6 /* Public | MethodIsConst  */,
       8,    0,   74,    2, 0x102,    7 /* Public | MethodIsConst  */,
       9,    0,   75,    2, 0x102,    8 /* Public | MethodIsConst  */,
      10,    0,   76,    2, 0x102,    9 /* Public | MethodIsConst  */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // methods: parameters
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Bool,
    QMetaType::Bool,

       0        // eod
};

Q_CONSTINIT const QMetaObject wangwenx190::FramelessHelper::FramelessQuickApplicationWindowPrivate::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickApplicationWindowPrivateENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickApplicationWindowPrivateENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickApplicationWindowPrivateENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<FramelessQuickApplicationWindowPrivate, std::true_type>,
        // method 'showMinimized2'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'toggleMaximized'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'toggleFullScreen'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'isHidden'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'isNormal'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'isMinimized'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'isMaximized'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'isZoomed'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>,
        // method 'isFullScreen'
        QtPrivate::TypeAndForceComplete<bool, std::false_type>
    >,
    nullptr
} };

void wangwenx190::FramelessHelper::FramelessQuickApplicationWindowPrivate::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<FramelessQuickApplicationWindowPrivate *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->showMinimized2(); break;
        case 1: _t->toggleMaximized(); break;
        case 2: _t->toggleFullScreen(); break;
        case 3: { bool _r = _t->isHidden();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 4: { bool _r = _t->isNormal();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 5: { bool _r = _t->isMinimized();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 6: { bool _r = _t->isMaximized();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 7: { bool _r = _t->isZoomed();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        case 8: { bool _r = _t->isFullScreen();
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    }
}

const QMetaObject *wangwenx190::FramelessHelper::FramelessQuickApplicationWindowPrivate::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *wangwenx190::FramelessHelper::FramelessQuickApplicationWindowPrivate::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickApplicationWindowPrivateENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int wangwenx190::FramelessHelper::FramelessQuickApplicationWindowPrivate::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 9;
    }
    return _id;
}
QT_WARNING_POP
