/****************************************************************************
** Meta object code from reading C++ file 'framelessquickutils.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../framelesshelper-2.3.6/include/FramelessHelper/Quick/framelessquickutils.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'framelessquickutils.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickUtilsENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickUtilsENDCLASS = QtMocHelpers::stringData(
    "wangwenx190::FramelessHelper::FramelessQuickUtils",
    "QML.Element",
    "FramelessUtils",
    "QML.Singleton",
    "true",
    "systemThemeChanged",
    "",
    "systemAccentColorChanged",
    "titleBarColorizedChanged",
    "getSystemButtonBackgroundColor",
    "QuickGlobal::SystemButtonType",
    "button",
    "QuickGlobal::ButtonState",
    "state",
    "titleBarHeight",
    "frameBorderVisible",
    "frameBorderThickness",
    "systemTheme",
    "QuickGlobal::SystemTheme",
    "systemAccentColor",
    "titleBarColorized",
    "defaultSystemLightColor",
    "defaultSystemDarkColor",
    "defaultSystemButtonSize",
    "defaultSystemButtonIconSize",
    "defaultSystemButtonBackgroundColor",
    "defaultSystemCloseButtonBackgroundColor"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickUtilsENDCLASS_t {
    uint offsetsAndSizes[54];
    char stringdata0[50];
    char stringdata1[12];
    char stringdata2[15];
    char stringdata3[14];
    char stringdata4[5];
    char stringdata5[19];
    char stringdata6[1];
    char stringdata7[25];
    char stringdata8[25];
    char stringdata9[31];
    char stringdata10[30];
    char stringdata11[7];
    char stringdata12[25];
    char stringdata13[6];
    char stringdata14[15];
    char stringdata15[19];
    char stringdata16[21];
    char stringdata17[12];
    char stringdata18[25];
    char stringdata19[18];
    char stringdata20[18];
    char stringdata21[24];
    char stringdata22[23];
    char stringdata23[24];
    char stringdata24[28];
    char stringdata25[35];
    char stringdata26[40];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickUtilsENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickUtilsENDCLASS_t qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickUtilsENDCLASS = {
    {
        QT_MOC_LITERAL(0, 49),  // "wangwenx190::FramelessHelper:..."
        QT_MOC_LITERAL(50, 11),  // "QML.Element"
        QT_MOC_LITERAL(62, 14),  // "FramelessUtils"
        QT_MOC_LITERAL(77, 13),  // "QML.Singleton"
        QT_MOC_LITERAL(91, 4),  // "true"
        QT_MOC_LITERAL(96, 18),  // "systemThemeChanged"
        QT_MOC_LITERAL(115, 0),  // ""
        QT_MOC_LITERAL(116, 24),  // "systemAccentColorChanged"
        QT_MOC_LITERAL(141, 24),  // "titleBarColorizedChanged"
        QT_MOC_LITERAL(166, 30),  // "getSystemButtonBackgroundColor"
        QT_MOC_LITERAL(197, 29),  // "QuickGlobal::SystemButtonType"
        QT_MOC_LITERAL(227, 6),  // "button"
        QT_MOC_LITERAL(234, 24),  // "QuickGlobal::ButtonState"
        QT_MOC_LITERAL(259, 5),  // "state"
        QT_MOC_LITERAL(265, 14),  // "titleBarHeight"
        QT_MOC_LITERAL(280, 18),  // "frameBorderVisible"
        QT_MOC_LITERAL(299, 20),  // "frameBorderThickness"
        QT_MOC_LITERAL(320, 11),  // "systemTheme"
        QT_MOC_LITERAL(332, 24),  // "QuickGlobal::SystemTheme"
        QT_MOC_LITERAL(357, 17),  // "systemAccentColor"
        QT_MOC_LITERAL(375, 17),  // "titleBarColorized"
        QT_MOC_LITERAL(393, 23),  // "defaultSystemLightColor"
        QT_MOC_LITERAL(417, 22),  // "defaultSystemDarkColor"
        QT_MOC_LITERAL(440, 23),  // "defaultSystemButtonSize"
        QT_MOC_LITERAL(464, 27),  // "defaultSystemButtonIconSize"
        QT_MOC_LITERAL(492, 34),  // "defaultSystemButtonBackground..."
        QT_MOC_LITERAL(527, 39)   // "defaultSystemCloseButtonBackg..."
    },
    "wangwenx190::FramelessHelper::FramelessQuickUtils",
    "QML.Element",
    "FramelessUtils",
    "QML.Singleton",
    "true",
    "systemThemeChanged",
    "",
    "systemAccentColorChanged",
    "titleBarColorizedChanged",
    "getSystemButtonBackgroundColor",
    "QuickGlobal::SystemButtonType",
    "button",
    "QuickGlobal::ButtonState",
    "state",
    "titleBarHeight",
    "frameBorderVisible",
    "frameBorderThickness",
    "systemTheme",
    "QuickGlobal::SystemTheme",
    "systemAccentColor",
    "titleBarColorized",
    "defaultSystemLightColor",
    "defaultSystemDarkColor",
    "defaultSystemButtonSize",
    "defaultSystemButtonIconSize",
    "defaultSystemButtonBackgroundColor",
    "defaultSystemCloseButtonBackgroundColor"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickUtilsENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       2,   14, // classinfo
       4,   18, // methods
      12,   50, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // classinfo: key, value
       1,    2,
       3,    4,

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       5,    0,   42,    6, 0x06,   13 /* Public */,
       7,    0,   43,    6, 0x06,   14 /* Public */,
       8,    0,   44,    6, 0x06,   15 /* Public */,

 // methods: name, argc, parameters, tag, flags, initial metatype offsets
       9,    2,   45,    6, 0x02,   16 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // methods: parameters
    QMetaType::QColor, 0x80000000 | 10, 0x80000000 | 12,   11,   13,

 // properties: name, type, flags
      14, QMetaType::QReal, 0x00015c01, uint(-1), 0,
      15, QMetaType::Bool, 0x00015c01, uint(-1), 0,
      16, QMetaType::QReal, 0x00015c01, uint(-1), 0,
      17, 0x80000000 | 18, 0x00015809, uint(0), 0,
      19, QMetaType::QColor, 0x00015801, uint(1), 0,
      20, QMetaType::Bool, 0x00015801, uint(2), 0,
      21, QMetaType::QColor, 0x00015c01, uint(-1), 0,
      22, QMetaType::QColor, 0x00015c01, uint(-1), 0,
      23, QMetaType::QSizeF, 0x00015c01, uint(-1), 0,
      24, QMetaType::QSizeF, 0x00015c01, uint(-1), 0,
      25, QMetaType::QColor, 0x00015c01, uint(-1), 0,
      26, QMetaType::QColor, 0x00015c01, uint(-1), 0,

       0        // eod
};

Q_CONSTINIT static const QMetaObject::SuperData qt_meta_extradata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickUtilsENDCLASS[] = {
    QMetaObject::SuperData::link<wangwenx190::FramelessHelper::QuickGlobal::staticMetaObject>(),
    nullptr
};

Q_CONSTINIT const QMetaObject wangwenx190::FramelessHelper::FramelessQuickUtils::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickUtilsENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickUtilsENDCLASS,
    qt_static_metacall,
    qt_meta_extradata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickUtilsENDCLASS,
    qt_metaTypeArray<
        // property 'titleBarHeight'
        qreal,
        // property 'frameBorderVisible'
        bool,
        // property 'frameBorderThickness'
        qreal,
        // property 'systemTheme'
        QuickGlobal::SystemTheme,
        // property 'systemAccentColor'
        QColor,
        // property 'titleBarColorized'
        bool,
        // property 'defaultSystemLightColor'
        QColor,
        // property 'defaultSystemDarkColor'
        QColor,
        // property 'defaultSystemButtonSize'
        QSizeF,
        // property 'defaultSystemButtonIconSize'
        QSizeF,
        // property 'defaultSystemButtonBackgroundColor'
        QColor,
        // property 'defaultSystemCloseButtonBackgroundColor'
        QColor,
        // Q_OBJECT / Q_GADGET
        FramelessQuickUtils,
        // method 'systemThemeChanged'
        void,
        // method 'systemAccentColorChanged'
        void,
        // method 'titleBarColorizedChanged'
        void,
        // method 'getSystemButtonBackgroundColor'
        QColor,
        const QuickGlobal::SystemButtonType,
        const QuickGlobal::ButtonState
    >,
    nullptr
} };

void wangwenx190::FramelessHelper::FramelessQuickUtils::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<FramelessQuickUtils *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->systemThemeChanged(); break;
        case 1: _t->systemAccentColorChanged(); break;
        case 2: _t->titleBarColorizedChanged(); break;
        case 3: { QColor _r = _t->getSystemButtonBackgroundColor((*reinterpret_cast< std::add_pointer_t<QuickGlobal::SystemButtonType>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QuickGlobal::ButtonState>>(_a[2])));
            if (_a[0]) *reinterpret_cast< QColor*>(_a[0]) = std::move(_r); }  break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (FramelessQuickUtils::*)();
            if (_t _q_method = &FramelessQuickUtils::systemThemeChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (FramelessQuickUtils::*)();
            if (_t _q_method = &FramelessQuickUtils::systemAccentColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (FramelessQuickUtils::*)();
            if (_t _q_method = &FramelessQuickUtils::titleBarColorizedChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
    }else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<FramelessQuickUtils *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< qreal*>(_v) = _t->titleBarHeight(); break;
        case 1: *reinterpret_cast< bool*>(_v) = _t->frameBorderVisible(); break;
        case 2: *reinterpret_cast< qreal*>(_v) = _t->frameBorderThickness(); break;
        case 3: *reinterpret_cast< QuickGlobal::SystemTheme*>(_v) = _t->systemTheme(); break;
        case 4: *reinterpret_cast< QColor*>(_v) = _t->systemAccentColor(); break;
        case 5: *reinterpret_cast< bool*>(_v) = _t->titleBarColorized(); break;
        case 6: *reinterpret_cast< QColor*>(_v) = _t->defaultSystemLightColor(); break;
        case 7: *reinterpret_cast< QColor*>(_v) = _t->defaultSystemDarkColor(); break;
        case 8: *reinterpret_cast< QSizeF*>(_v) = _t->defaultSystemButtonSize(); break;
        case 9: *reinterpret_cast< QSizeF*>(_v) = _t->defaultSystemButtonIconSize(); break;
        case 10: *reinterpret_cast< QColor*>(_v) = _t->defaultSystemButtonBackgroundColor(); break;
        case 11: *reinterpret_cast< QColor*>(_v) = _t->defaultSystemCloseButtonBackgroundColor(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
    } else if (_c == QMetaObject::ResetProperty) {
    } else if (_c == QMetaObject::BindableProperty) {
    }
}

const QMetaObject *wangwenx190::FramelessHelper::FramelessQuickUtils::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *wangwenx190::FramelessHelper::FramelessQuickUtils::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickUtilsENDCLASS.stringdata0))
        return static_cast<void*>(this);
    if (!strcmp(_clname, "QQmlParserStatus"))
        return static_cast< QQmlParserStatus*>(this);
    if (!strcmp(_clname, "org.qt-project.Qt.QQmlParserStatus"))
        return static_cast< QQmlParserStatus*>(this);
    return QObject::qt_metacast(_clname);
}

int wangwenx190::FramelessHelper::FramelessQuickUtils::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 4)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 4;
    }else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 12;
    }
    return _id;
}

// SIGNAL 0
void wangwenx190::FramelessHelper::FramelessQuickUtils::systemThemeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void wangwenx190::FramelessHelper::FramelessQuickUtils::systemAccentColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void wangwenx190::FramelessHelper::FramelessQuickUtils::titleBarColorizedChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}
QT_WARNING_POP
