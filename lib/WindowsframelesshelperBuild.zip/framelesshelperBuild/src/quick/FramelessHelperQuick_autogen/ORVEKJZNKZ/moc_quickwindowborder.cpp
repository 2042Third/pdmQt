/****************************************************************************
** Meta object code from reading C++ file 'quickwindowborder.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../framelesshelper-2.3.6/include/FramelessHelper/Quick/quickwindowborder.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'quickwindowborder.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickWindowBorderENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickWindowBorderENDCLASS = QtMocHelpers::stringData(
    "wangwenx190::FramelessHelper::QuickWindowBorder",
    "QML.Element",
    "WindowBorder",
    "thicknessChanged",
    "",
    "edgesChanged",
    "activeColorChanged",
    "inactiveColorChanged",
    "nativeBorderChanged",
    "setThickness",
    "value",
    "setEdges",
    "QuickGlobal::WindowEdges",
    "setActiveColor",
    "setInactiveColor",
    "thickness",
    "edges",
    "activeColor",
    "inactiveColor",
    "nativeThickness",
    "nativeEdges",
    "nativeActiveColor",
    "nativeInactiveColor"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickWindowBorderENDCLASS_t {
    uint offsetsAndSizes[46];
    char stringdata0[48];
    char stringdata1[12];
    char stringdata2[13];
    char stringdata3[17];
    char stringdata4[1];
    char stringdata5[13];
    char stringdata6[19];
    char stringdata7[21];
    char stringdata8[20];
    char stringdata9[13];
    char stringdata10[6];
    char stringdata11[9];
    char stringdata12[25];
    char stringdata13[15];
    char stringdata14[17];
    char stringdata15[10];
    char stringdata16[6];
    char stringdata17[12];
    char stringdata18[14];
    char stringdata19[16];
    char stringdata20[12];
    char stringdata21[18];
    char stringdata22[20];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickWindowBorderENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickWindowBorderENDCLASS_t qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickWindowBorderENDCLASS = {
    {
        QT_MOC_LITERAL(0, 47),  // "wangwenx190::FramelessHelper:..."
        QT_MOC_LITERAL(48, 11),  // "QML.Element"
        QT_MOC_LITERAL(60, 12),  // "WindowBorder"
        QT_MOC_LITERAL(73, 16),  // "thicknessChanged"
        QT_MOC_LITERAL(90, 0),  // ""
        QT_MOC_LITERAL(91, 12),  // "edgesChanged"
        QT_MOC_LITERAL(104, 18),  // "activeColorChanged"
        QT_MOC_LITERAL(123, 20),  // "inactiveColorChanged"
        QT_MOC_LITERAL(144, 19),  // "nativeBorderChanged"
        QT_MOC_LITERAL(164, 12),  // "setThickness"
        QT_MOC_LITERAL(177, 5),  // "value"
        QT_MOC_LITERAL(183, 8),  // "setEdges"
        QT_MOC_LITERAL(192, 24),  // "QuickGlobal::WindowEdges"
        QT_MOC_LITERAL(217, 14),  // "setActiveColor"
        QT_MOC_LITERAL(232, 16),  // "setInactiveColor"
        QT_MOC_LITERAL(249, 9),  // "thickness"
        QT_MOC_LITERAL(259, 5),  // "edges"
        QT_MOC_LITERAL(265, 11),  // "activeColor"
        QT_MOC_LITERAL(277, 13),  // "inactiveColor"
        QT_MOC_LITERAL(291, 15),  // "nativeThickness"
        QT_MOC_LITERAL(307, 11),  // "nativeEdges"
        QT_MOC_LITERAL(319, 17),  // "nativeActiveColor"
        QT_MOC_LITERAL(337, 19)   // "nativeInactiveColor"
    },
    "wangwenx190::FramelessHelper::QuickWindowBorder",
    "QML.Element",
    "WindowBorder",
    "thicknessChanged",
    "",
    "edgesChanged",
    "activeColorChanged",
    "inactiveColorChanged",
    "nativeBorderChanged",
    "setThickness",
    "value",
    "setEdges",
    "QuickGlobal::WindowEdges",
    "setActiveColor",
    "setInactiveColor",
    "thickness",
    "edges",
    "activeColor",
    "inactiveColor",
    "nativeThickness",
    "nativeEdges",
    "nativeActiveColor",
    "nativeInactiveColor"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickWindowBorderENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       1,   14, // classinfo
       9,   16, // methods
       8,   87, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // classinfo: key, value
       1,    2,

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       3,    0,   70,    4, 0x06,    9 /* Public */,
       5,    0,   71,    4, 0x06,   10 /* Public */,
       6,    0,   72,    4, 0x06,   11 /* Public */,
       7,    0,   73,    4, 0x06,   12 /* Public */,
       8,    0,   74,    4, 0x06,   13 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       9,    1,   75,    4, 0x0a,   14 /* Public */,
      11,    1,   78,    4, 0x0a,   16 /* Public */,
      13,    1,   81,    4, 0x0a,   18 /* Public */,
      14,    1,   84,    4, 0x0a,   20 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::QReal,   10,
    QMetaType::Void, 0x80000000 | 12,   10,
    QMetaType::Void, QMetaType::QColor,   10,
    QMetaType::Void, QMetaType::QColor,   10,

 // properties: name, type, flags
      15, QMetaType::QReal, 0x00015903, uint(0), 0,
      16, 0x80000000 | 12, 0x0001590b, uint(1), 0,
      17, QMetaType::QColor, 0x00015903, uint(2), 0,
      18, QMetaType::QColor, 0x00015903, uint(3), 0,
      19, QMetaType::QReal, 0x00015801, uint(4), 0,
      20, 0x80000000 | 12, 0x00015809, uint(4), 0,
      21, QMetaType::QColor, 0x00015801, uint(4), 0,
      22, QMetaType::QColor, 0x00015801, uint(4), 0,

       0        // eod
};

Q_CONSTINIT static const QMetaObject::SuperData qt_meta_extradata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickWindowBorderENDCLASS[] = {
    QMetaObject::SuperData::link<wangwenx190::FramelessHelper::QuickGlobal::staticMetaObject>(),
    nullptr
};

Q_CONSTINIT const QMetaObject wangwenx190::FramelessHelper::QuickWindowBorder::staticMetaObject = { {
    QMetaObject::SuperData::link<QQuickPaintedItem::staticMetaObject>(),
    qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickWindowBorderENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickWindowBorderENDCLASS,
    qt_static_metacall,
    qt_meta_extradata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickWindowBorderENDCLASS,
    qt_metaTypeArray<
        // property 'thickness'
        qreal,
        // property 'edges'
        QuickGlobal::WindowEdges,
        // property 'activeColor'
        QColor,
        // property 'inactiveColor'
        QColor,
        // property 'nativeThickness'
        qreal,
        // property 'nativeEdges'
        QuickGlobal::WindowEdges,
        // property 'nativeActiveColor'
        QColor,
        // property 'nativeInactiveColor'
        QColor,
        // Q_OBJECT / Q_GADGET
        QuickWindowBorder,
        // method 'thicknessChanged'
        void,
        // method 'edgesChanged'
        void,
        // method 'activeColorChanged'
        void,
        // method 'inactiveColorChanged'
        void,
        // method 'nativeBorderChanged'
        void,
        // method 'setThickness'
        void,
        const qreal,
        // method 'setEdges'
        void,
        const QuickGlobal::WindowEdges,
        // method 'setActiveColor'
        void,
        const QColor &,
        // method 'setInactiveColor'
        void,
        const QColor &
    >,
    nullptr
} };

void wangwenx190::FramelessHelper::QuickWindowBorder::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<QuickWindowBorder *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->thicknessChanged(); break;
        case 1: _t->edgesChanged(); break;
        case 2: _t->activeColorChanged(); break;
        case 3: _t->inactiveColorChanged(); break;
        case 4: _t->nativeBorderChanged(); break;
        case 5: _t->setThickness((*reinterpret_cast< std::add_pointer_t<qreal>>(_a[1]))); break;
        case 6: _t->setEdges((*reinterpret_cast< std::add_pointer_t<QuickGlobal::WindowEdges>>(_a[1]))); break;
        case 7: _t->setActiveColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 8: _t->setInactiveColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (QuickWindowBorder::*)();
            if (_t _q_method = &QuickWindowBorder::thicknessChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (QuickWindowBorder::*)();
            if (_t _q_method = &QuickWindowBorder::edgesChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (QuickWindowBorder::*)();
            if (_t _q_method = &QuickWindowBorder::activeColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (QuickWindowBorder::*)();
            if (_t _q_method = &QuickWindowBorder::inactiveColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (QuickWindowBorder::*)();
            if (_t _q_method = &QuickWindowBorder::nativeBorderChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
    }else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<QuickWindowBorder *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< qreal*>(_v) = _t->thickness(); break;
        case 1: *reinterpret_cast< QuickGlobal::WindowEdges*>(_v) = _t->edges(); break;
        case 2: *reinterpret_cast< QColor*>(_v) = _t->activeColor(); break;
        case 3: *reinterpret_cast< QColor*>(_v) = _t->inactiveColor(); break;
        case 4: *reinterpret_cast< qreal*>(_v) = _t->nativeThickness(); break;
        case 5: *reinterpret_cast< QuickGlobal::WindowEdges*>(_v) = _t->nativeEdges(); break;
        case 6: *reinterpret_cast< QColor*>(_v) = _t->nativeActiveColor(); break;
        case 7: *reinterpret_cast< QColor*>(_v) = _t->nativeInactiveColor(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<QuickWindowBorder *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setThickness(*reinterpret_cast< qreal*>(_v)); break;
        case 1: _t->setEdges(*reinterpret_cast< QuickGlobal::WindowEdges*>(_v)); break;
        case 2: _t->setActiveColor(*reinterpret_cast< QColor*>(_v)); break;
        case 3: _t->setInactiveColor(*reinterpret_cast< QColor*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    } else if (_c == QMetaObject::BindableProperty) {
    }
}

const QMetaObject *wangwenx190::FramelessHelper::QuickWindowBorder::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *wangwenx190::FramelessHelper::QuickWindowBorder::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEQuickWindowBorderENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QQuickPaintedItem::qt_metacast(_clname);
}

int wangwenx190::FramelessHelper::QuickWindowBorder::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QQuickPaintedItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 9;
    }else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void wangwenx190::FramelessHelper::QuickWindowBorder::thicknessChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void wangwenx190::FramelessHelper::QuickWindowBorder::edgesChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void wangwenx190::FramelessHelper::QuickWindowBorder::activeColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void wangwenx190::FramelessHelper::QuickWindowBorder::inactiveColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void wangwenx190::FramelessHelper::QuickWindowBorder::nativeBorderChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}
QT_WARNING_POP
