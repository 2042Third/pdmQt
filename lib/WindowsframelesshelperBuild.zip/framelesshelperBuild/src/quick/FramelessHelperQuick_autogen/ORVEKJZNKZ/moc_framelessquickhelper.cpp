/****************************************************************************
** Meta object code from reading C++ file 'framelessquickhelper.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../framelesshelper-2.3.6/include/FramelessHelper/Quick/framelessquickhelper.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'framelessquickhelper.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickHelperENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickHelperENDCLASS = QtMocHelpers::stringData(
    "wangwenx190::FramelessHelper::FramelessQuickHelper",
    "QML.Element",
    "FramelessHelper",
    "QML.Attached",
    "FramelessQuickHelper",
    "extendsContentIntoTitleBarChanged",
    "",
    "titleBarItemChanged",
    "windowFixedSizeChanged",
    "blurBehindWindowEnabledChanged",
    "windowChanged2",
    "ready",
    "extendsContentIntoTitleBar",
    "value",
    "setTitleBarItem",
    "QQuickItem*",
    "setSystemButton",
    "item",
    "QuickGlobal::SystemButtonType",
    "buttonType",
    "setHitTestVisible",
    "visible",
    "setHitTestVisible_rect",
    "rect",
    "setHitTestVisible_object",
    "object",
    "setHitTestVisible_item",
    "showSystemMenu",
    "pos",
    "windowStartSystemMove2",
    "windowStartSystemResize2",
    "Qt::Edges",
    "edges",
    "moveWindowToDesktopCenter",
    "bringWindowToFront",
    "setWindowFixedSize",
    "setBlurBehindWindowEnabled",
    "titleBarItem",
    "windowFixedSize",
    "blurBehindWindowEnabled",
    "window",
    "QQuickWindow*"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickHelperENDCLASS_t {
    uint offsetsAndSizes[84];
    char stringdata0[51];
    char stringdata1[12];
    char stringdata2[16];
    char stringdata3[13];
    char stringdata4[21];
    char stringdata5[34];
    char stringdata6[1];
    char stringdata7[20];
    char stringdata8[23];
    char stringdata9[31];
    char stringdata10[15];
    char stringdata11[6];
    char stringdata12[27];
    char stringdata13[6];
    char stringdata14[16];
    char stringdata15[12];
    char stringdata16[16];
    char stringdata17[5];
    char stringdata18[30];
    char stringdata19[11];
    char stringdata20[18];
    char stringdata21[8];
    char stringdata22[23];
    char stringdata23[5];
    char stringdata24[25];
    char stringdata25[7];
    char stringdata26[23];
    char stringdata27[15];
    char stringdata28[4];
    char stringdata29[23];
    char stringdata30[25];
    char stringdata31[10];
    char stringdata32[6];
    char stringdata33[26];
    char stringdata34[19];
    char stringdata35[19];
    char stringdata36[27];
    char stringdata37[13];
    char stringdata38[16];
    char stringdata39[24];
    char stringdata40[7];
    char stringdata41[14];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickHelperENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickHelperENDCLASS_t qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickHelperENDCLASS = {
    {
        QT_MOC_LITERAL(0, 50),  // "wangwenx190::FramelessHelper:..."
        QT_MOC_LITERAL(51, 11),  // "QML.Element"
        QT_MOC_LITERAL(63, 15),  // "FramelessHelper"
        QT_MOC_LITERAL(79, 12),  // "QML.Attached"
        QT_MOC_LITERAL(92, 20),  // "FramelessQuickHelper"
        QT_MOC_LITERAL(113, 33),  // "extendsContentIntoTitleBarCha..."
        QT_MOC_LITERAL(147, 0),  // ""
        QT_MOC_LITERAL(148, 19),  // "titleBarItemChanged"
        QT_MOC_LITERAL(168, 22),  // "windowFixedSizeChanged"
        QT_MOC_LITERAL(191, 30),  // "blurBehindWindowEnabledChanged"
        QT_MOC_LITERAL(222, 14),  // "windowChanged2"
        QT_MOC_LITERAL(237, 5),  // "ready"
        QT_MOC_LITERAL(243, 26),  // "extendsContentIntoTitleBar"
        QT_MOC_LITERAL(270, 5),  // "value"
        QT_MOC_LITERAL(276, 15),  // "setTitleBarItem"
        QT_MOC_LITERAL(292, 11),  // "QQuickItem*"
        QT_MOC_LITERAL(304, 15),  // "setSystemButton"
        QT_MOC_LITERAL(320, 4),  // "item"
        QT_MOC_LITERAL(325, 29),  // "QuickGlobal::SystemButtonType"
        QT_MOC_LITERAL(355, 10),  // "buttonType"
        QT_MOC_LITERAL(366, 17),  // "setHitTestVisible"
        QT_MOC_LITERAL(384, 7),  // "visible"
        QT_MOC_LITERAL(392, 22),  // "setHitTestVisible_rect"
        QT_MOC_LITERAL(415, 4),  // "rect"
        QT_MOC_LITERAL(420, 24),  // "setHitTestVisible_object"
        QT_MOC_LITERAL(445, 6),  // "object"
        QT_MOC_LITERAL(452, 22),  // "setHitTestVisible_item"
        QT_MOC_LITERAL(475, 14),  // "showSystemMenu"
        QT_MOC_LITERAL(490, 3),  // "pos"
        QT_MOC_LITERAL(494, 22),  // "windowStartSystemMove2"
        QT_MOC_LITERAL(517, 24),  // "windowStartSystemResize2"
        QT_MOC_LITERAL(542, 9),  // "Qt::Edges"
        QT_MOC_LITERAL(552, 5),  // "edges"
        QT_MOC_LITERAL(558, 25),  // "moveWindowToDesktopCenter"
        QT_MOC_LITERAL(584, 18),  // "bringWindowToFront"
        QT_MOC_LITERAL(603, 18),  // "setWindowFixedSize"
        QT_MOC_LITERAL(622, 26),  // "setBlurBehindWindowEnabled"
        QT_MOC_LITERAL(649, 12),  // "titleBarItem"
        QT_MOC_LITERAL(662, 15),  // "windowFixedSize"
        QT_MOC_LITERAL(678, 23),  // "blurBehindWindowEnabled"
        QT_MOC_LITERAL(702, 6),  // "window"
        QT_MOC_LITERAL(709, 13)   // "QQuickWindow*"
    },
    "wangwenx190::FramelessHelper::FramelessQuickHelper",
    "QML.Element",
    "FramelessHelper",
    "QML.Attached",
    "FramelessQuickHelper",
    "extendsContentIntoTitleBarChanged",
    "",
    "titleBarItemChanged",
    "windowFixedSizeChanged",
    "blurBehindWindowEnabledChanged",
    "windowChanged2",
    "ready",
    "extendsContentIntoTitleBar",
    "value",
    "setTitleBarItem",
    "QQuickItem*",
    "setSystemButton",
    "item",
    "QuickGlobal::SystemButtonType",
    "buttonType",
    "setHitTestVisible",
    "visible",
    "setHitTestVisible_rect",
    "rect",
    "setHitTestVisible_object",
    "object",
    "setHitTestVisible_item",
    "showSystemMenu",
    "pos",
    "windowStartSystemMove2",
    "windowStartSystemResize2",
    "Qt::Edges",
    "edges",
    "moveWindowToDesktopCenter",
    "bringWindowToFront",
    "setWindowFixedSize",
    "setBlurBehindWindowEnabled",
    "titleBarItem",
    "windowFixedSize",
    "blurBehindWindowEnabled",
    "window",
    "QQuickWindow*"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickHelperENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       2,   14, // classinfo
      25,   18, // methods
       5,  237, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // classinfo: key, value
       1,    2,
       3,    4,

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       5,    0,  168,    6, 0x06,    6 /* Public */,
       7,    0,  169,    6, 0x06,    7 /* Public */,
       8,    0,  170,    6, 0x06,    8 /* Public */,
       9,    0,  171,    6, 0x06,    9 /* Public */,
      10,    0,  172,    6, 0x06,   10 /* Public */,
      11,    0,  173,    6, 0x06,   11 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      12,    1,  174,    6, 0x0a,   12 /* Public */,
      12,    0,  177,    6, 0x2a,   14 /* Public | MethodCloned */,
      14,    1,  178,    6, 0x0a,   15 /* Public */,
      16,    2,  181,    6, 0x0a,   17 /* Public */,
      20,    2,  186,    6, 0x0a,   20 /* Public */,
      20,    1,  191,    6, 0x2a,   23 /* Public | MethodCloned */,
      22,    2,  194,    6, 0x0a,   25 /* Public */,
      22,    1,  199,    6, 0x2a,   28 /* Public | MethodCloned */,
      24,    2,  202,    6, 0x0a,   30 /* Public */,
      24,    1,  207,    6, 0x2a,   33 /* Public | MethodCloned */,
      26,    2,  210,    6, 0x0a,   35 /* Public */,
      26,    1,  215,    6, 0x2a,   38 /* Public | MethodCloned */,
      27,    1,  218,    6, 0x0a,   40 /* Public */,
      29,    1,  221,    6, 0x0a,   42 /* Public */,
      30,    2,  224,    6, 0x0a,   44 /* Public */,
      33,    0,  229,    6, 0x0a,   47 /* Public */,
      34,    0,  230,    6, 0x0a,   48 /* Public */,
      35,    1,  231,    6, 0x0a,   49 /* Public */,
      36,    1,  234,    6, 0x0a,   51 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,   13,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 15,   13,
    QMetaType::Void, 0x80000000 | 15, 0x80000000 | 18,   17,   19,
    QMetaType::Void, 0x80000000 | 15, QMetaType::Bool,   17,   21,
    QMetaType::Void, 0x80000000 | 15,   17,
    QMetaType::Void, QMetaType::QRect, QMetaType::Bool,   23,   21,
    QMetaType::Void, QMetaType::QRect,   23,
    QMetaType::Void, QMetaType::QObjectStar, QMetaType::Bool,   25,   21,
    QMetaType::Void, QMetaType::QObjectStar,   25,
    QMetaType::Void, 0x80000000 | 15, QMetaType::Bool,   17,   21,
    QMetaType::Void, 0x80000000 | 15,   17,
    QMetaType::Void, QMetaType::QPoint,   28,
    QMetaType::Void, QMetaType::QPoint,   28,
    QMetaType::Void, 0x80000000 | 31, QMetaType::QPoint,   32,   28,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   13,
    QMetaType::Void, QMetaType::Bool,   13,

 // properties: name, type, flags
      37, 0x80000000 | 15, 0x0001590b, uint(1), 0,
      38, QMetaType::Bool, 0x00015903, uint(2), 0,
      39, QMetaType::Bool, 0x00015903, uint(3), 0,
      40, 0x80000000 | 41, 0x00015809, uint(4), 0,
      12, QMetaType::Bool, 0x00015803, uint(0), 0,

       0        // eod
};

Q_CONSTINIT const QMetaObject wangwenx190::FramelessHelper::FramelessQuickHelper::staticMetaObject = { {
    QMetaObject::SuperData::link<QQuickItem::staticMetaObject>(),
    qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickHelperENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickHelperENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_metaTypeArray<
        // property 'titleBarItem'
        QQuickItem*,
        // property 'windowFixedSize'
        bool,
        // property 'blurBehindWindowEnabled'
        bool,
        // property 'window'
        QQuickWindow*,
        // property 'extendsContentIntoTitleBar'
        bool,
        // Q_OBJECT / Q_GADGET
        FramelessQuickHelper,
        // method 'extendsContentIntoTitleBarChanged'
        void,
        // method 'titleBarItemChanged'
        void,
        // method 'windowFixedSizeChanged'
        void,
        // method 'blurBehindWindowEnabledChanged'
        void,
        // method 'windowChanged2'
        void,
        // method 'ready'
        void,
        // method 'extendsContentIntoTitleBar'
        void,
        const bool,
        // method 'extendsContentIntoTitleBar'
        void,
        // method 'setTitleBarItem'
        void,
        QQuickItem *,
        // method 'setSystemButton'
        void,
        QQuickItem *,
        const QuickGlobal::SystemButtonType,
        // method 'setHitTestVisible'
        void,
        QQuickItem *,
        const bool,
        // method 'setHitTestVisible'
        void,
        QQuickItem *,
        // method 'setHitTestVisible_rect'
        void,
        const QRect &,
        const bool,
        // method 'setHitTestVisible_rect'
        void,
        const QRect &,
        // method 'setHitTestVisible_object'
        void,
        QObject *,
        const bool,
        // method 'setHitTestVisible_object'
        void,
        QObject *,
        // method 'setHitTestVisible_item'
        void,
        QQuickItem *,
        const bool,
        // method 'setHitTestVisible_item'
        void,
        QQuickItem *,
        // method 'showSystemMenu'
        void,
        const QPoint &,
        // method 'windowStartSystemMove2'
        void,
        const QPoint &,
        // method 'windowStartSystemResize2'
        void,
        const Qt::Edges,
        const QPoint &,
        // method 'moveWindowToDesktopCenter'
        void,
        // method 'bringWindowToFront'
        void,
        // method 'setWindowFixedSize'
        void,
        const bool,
        // method 'setBlurBehindWindowEnabled'
        void,
        const bool
    >,
    nullptr
} };

void wangwenx190::FramelessHelper::FramelessQuickHelper::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<FramelessQuickHelper *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->extendsContentIntoTitleBarChanged(); break;
        case 1: _t->titleBarItemChanged(); break;
        case 2: _t->windowFixedSizeChanged(); break;
        case 3: _t->blurBehindWindowEnabledChanged(); break;
        case 4: _t->windowChanged2(); break;
        case 5: _t->ready(); break;
        case 6: _t->extendsContentIntoTitleBar((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 7: _t->extendsContentIntoTitleBar(); break;
        case 8: _t->setTitleBarItem((*reinterpret_cast< std::add_pointer_t<QQuickItem*>>(_a[1]))); break;
        case 9: _t->setSystemButton((*reinterpret_cast< std::add_pointer_t<QQuickItem*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QuickGlobal::SystemButtonType>>(_a[2]))); break;
        case 10: _t->setHitTestVisible((*reinterpret_cast< std::add_pointer_t<QQuickItem*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 11: _t->setHitTestVisible((*reinterpret_cast< std::add_pointer_t<QQuickItem*>>(_a[1]))); break;
        case 12: _t->setHitTestVisible_rect((*reinterpret_cast< std::add_pointer_t<QRect>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 13: _t->setHitTestVisible_rect((*reinterpret_cast< std::add_pointer_t<QRect>>(_a[1]))); break;
        case 14: _t->setHitTestVisible_object((*reinterpret_cast< std::add_pointer_t<QObject*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 15: _t->setHitTestVisible_object((*reinterpret_cast< std::add_pointer_t<QObject*>>(_a[1]))); break;
        case 16: _t->setHitTestVisible_item((*reinterpret_cast< std::add_pointer_t<QQuickItem*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[2]))); break;
        case 17: _t->setHitTestVisible_item((*reinterpret_cast< std::add_pointer_t<QQuickItem*>>(_a[1]))); break;
        case 18: _t->showSystemMenu((*reinterpret_cast< std::add_pointer_t<QPoint>>(_a[1]))); break;
        case 19: _t->windowStartSystemMove2((*reinterpret_cast< std::add_pointer_t<QPoint>>(_a[1]))); break;
        case 20: _t->windowStartSystemResize2((*reinterpret_cast< std::add_pointer_t<Qt::Edges>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QPoint>>(_a[2]))); break;
        case 21: _t->moveWindowToDesktopCenter(); break;
        case 22: _t->bringWindowToFront(); break;
        case 23: _t->setWindowFixedSize((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        case 24: _t->setBlurBehindWindowEnabled((*reinterpret_cast< std::add_pointer_t<bool>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
        case 8:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QQuickItem* >(); break;
            }
            break;
        case 9:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QQuickItem* >(); break;
            }
            break;
        case 10:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QQuickItem* >(); break;
            }
            break;
        case 11:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QQuickItem* >(); break;
            }
            break;
        case 16:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QQuickItem* >(); break;
            }
            break;
        case 17:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType(); break;
            case 0:
                *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType::fromType< QQuickItem* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (FramelessQuickHelper::*)();
            if (_t _q_method = &FramelessQuickHelper::extendsContentIntoTitleBarChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (FramelessQuickHelper::*)();
            if (_t _q_method = &FramelessQuickHelper::titleBarItemChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (FramelessQuickHelper::*)();
            if (_t _q_method = &FramelessQuickHelper::windowFixedSizeChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (FramelessQuickHelper::*)();
            if (_t _q_method = &FramelessQuickHelper::blurBehindWindowEnabledChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (FramelessQuickHelper::*)();
            if (_t _q_method = &FramelessQuickHelper::windowChanged2; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (FramelessQuickHelper::*)();
            if (_t _q_method = &FramelessQuickHelper::ready; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QQuickItem* >(); break;
        case 3:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QQuickWindow* >(); break;
        }
    } else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<FramelessQuickHelper *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QQuickItem**>(_v) = _t->titleBarItem(); break;
        case 1: *reinterpret_cast< bool*>(_v) = _t->isWindowFixedSize(); break;
        case 2: *reinterpret_cast< bool*>(_v) = _t->isBlurBehindWindowEnabled(); break;
        case 3: *reinterpret_cast< QQuickWindow**>(_v) = _t->window(); break;
        case 4: *reinterpret_cast< bool*>(_v) = _t->isContentExtendedIntoTitleBar(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<FramelessQuickHelper *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setTitleBarItem(*reinterpret_cast< QQuickItem**>(_v)); break;
        case 1: _t->setWindowFixedSize(*reinterpret_cast< bool*>(_v)); break;
        case 2: _t->setBlurBehindWindowEnabled(*reinterpret_cast< bool*>(_v)); break;
        case 4: _t->extendsContentIntoTitleBar(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    } else if (_c == QMetaObject::BindableProperty) {
    }
}

const QMetaObject *wangwenx190::FramelessHelper::FramelessQuickHelper::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *wangwenx190::FramelessHelper::FramelessQuickHelper::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessQuickHelperENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QQuickItem::qt_metacast(_clname);
}

int wangwenx190::FramelessHelper::FramelessQuickHelper::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QQuickItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    }else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void wangwenx190::FramelessHelper::FramelessQuickHelper::extendsContentIntoTitleBarChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void wangwenx190::FramelessHelper::FramelessQuickHelper::titleBarItemChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void wangwenx190::FramelessHelper::FramelessQuickHelper::windowFixedSizeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void wangwenx190::FramelessHelper::FramelessQuickHelper::blurBehindWindowEnabledChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void wangwenx190::FramelessHelper::FramelessQuickHelper::windowChanged2()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void wangwenx190::FramelessHelper::FramelessQuickHelper::ready()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}
QT_WARNING_POP
