/****************************************************************************
** Meta object code from reading C++ file 'framelesshelpercore_global.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../framelesshelper-2.3.6/include/FramelessHelper/Core/framelesshelpercore_global.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'framelesshelpercore_global.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEGlobalENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEGlobalENDCLASS = QtMocHelpers::stringData(
    "wangwenx190::FramelessHelper::Global",
    "Option",
    "UseCrossPlatformQtImplementation",
    "ForceHideWindowFrameBorder",
    "ForceShowWindowFrameBorder",
    "DisableWindowsSnapLayout",
    "WindowUseRoundCorners",
    "CenterWindowBeforeShow",
    "EnableBlurBehindWindow",
    "ForceNonNativeBackgroundBlur",
    "DisableLazyInitializationForMicaMaterial",
    "ForceNativeBackgroundBlur",
    "SystemTheme",
    "Unknown",
    "Light",
    "Dark",
    "HighContrast",
    "SystemButtonType",
    "WindowIcon",
    "Help",
    "Minimize",
    "Maximize",
    "Restore",
    "Close",
    "DwmColorizationArea",
    "None",
    "StartMenu_TaskBar_ActionCenter",
    "TitleBar_WindowBorder",
    "All",
    "ButtonState",
    "Normal",
    "Hovered",
    "Pressed",
    "Released",
    "WindowsVersion",
    "_2000",
    "_XP",
    "_XP_64",
    "_Vista",
    "_Vista_SP1",
    "_Vista_SP2",
    "_7",
    "_7_SP1",
    "_8",
    "_8_1",
    "_8_1_Update1",
    "_10_1507",
    "_10_1511",
    "_10_1607",
    "_10_1703",
    "_10_1709",
    "_10_1803",
    "_10_1809",
    "_10_1903",
    "_10_1909",
    "_10_2004",
    "_10_20H2",
    "_10_21H1",
    "_10_21H2",
    "_10_22H2",
    "_11_21H2",
    "_11_22H2",
    "_WS_03",
    "_10",
    "_11",
    "Latest",
    "BlurMode",
    "Disable",
    "Default",
    "Windows_Aero",
    "Windows_Acrylic",
    "Windows_Mica",
    "Windows_MicaAlt",
    "WallpaperAspectStyle",
    "Fill",
    "Fit",
    "Stretch",
    "Tile",
    "Center",
    "Span",
    "RegistryRootKey",
    "ClassesRoot",
    "CurrentUser",
    "LocalMachine",
    "Users",
    "PerformanceData",
    "CurrentConfig",
    "DynData",
    "CurrentUserLocalSettings",
    "PerformanceText",
    "PerformanceNlsText",
    "WindowEdge",
    "Left",
    "Top",
    "Right",
    "Bottom",
    "WindowEdges",
    "DpiAwareness",
    "Unaware",
    "System",
    "PerMonitor",
    "PerMonitorVersion2",
    "Unaware_GdiScaled",
    "WindowCornerStyle",
    "Square",
    "Round"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEGlobalENDCLASS_t {
    uint offsetsAndSizes[212];
    char stringdata0[37];
    char stringdata1[7];
    char stringdata2[33];
    char stringdata3[27];
    char stringdata4[27];
    char stringdata5[25];
    char stringdata6[22];
    char stringdata7[23];
    char stringdata8[23];
    char stringdata9[29];
    char stringdata10[41];
    char stringdata11[26];
    char stringdata12[12];
    char stringdata13[8];
    char stringdata14[6];
    char stringdata15[5];
    char stringdata16[13];
    char stringdata17[17];
    char stringdata18[11];
    char stringdata19[5];
    char stringdata20[9];
    char stringdata21[9];
    char stringdata22[8];
    char stringdata23[6];
    char stringdata24[20];
    char stringdata25[5];
    char stringdata26[31];
    char stringdata27[22];
    char stringdata28[4];
    char stringdata29[12];
    char stringdata30[7];
    char stringdata31[8];
    char stringdata32[8];
    char stringdata33[9];
    char stringdata34[15];
    char stringdata35[6];
    char stringdata36[4];
    char stringdata37[7];
    char stringdata38[7];
    char stringdata39[11];
    char stringdata40[11];
    char stringdata41[3];
    char stringdata42[7];
    char stringdata43[3];
    char stringdata44[5];
    char stringdata45[13];
    char stringdata46[9];
    char stringdata47[9];
    char stringdata48[9];
    char stringdata49[9];
    char stringdata50[9];
    char stringdata51[9];
    char stringdata52[9];
    char stringdata53[9];
    char stringdata54[9];
    char stringdata55[9];
    char stringdata56[9];
    char stringdata57[9];
    char stringdata58[9];
    char stringdata59[9];
    char stringdata60[9];
    char stringdata61[9];
    char stringdata62[7];
    char stringdata63[4];
    char stringdata64[4];
    char stringdata65[7];
    char stringdata66[9];
    char stringdata67[8];
    char stringdata68[8];
    char stringdata69[13];
    char stringdata70[16];
    char stringdata71[13];
    char stringdata72[16];
    char stringdata73[21];
    char stringdata74[5];
    char stringdata75[4];
    char stringdata76[8];
    char stringdata77[5];
    char stringdata78[7];
    char stringdata79[5];
    char stringdata80[16];
    char stringdata81[12];
    char stringdata82[12];
    char stringdata83[13];
    char stringdata84[6];
    char stringdata85[16];
    char stringdata86[14];
    char stringdata87[8];
    char stringdata88[25];
    char stringdata89[16];
    char stringdata90[19];
    char stringdata91[11];
    char stringdata92[5];
    char stringdata93[4];
    char stringdata94[6];
    char stringdata95[7];
    char stringdata96[12];
    char stringdata97[13];
    char stringdata98[8];
    char stringdata99[7];
    char stringdata100[11];
    char stringdata101[19];
    char stringdata102[18];
    char stringdata103[18];
    char stringdata104[7];
    char stringdata105[6];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEGlobalENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEGlobalENDCLASS_t qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEGlobalENDCLASS = {
    {
        QT_MOC_LITERAL(0, 36),  // "wangwenx190::FramelessHelper:..."
        QT_MOC_LITERAL(37, 6),  // "Option"
        QT_MOC_LITERAL(44, 32),  // "UseCrossPlatformQtImplementation"
        QT_MOC_LITERAL(77, 26),  // "ForceHideWindowFrameBorder"
        QT_MOC_LITERAL(104, 26),  // "ForceShowWindowFrameBorder"
        QT_MOC_LITERAL(131, 24),  // "DisableWindowsSnapLayout"
        QT_MOC_LITERAL(156, 21),  // "WindowUseRoundCorners"
        QT_MOC_LITERAL(178, 22),  // "CenterWindowBeforeShow"
        QT_MOC_LITERAL(201, 22),  // "EnableBlurBehindWindow"
        QT_MOC_LITERAL(224, 28),  // "ForceNonNativeBackgroundBlur"
        QT_MOC_LITERAL(253, 40),  // "DisableLazyInitializationForM..."
        QT_MOC_LITERAL(294, 25),  // "ForceNativeBackgroundBlur"
        QT_MOC_LITERAL(320, 11),  // "SystemTheme"
        QT_MOC_LITERAL(332, 7),  // "Unknown"
        QT_MOC_LITERAL(340, 5),  // "Light"
        QT_MOC_LITERAL(346, 4),  // "Dark"
        QT_MOC_LITERAL(351, 12),  // "HighContrast"
        QT_MOC_LITERAL(364, 16),  // "SystemButtonType"
        QT_MOC_LITERAL(381, 10),  // "WindowIcon"
        QT_MOC_LITERAL(392, 4),  // "Help"
        QT_MOC_LITERAL(397, 8),  // "Minimize"
        QT_MOC_LITERAL(406, 8),  // "Maximize"
        QT_MOC_LITERAL(415, 7),  // "Restore"
        QT_MOC_LITERAL(423, 5),  // "Close"
        QT_MOC_LITERAL(429, 19),  // "DwmColorizationArea"
        QT_MOC_LITERAL(449, 4),  // "None"
        QT_MOC_LITERAL(454, 30),  // "StartMenu_TaskBar_ActionCenter"
        QT_MOC_LITERAL(485, 21),  // "TitleBar_WindowBorder"
        QT_MOC_LITERAL(507, 3),  // "All"
        QT_MOC_LITERAL(511, 11),  // "ButtonState"
        QT_MOC_LITERAL(523, 6),  // "Normal"
        QT_MOC_LITERAL(530, 7),  // "Hovered"
        QT_MOC_LITERAL(538, 7),  // "Pressed"
        QT_MOC_LITERAL(546, 8),  // "Released"
        QT_MOC_LITERAL(555, 14),  // "WindowsVersion"
        QT_MOC_LITERAL(570, 5),  // "_2000"
        QT_MOC_LITERAL(576, 3),  // "_XP"
        QT_MOC_LITERAL(580, 6),  // "_XP_64"
        QT_MOC_LITERAL(587, 6),  // "_Vista"
        QT_MOC_LITERAL(594, 10),  // "_Vista_SP1"
        QT_MOC_LITERAL(605, 10),  // "_Vista_SP2"
        QT_MOC_LITERAL(616, 2),  // "_7"
        QT_MOC_LITERAL(619, 6),  // "_7_SP1"
        QT_MOC_LITERAL(626, 2),  // "_8"
        QT_MOC_LITERAL(629, 4),  // "_8_1"
        QT_MOC_LITERAL(634, 12),  // "_8_1_Update1"
        QT_MOC_LITERAL(647, 8),  // "_10_1507"
        QT_MOC_LITERAL(656, 8),  // "_10_1511"
        QT_MOC_LITERAL(665, 8),  // "_10_1607"
        QT_MOC_LITERAL(674, 8),  // "_10_1703"
        QT_MOC_LITERAL(683, 8),  // "_10_1709"
        QT_MOC_LITERAL(692, 8),  // "_10_1803"
        QT_MOC_LITERAL(701, 8),  // "_10_1809"
        QT_MOC_LITERAL(710, 8),  // "_10_1903"
        QT_MOC_LITERAL(719, 8),  // "_10_1909"
        QT_MOC_LITERAL(728, 8),  // "_10_2004"
        QT_MOC_LITERAL(737, 8),  // "_10_20H2"
        QT_MOC_LITERAL(746, 8),  // "_10_21H1"
        QT_MOC_LITERAL(755, 8),  // "_10_21H2"
        QT_MOC_LITERAL(764, 8),  // "_10_22H2"
        QT_MOC_LITERAL(773, 8),  // "_11_21H2"
        QT_MOC_LITERAL(782, 8),  // "_11_22H2"
        QT_MOC_LITERAL(791, 6),  // "_WS_03"
        QT_MOC_LITERAL(798, 3),  // "_10"
        QT_MOC_LITERAL(802, 3),  // "_11"
        QT_MOC_LITERAL(806, 6),  // "Latest"
        QT_MOC_LITERAL(813, 8),  // "BlurMode"
        QT_MOC_LITERAL(822, 7),  // "Disable"
        QT_MOC_LITERAL(830, 7),  // "Default"
        QT_MOC_LITERAL(838, 12),  // "Windows_Aero"
        QT_MOC_LITERAL(851, 15),  // "Windows_Acrylic"
        QT_MOC_LITERAL(867, 12),  // "Windows_Mica"
        QT_MOC_LITERAL(880, 15),  // "Windows_MicaAlt"
        QT_MOC_LITERAL(896, 20),  // "WallpaperAspectStyle"
        QT_MOC_LITERAL(917, 4),  // "Fill"
        QT_MOC_LITERAL(922, 3),  // "Fit"
        QT_MOC_LITERAL(926, 7),  // "Stretch"
        QT_MOC_LITERAL(934, 4),  // "Tile"
        QT_MOC_LITERAL(939, 6),  // "Center"
        QT_MOC_LITERAL(946, 4),  // "Span"
        QT_MOC_LITERAL(951, 15),  // "RegistryRootKey"
        QT_MOC_LITERAL(967, 11),  // "ClassesRoot"
        QT_MOC_LITERAL(979, 11),  // "CurrentUser"
        QT_MOC_LITERAL(991, 12),  // "LocalMachine"
        QT_MOC_LITERAL(1004, 5),  // "Users"
        QT_MOC_LITERAL(1010, 15),  // "PerformanceData"
        QT_MOC_LITERAL(1026, 13),  // "CurrentConfig"
        QT_MOC_LITERAL(1040, 7),  // "DynData"
        QT_MOC_LITERAL(1048, 24),  // "CurrentUserLocalSettings"
        QT_MOC_LITERAL(1073, 15),  // "PerformanceText"
        QT_MOC_LITERAL(1089, 18),  // "PerformanceNlsText"
        QT_MOC_LITERAL(1108, 10),  // "WindowEdge"
        QT_MOC_LITERAL(1119, 4),  // "Left"
        QT_MOC_LITERAL(1124, 3),  // "Top"
        QT_MOC_LITERAL(1128, 5),  // "Right"
        QT_MOC_LITERAL(1134, 6),  // "Bottom"
        QT_MOC_LITERAL(1141, 11),  // "WindowEdges"
        QT_MOC_LITERAL(1153, 12),  // "DpiAwareness"
        QT_MOC_LITERAL(1166, 7),  // "Unaware"
        QT_MOC_LITERAL(1174, 6),  // "System"
        QT_MOC_LITERAL(1181, 10),  // "PerMonitor"
        QT_MOC_LITERAL(1192, 18),  // "PerMonitorVersion2"
        QT_MOC_LITERAL(1211, 17),  // "Unaware_GdiScaled"
        QT_MOC_LITERAL(1229, 17),  // "WindowCornerStyle"
        QT_MOC_LITERAL(1247, 6),  // "Square"
        QT_MOC_LITERAL(1254, 5)   // "Round"
    },
    "wangwenx190::FramelessHelper::Global",
    "Option",
    "UseCrossPlatformQtImplementation",
    "ForceHideWindowFrameBorder",
    "ForceShowWindowFrameBorder",
    "DisableWindowsSnapLayout",
    "WindowUseRoundCorners",
    "CenterWindowBeforeShow",
    "EnableBlurBehindWindow",
    "ForceNonNativeBackgroundBlur",
    "DisableLazyInitializationForMicaMaterial",
    "ForceNativeBackgroundBlur",
    "SystemTheme",
    "Unknown",
    "Light",
    "Dark",
    "HighContrast",
    "SystemButtonType",
    "WindowIcon",
    "Help",
    "Minimize",
    "Maximize",
    "Restore",
    "Close",
    "DwmColorizationArea",
    "None",
    "StartMenu_TaskBar_ActionCenter",
    "TitleBar_WindowBorder",
    "All",
    "ButtonState",
    "Normal",
    "Hovered",
    "Pressed",
    "Released",
    "WindowsVersion",
    "_2000",
    "_XP",
    "_XP_64",
    "_Vista",
    "_Vista_SP1",
    "_Vista_SP2",
    "_7",
    "_7_SP1",
    "_8",
    "_8_1",
    "_8_1_Update1",
    "_10_1507",
    "_10_1511",
    "_10_1607",
    "_10_1703",
    "_10_1709",
    "_10_1803",
    "_10_1809",
    "_10_1903",
    "_10_1909",
    "_10_2004",
    "_10_20H2",
    "_10_21H1",
    "_10_21H2",
    "_10_22H2",
    "_11_21H2",
    "_11_22H2",
    "_WS_03",
    "_10",
    "_11",
    "Latest",
    "BlurMode",
    "Disable",
    "Default",
    "Windows_Aero",
    "Windows_Acrylic",
    "Windows_Mica",
    "Windows_MicaAlt",
    "WallpaperAspectStyle",
    "Fill",
    "Fit",
    "Stretch",
    "Tile",
    "Center",
    "Span",
    "RegistryRootKey",
    "ClassesRoot",
    "CurrentUser",
    "LocalMachine",
    "Users",
    "PerformanceData",
    "CurrentConfig",
    "DynData",
    "CurrentUserLocalSettings",
    "PerformanceText",
    "PerformanceNlsText",
    "WindowEdge",
    "Left",
    "Top",
    "Right",
    "Bottom",
    "WindowEdges",
    "DpiAwareness",
    "Unaware",
    "System",
    "PerMonitor",
    "PerMonitorVersion2",
    "Unaware_GdiScaled",
    "WindowCornerStyle",
    "Square",
    "Round"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEGlobalENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
      13,   14, // enums/sets
       0,    0, // constructors
       4,       // flags
       0,       // signalCount

 // enums: name, alias, flags, count, data
       1,    1, 0x2,   10,   79,
      12,   12, 0x2,    4,   99,
      17,   17, 0x2,    7,  107,
      24,   24, 0x2,    4,  121,
      29,   29, 0x2,    4,  129,
      34,   34, 0x2,   31,  137,
      66,   66, 0x2,    6,  199,
      73,   73, 0x2,    6,  211,
      80,   80, 0x2,   10,  223,
      91,   91, 0x2,    4,  243,
      96,   91, 0x3,    4,  251,
      97,   97, 0x2,    6,  259,
     103,  103, 0x2,    3,  271,

 // enum data: key, value
       2, uint(wangwenx190::FramelessHelper::Global::Option::UseCrossPlatformQtImplementation),
       3, uint(wangwenx190::FramelessHelper::Global::Option::ForceHideWindowFrameBorder),
       4, uint(wangwenx190::FramelessHelper::Global::Option::ForceShowWindowFrameBorder),
       5, uint(wangwenx190::FramelessHelper::Global::Option::DisableWindowsSnapLayout),
       6, uint(wangwenx190::FramelessHelper::Global::Option::WindowUseRoundCorners),
       7, uint(wangwenx190::FramelessHelper::Global::Option::CenterWindowBeforeShow),
       8, uint(wangwenx190::FramelessHelper::Global::Option::EnableBlurBehindWindow),
       9, uint(wangwenx190::FramelessHelper::Global::Option::ForceNonNativeBackgroundBlur),
      10, uint(wangwenx190::FramelessHelper::Global::Option::DisableLazyInitializationForMicaMaterial),
      11, uint(wangwenx190::FramelessHelper::Global::Option::ForceNativeBackgroundBlur),
      13, uint(wangwenx190::FramelessHelper::Global::SystemTheme::Unknown),
      14, uint(wangwenx190::FramelessHelper::Global::SystemTheme::Light),
      15, uint(wangwenx190::FramelessHelper::Global::SystemTheme::Dark),
      16, uint(wangwenx190::FramelessHelper::Global::SystemTheme::HighContrast),
      13, uint(wangwenx190::FramelessHelper::Global::SystemButtonType::Unknown),
      18, uint(wangwenx190::FramelessHelper::Global::SystemButtonType::WindowIcon),
      19, uint(wangwenx190::FramelessHelper::Global::SystemButtonType::Help),
      20, uint(wangwenx190::FramelessHelper::Global::SystemButtonType::Minimize),
      21, uint(wangwenx190::FramelessHelper::Global::SystemButtonType::Maximize),
      22, uint(wangwenx190::FramelessHelper::Global::SystemButtonType::Restore),
      23, uint(wangwenx190::FramelessHelper::Global::SystemButtonType::Close),
      25, uint(wangwenx190::FramelessHelper::Global::DwmColorizationArea::None),
      26, uint(wangwenx190::FramelessHelper::Global::DwmColorizationArea::StartMenu_TaskBar_ActionCenter),
      27, uint(wangwenx190::FramelessHelper::Global::DwmColorizationArea::TitleBar_WindowBorder),
      28, uint(wangwenx190::FramelessHelper::Global::DwmColorizationArea::All),
      30, uint(wangwenx190::FramelessHelper::Global::ButtonState::Normal),
      31, uint(wangwenx190::FramelessHelper::Global::ButtonState::Hovered),
      32, uint(wangwenx190::FramelessHelper::Global::ButtonState::Pressed),
      33, uint(wangwenx190::FramelessHelper::Global::ButtonState::Released),
      35, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_2000),
      36, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_XP),
      37, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_XP_64),
      38, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_Vista),
      39, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_Vista_SP1),
      40, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_Vista_SP2),
      41, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_7),
      42, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_7_SP1),
      43, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_8),
      44, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_8_1),
      45, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_8_1_Update1),
      46, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_10_1507),
      47, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_10_1511),
      48, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_10_1607),
      49, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_10_1703),
      50, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_10_1709),
      51, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_10_1803),
      52, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_10_1809),
      53, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_10_1903),
      54, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_10_1909),
      55, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_10_2004),
      56, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_10_20H2),
      57, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_10_21H1),
      58, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_10_21H2),
      59, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_10_22H2),
      60, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_11_21H2),
      61, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_11_22H2),
      62, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_WS_03),
      63, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_10),
      64, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::_11),
      65, uint(wangwenx190::FramelessHelper::Global::WindowsVersion::Latest),
      67, uint(wangwenx190::FramelessHelper::Global::BlurMode::Disable),
      68, uint(wangwenx190::FramelessHelper::Global::BlurMode::Default),
      69, uint(wangwenx190::FramelessHelper::Global::BlurMode::Windows_Aero),
      70, uint(wangwenx190::FramelessHelper::Global::BlurMode::Windows_Acrylic),
      71, uint(wangwenx190::FramelessHelper::Global::BlurMode::Windows_Mica),
      72, uint(wangwenx190::FramelessHelper::Global::BlurMode::Windows_MicaAlt),
      74, uint(wangwenx190::FramelessHelper::Global::WallpaperAspectStyle::Fill),
      75, uint(wangwenx190::FramelessHelper::Global::WallpaperAspectStyle::Fit),
      76, uint(wangwenx190::FramelessHelper::Global::WallpaperAspectStyle::Stretch),
      77, uint(wangwenx190::FramelessHelper::Global::WallpaperAspectStyle::Tile),
      78, uint(wangwenx190::FramelessHelper::Global::WallpaperAspectStyle::Center),
      79, uint(wangwenx190::FramelessHelper::Global::WallpaperAspectStyle::Span),
      81, uint(wangwenx190::FramelessHelper::Global::RegistryRootKey::ClassesRoot),
      82, uint(wangwenx190::FramelessHelper::Global::RegistryRootKey::CurrentUser),
      83, uint(wangwenx190::FramelessHelper::Global::RegistryRootKey::LocalMachine),
      84, uint(wangwenx190::FramelessHelper::Global::RegistryRootKey::Users),
      85, uint(wangwenx190::FramelessHelper::Global::RegistryRootKey::PerformanceData),
      86, uint(wangwenx190::FramelessHelper::Global::RegistryRootKey::CurrentConfig),
      87, uint(wangwenx190::FramelessHelper::Global::RegistryRootKey::DynData),
      88, uint(wangwenx190::FramelessHelper::Global::RegistryRootKey::CurrentUserLocalSettings),
      89, uint(wangwenx190::FramelessHelper::Global::RegistryRootKey::PerformanceText),
      90, uint(wangwenx190::FramelessHelper::Global::RegistryRootKey::PerformanceNlsText),
      92, uint(wangwenx190::FramelessHelper::Global::WindowEdge::Left),
      93, uint(wangwenx190::FramelessHelper::Global::WindowEdge::Top),
      94, uint(wangwenx190::FramelessHelper::Global::WindowEdge::Right),
      95, uint(wangwenx190::FramelessHelper::Global::WindowEdge::Bottom),
      92, uint(wangwenx190::FramelessHelper::Global::WindowEdge::Left),
      93, uint(wangwenx190::FramelessHelper::Global::WindowEdge::Top),
      94, uint(wangwenx190::FramelessHelper::Global::WindowEdge::Right),
      95, uint(wangwenx190::FramelessHelper::Global::WindowEdge::Bottom),
      13, uint(wangwenx190::FramelessHelper::Global::DpiAwareness::Unknown),
      98, uint(wangwenx190::FramelessHelper::Global::DpiAwareness::Unaware),
      99, uint(wangwenx190::FramelessHelper::Global::DpiAwareness::System),
     100, uint(wangwenx190::FramelessHelper::Global::DpiAwareness::PerMonitor),
     101, uint(wangwenx190::FramelessHelper::Global::DpiAwareness::PerMonitorVersion2),
     102, uint(wangwenx190::FramelessHelper::Global::DpiAwareness::Unaware_GdiScaled),
      68, uint(wangwenx190::FramelessHelper::Global::WindowCornerStyle::Default),
     104, uint(wangwenx190::FramelessHelper::Global::WindowCornerStyle::Square),
     105, uint(wangwenx190::FramelessHelper::Global::WindowCornerStyle::Round),

       0        // eod
};

Q_CONSTINIT const QMetaObject wangwenx190::FramelessHelper::Global::staticMetaObject = { {
    nullptr,
    qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEGlobalENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEGlobalENDCLASS,
    nullptr,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEGlobalENDCLASS_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<void, std::true_type>
    >,
    nullptr
} };

QT_WARNING_POP
