/****************************************************************************
** Meta object code from reading C++ file 'micamaterial.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../framelesshelper-2.3.6/include/FramelessHelper/Core/micamaterial.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'micamaterial.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS = QtMocHelpers::stringData(
    "wangwenx190::FramelessHelper::MicaMaterial",
    "tintColorChanged",
    "",
    "tintOpacityChanged",
    "noiseOpacityChanged",
    "shouldRedraw",
    "paint",
    "QPainter*",
    "painter",
    "size",
    "pos",
    "tintColor",
    "tintOpacity",
    "noiseOpacity"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS_t {
    uint offsetsAndSizes[28];
    char stringdata0[43];
    char stringdata1[17];
    char stringdata2[1];
    char stringdata3[19];
    char stringdata4[20];
    char stringdata5[13];
    char stringdata6[6];
    char stringdata7[10];
    char stringdata8[8];
    char stringdata9[5];
    char stringdata10[4];
    char stringdata11[10];
    char stringdata12[12];
    char stringdata13[13];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS_t qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS = {
    {
        QT_MOC_LITERAL(0, 42),  // "wangwenx190::FramelessHelper:..."
        QT_MOC_LITERAL(43, 16),  // "tintColorChanged"
        QT_MOC_LITERAL(60, 0),  // ""
        QT_MOC_LITERAL(61, 18),  // "tintOpacityChanged"
        QT_MOC_LITERAL(80, 19),  // "noiseOpacityChanged"
        QT_MOC_LITERAL(100, 12),  // "shouldRedraw"
        QT_MOC_LITERAL(113, 5),  // "paint"
        QT_MOC_LITERAL(119, 9),  // "QPainter*"
        QT_MOC_LITERAL(129, 7),  // "painter"
        QT_MOC_LITERAL(137, 4),  // "size"
        QT_MOC_LITERAL(142, 3),  // "pos"
        QT_MOC_LITERAL(146, 9),  // "tintColor"
        QT_MOC_LITERAL(156, 11),  // "tintOpacity"
        QT_MOC_LITERAL(168, 12)   // "noiseOpacity"
    },
    "wangwenx190::FramelessHelper::MicaMaterial",
    "tintColorChanged",
    "",
    "tintOpacityChanged",
    "noiseOpacityChanged",
    "shouldRedraw",
    "paint",
    "QPainter*",
    "painter",
    "size",
    "pos",
    "tintColor",
    "tintOpacity",
    "noiseOpacity"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       3,   55, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   44,    2, 0x06,    4 /* Public */,
       3,    0,   45,    2, 0x06,    5 /* Public */,
       4,    0,   46,    2, 0x06,    6 /* Public */,
       5,    0,   47,    2, 0x06,    7 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       6,    3,   48,    2, 0x0a,    8 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 7, QMetaType::QSize, QMetaType::QPoint,    8,    9,   10,

 // properties: name, type, flags
      11, QMetaType::QColor, 0x00015903, uint(0), 0,
      12, QMetaType::QReal, 0x00015903, uint(1), 0,
      13, QMetaType::QReal, 0x00015903, uint(2), 0,

       0        // eod
};

Q_CONSTINIT const QMetaObject wangwenx190::FramelessHelper::MicaMaterial::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS_t,
        // property 'tintColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'tintOpacity'
        QtPrivate::TypeAndForceComplete<qreal, std::true_type>,
        // property 'noiseOpacity'
        QtPrivate::TypeAndForceComplete<qreal, std::true_type>,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<MicaMaterial, std::true_type>,
        // method 'tintColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'tintOpacityChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'noiseOpacityChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'shouldRedraw'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'paint'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPainter *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QSize &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QPoint &, std::false_type>
    >,
    nullptr
} };

void wangwenx190::FramelessHelper::MicaMaterial::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MicaMaterial *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->tintColorChanged(); break;
        case 1: _t->tintOpacityChanged(); break;
        case 2: _t->noiseOpacityChanged(); break;
        case 3: _t->shouldRedraw(); break;
        case 4: _t->paint((*reinterpret_cast< std::add_pointer_t<QPainter*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QSize>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<QPoint>>(_a[3]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MicaMaterial::*)();
            if (_t _q_method = &MicaMaterial::tintColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (MicaMaterial::*)();
            if (_t _q_method = &MicaMaterial::tintOpacityChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (MicaMaterial::*)();
            if (_t _q_method = &MicaMaterial::noiseOpacityChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (MicaMaterial::*)();
            if (_t _q_method = &MicaMaterial::shouldRedraw; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
    }else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<MicaMaterial *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QColor*>(_v) = _t->tintColor(); break;
        case 1: *reinterpret_cast< qreal*>(_v) = _t->tintOpacity(); break;
        case 2: *reinterpret_cast< qreal*>(_v) = _t->noiseOpacity(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<MicaMaterial *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setTintColor(*reinterpret_cast< QColor*>(_v)); break;
        case 1: _t->setTintOpacity(*reinterpret_cast< qreal*>(_v)); break;
        case 2: _t->setNoiseOpacity(*reinterpret_cast< qreal*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    } else if (_c == QMetaObject::BindableProperty) {
    }
}

const QMetaObject *wangwenx190::FramelessHelper::MicaMaterial::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *wangwenx190::FramelessHelper::MicaMaterial::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEMicaMaterialENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int wangwenx190::FramelessHelper::MicaMaterial::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 5)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 5;
    }else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 3;
    }
    return _id;
}

// SIGNAL 0
void wangwenx190::FramelessHelper::MicaMaterial::tintColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void wangwenx190::FramelessHelper::MicaMaterial::tintOpacityChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void wangwenx190::FramelessHelper::MicaMaterial::noiseOpacityChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void wangwenx190::FramelessHelper::MicaMaterial::shouldRedraw()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}
QT_WARNING_POP
