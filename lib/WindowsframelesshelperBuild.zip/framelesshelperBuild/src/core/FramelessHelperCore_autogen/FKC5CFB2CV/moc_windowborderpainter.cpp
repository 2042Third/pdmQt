/****************************************************************************
** Meta object code from reading C++ file 'windowborderpainter.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../framelesshelper-2.3.6/include/FramelessHelper/Core/windowborderpainter.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'windowborderpainter.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEWindowBorderPainterENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEWindowBorderPainterENDCLASS = QtMocHelpers::stringData(
    "wangwenx190::FramelessHelper::WindowBorderPainter",
    "thicknessChanged",
    "",
    "edgesChanged",
    "activeColorChanged",
    "inactiveColorChanged",
    "nativeBorderChanged",
    "shouldRepaint",
    "paint",
    "QPainter*",
    "painter",
    "size",
    "active",
    "setThickness",
    "value",
    "setEdges",
    "Global::WindowEdges",
    "setActiveColor",
    "setInactiveColor",
    "thickness",
    "edges",
    "activeColor",
    "inactiveColor",
    "nativeThickness",
    "nativeEdges",
    "nativeActiveColor",
    "nativeInactiveColor"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEWindowBorderPainterENDCLASS_t {
    uint offsetsAndSizes[54];
    char stringdata0[50];
    char stringdata1[17];
    char stringdata2[1];
    char stringdata3[13];
    char stringdata4[19];
    char stringdata5[21];
    char stringdata6[20];
    char stringdata7[14];
    char stringdata8[6];
    char stringdata9[10];
    char stringdata10[8];
    char stringdata11[5];
    char stringdata12[7];
    char stringdata13[13];
    char stringdata14[6];
    char stringdata15[9];
    char stringdata16[20];
    char stringdata17[15];
    char stringdata18[17];
    char stringdata19[10];
    char stringdata20[6];
    char stringdata21[12];
    char stringdata22[14];
    char stringdata23[16];
    char stringdata24[12];
    char stringdata25[18];
    char stringdata26[20];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEWindowBorderPainterENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEWindowBorderPainterENDCLASS_t qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEWindowBorderPainterENDCLASS = {
    {
        QT_MOC_LITERAL(0, 49),  // "wangwenx190::FramelessHelper:..."
        QT_MOC_LITERAL(50, 16),  // "thicknessChanged"
        QT_MOC_LITERAL(67, 0),  // ""
        QT_MOC_LITERAL(68, 12),  // "edgesChanged"
        QT_MOC_LITERAL(81, 18),  // "activeColorChanged"
        QT_MOC_LITERAL(100, 20),  // "inactiveColorChanged"
        QT_MOC_LITERAL(121, 19),  // "nativeBorderChanged"
        QT_MOC_LITERAL(141, 13),  // "shouldRepaint"
        QT_MOC_LITERAL(155, 5),  // "paint"
        QT_MOC_LITERAL(161, 9),  // "QPainter*"
        QT_MOC_LITERAL(171, 7),  // "painter"
        QT_MOC_LITERAL(179, 4),  // "size"
        QT_MOC_LITERAL(184, 6),  // "active"
        QT_MOC_LITERAL(191, 12),  // "setThickness"
        QT_MOC_LITERAL(204, 5),  // "value"
        QT_MOC_LITERAL(210, 8),  // "setEdges"
        QT_MOC_LITERAL(219, 19),  // "Global::WindowEdges"
        QT_MOC_LITERAL(239, 14),  // "setActiveColor"
        QT_MOC_LITERAL(254, 16),  // "setInactiveColor"
        QT_MOC_LITERAL(271, 9),  // "thickness"
        QT_MOC_LITERAL(281, 5),  // "edges"
        QT_MOC_LITERAL(287, 11),  // "activeColor"
        QT_MOC_LITERAL(299, 13),  // "inactiveColor"
        QT_MOC_LITERAL(313, 15),  // "nativeThickness"
        QT_MOC_LITERAL(329, 11),  // "nativeEdges"
        QT_MOC_LITERAL(341, 17),  // "nativeActiveColor"
        QT_MOC_LITERAL(359, 19)   // "nativeInactiveColor"
    },
    "wangwenx190::FramelessHelper::WindowBorderPainter",
    "thicknessChanged",
    "",
    "edgesChanged",
    "activeColorChanged",
    "inactiveColorChanged",
    "nativeBorderChanged",
    "shouldRepaint",
    "paint",
    "QPainter*",
    "painter",
    "size",
    "active",
    "setThickness",
    "value",
    "setEdges",
    "Global::WindowEdges",
    "setActiveColor",
    "setInactiveColor",
    "thickness",
    "edges",
    "activeColor",
    "inactiveColor",
    "nativeThickness",
    "nativeEdges",
    "nativeActiveColor",
    "nativeInactiveColor"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEWindowBorderPainterENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       8,  105, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   80,    2, 0x06,    9 /* Public */,
       3,    0,   81,    2, 0x06,   10 /* Public */,
       4,    0,   82,    2, 0x06,   11 /* Public */,
       5,    0,   83,    2, 0x06,   12 /* Public */,
       6,    0,   84,    2, 0x06,   13 /* Public */,
       7,    0,   85,    2, 0x06,   14 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       8,    3,   86,    2, 0x10a,   15 /* Public | MethodIsConst  */,
      13,    1,   93,    2, 0x0a,   19 /* Public */,
      15,    1,   96,    2, 0x0a,   21 /* Public */,
      17,    1,   99,    2, 0x0a,   23 /* Public */,
      18,    1,  102,    2, 0x0a,   25 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 9, QMetaType::QSize, QMetaType::Bool,   10,   11,   12,
    QMetaType::Void, QMetaType::Int,   14,
    QMetaType::Void, 0x80000000 | 16,   14,
    QMetaType::Void, QMetaType::QColor,   14,
    QMetaType::Void, QMetaType::QColor,   14,

 // properties: name, type, flags
      19, QMetaType::Int, 0x00015903, uint(0), 0,
      20, 0x80000000 | 16, 0x0001590b, uint(1), 0,
      21, QMetaType::QColor, 0x00015903, uint(2), 0,
      22, QMetaType::QColor, 0x00015903, uint(3), 0,
      23, QMetaType::Int, 0x00015801, uint(4), 0,
      24, 0x80000000 | 16, 0x00015809, uint(4), 0,
      25, QMetaType::QColor, 0x00015801, uint(4), 0,
      26, QMetaType::QColor, 0x00015801, uint(4), 0,

       0        // eod
};

Q_CONSTINIT static const QMetaObject::SuperData qt_meta_extradata_CLASSwangwenx190SCOPEFramelessHelperSCOPEWindowBorderPainterENDCLASS[] = {
    QMetaObject::SuperData::link<wangwenx190::FramelessHelper::Global::staticMetaObject>(),
    nullptr
};

Q_CONSTINIT const QMetaObject wangwenx190::FramelessHelper::WindowBorderPainter::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEWindowBorderPainterENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEWindowBorderPainterENDCLASS,
    qt_static_metacall,
    qt_meta_extradata_CLASSwangwenx190SCOPEFramelessHelperSCOPEWindowBorderPainterENDCLASS,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEWindowBorderPainterENDCLASS_t,
        // property 'thickness'
        QtPrivate::TypeAndForceComplete<int, std::true_type>,
        // property 'edges'
        QtPrivate::TypeAndForceComplete<Global::WindowEdges, std::true_type>,
        // property 'activeColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'inactiveColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'nativeThickness'
        QtPrivate::TypeAndForceComplete<int, std::true_type>,
        // property 'nativeEdges'
        QtPrivate::TypeAndForceComplete<Global::WindowEdges, std::true_type>,
        // property 'nativeActiveColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'nativeInactiveColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<WindowBorderPainter, std::true_type>,
        // method 'thicknessChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'edgesChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'activeColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'inactiveColorChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'nativeBorderChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'shouldRepaint'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'paint'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QPainter *, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QSize &, std::false_type>,
        QtPrivate::TypeAndForceComplete<const bool, std::false_type>,
        // method 'setThickness'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const int, std::false_type>,
        // method 'setEdges'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const Global::WindowEdges, std::false_type>,
        // method 'setActiveColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QColor &, std::false_type>,
        // method 'setInactiveColor'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const QColor &, std::false_type>
    >,
    nullptr
} };

void wangwenx190::FramelessHelper::WindowBorderPainter::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<WindowBorderPainter *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->thicknessChanged(); break;
        case 1: _t->edgesChanged(); break;
        case 2: _t->activeColorChanged(); break;
        case 3: _t->inactiveColorChanged(); break;
        case 4: _t->nativeBorderChanged(); break;
        case 5: _t->shouldRepaint(); break;
        case 6: _t->paint((*reinterpret_cast< std::add_pointer_t<QPainter*>>(_a[1])),(*reinterpret_cast< std::add_pointer_t<QSize>>(_a[2])),(*reinterpret_cast< std::add_pointer_t<bool>>(_a[3]))); break;
        case 7: _t->setThickness((*reinterpret_cast< std::add_pointer_t<int>>(_a[1]))); break;
        case 8: _t->setEdges((*reinterpret_cast< std::add_pointer_t<Global::WindowEdges>>(_a[1]))); break;
        case 9: _t->setActiveColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        case 10: _t->setInactiveColor((*reinterpret_cast< std::add_pointer_t<QColor>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (WindowBorderPainter::*)();
            if (_t _q_method = &WindowBorderPainter::thicknessChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (WindowBorderPainter::*)();
            if (_t _q_method = &WindowBorderPainter::edgesChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (WindowBorderPainter::*)();
            if (_t _q_method = &WindowBorderPainter::activeColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (WindowBorderPainter::*)();
            if (_t _q_method = &WindowBorderPainter::inactiveColorChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (WindowBorderPainter::*)();
            if (_t _q_method = &WindowBorderPainter::nativeBorderChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (WindowBorderPainter::*)();
            if (_t _q_method = &WindowBorderPainter::shouldRepaint; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 5;
                return;
            }
        }
    }else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<WindowBorderPainter *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< int*>(_v) = _t->thickness(); break;
        case 1: *reinterpret_cast< Global::WindowEdges*>(_v) = _t->edges(); break;
        case 2: *reinterpret_cast< QColor*>(_v) = _t->activeColor(); break;
        case 3: *reinterpret_cast< QColor*>(_v) = _t->inactiveColor(); break;
        case 4: *reinterpret_cast< int*>(_v) = _t->nativeThickness(); break;
        case 5: *reinterpret_cast< Global::WindowEdges*>(_v) = _t->nativeEdges(); break;
        case 6: *reinterpret_cast< QColor*>(_v) = _t->nativeActiveColor(); break;
        case 7: *reinterpret_cast< QColor*>(_v) = _t->nativeInactiveColor(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<WindowBorderPainter *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setThickness(*reinterpret_cast< int*>(_v)); break;
        case 1: _t->setEdges(*reinterpret_cast< Global::WindowEdges*>(_v)); break;
        case 2: _t->setActiveColor(*reinterpret_cast< QColor*>(_v)); break;
        case 3: _t->setInactiveColor(*reinterpret_cast< QColor*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    } else if (_c == QMetaObject::BindableProperty) {
    }
}

const QMetaObject *wangwenx190::FramelessHelper::WindowBorderPainter::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *wangwenx190::FramelessHelper::WindowBorderPainter::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEWindowBorderPainterENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int wangwenx190::FramelessHelper::WindowBorderPainter::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 11;
    }else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    }
    return _id;
}

// SIGNAL 0
void wangwenx190::FramelessHelper::WindowBorderPainter::thicknessChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void wangwenx190::FramelessHelper::WindowBorderPainter::edgesChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void wangwenx190::FramelessHelper::WindowBorderPainter::activeColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void wangwenx190::FramelessHelper::WindowBorderPainter::inactiveColorChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, nullptr);
}

// SIGNAL 4
void wangwenx190::FramelessHelper::WindowBorderPainter::nativeBorderChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void wangwenx190::FramelessHelper::WindowBorderPainter::shouldRepaint()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}
QT_WARNING_POP
