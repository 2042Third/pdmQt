/****************************************************************************
** Meta object code from reading C++ file 'framelessmanager.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.5.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../../framelesshelper-2.3.6/include/FramelessHelper/Core/framelessmanager.h"
#include <QtCore/qmetatype.h>

#if __has_include(<QtCore/qtmochelpers.h>)
#include <QtCore/qtmochelpers.h>
#else
QT_BEGIN_MOC_NAMESPACE
#endif


#include <memory>

#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'framelessmanager.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.5.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
QT_WARNING_DISABLE_GCC("-Wuseless-cast")
namespace {

#ifdef QT_MOC_HAS_STRINGDATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessManagerENDCLASS_t {};
static constexpr auto qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessManagerENDCLASS = QtMocHelpers::stringData(
    "wangwenx190::FramelessHelper::FramelessManager",
    "systemThemeChanged",
    "",
    "wallpaperChanged",
    "addWindow",
    "const SystemParameters*",
    "params",
    "removeWindow",
    "WId",
    "windowId",
    "systemTheme",
    "Global::SystemTheme",
    "systemAccentColor",
    "wallpaper",
    "wallpaperAspectStyle",
    "Global::WallpaperAspectStyle"
);
#else  // !QT_MOC_HAS_STRING_DATA
struct qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessManagerENDCLASS_t {
    uint offsetsAndSizes[32];
    char stringdata0[47];
    char stringdata1[19];
    char stringdata2[1];
    char stringdata3[17];
    char stringdata4[10];
    char stringdata5[24];
    char stringdata6[7];
    char stringdata7[13];
    char stringdata8[4];
    char stringdata9[9];
    char stringdata10[12];
    char stringdata11[20];
    char stringdata12[18];
    char stringdata13[10];
    char stringdata14[21];
    char stringdata15[29];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessManagerENDCLASS_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessManagerENDCLASS_t qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessManagerENDCLASS = {
    {
        QT_MOC_LITERAL(0, 46),  // "wangwenx190::FramelessHelper:..."
        QT_MOC_LITERAL(47, 18),  // "systemThemeChanged"
        QT_MOC_LITERAL(66, 0),  // ""
        QT_MOC_LITERAL(67, 16),  // "wallpaperChanged"
        QT_MOC_LITERAL(84, 9),  // "addWindow"
        QT_MOC_LITERAL(94, 23),  // "const SystemParameters*"
        QT_MOC_LITERAL(118, 6),  // "params"
        QT_MOC_LITERAL(125, 12),  // "removeWindow"
        QT_MOC_LITERAL(138, 3),  // "WId"
        QT_MOC_LITERAL(142, 8),  // "windowId"
        QT_MOC_LITERAL(151, 11),  // "systemTheme"
        QT_MOC_LITERAL(163, 19),  // "Global::SystemTheme"
        QT_MOC_LITERAL(183, 17),  // "systemAccentColor"
        QT_MOC_LITERAL(201, 9),  // "wallpaper"
        QT_MOC_LITERAL(211, 20),  // "wallpaperAspectStyle"
        QT_MOC_LITERAL(232, 28)   // "Global::WallpaperAspectStyle"
    },
    "wangwenx190::FramelessHelper::FramelessManager",
    "systemThemeChanged",
    "",
    "wallpaperChanged",
    "addWindow",
    "const SystemParameters*",
    "params",
    "removeWindow",
    "WId",
    "windowId",
    "systemTheme",
    "Global::SystemTheme",
    "systemAccentColor",
    "wallpaper",
    "wallpaperAspectStyle",
    "Global::WallpaperAspectStyle"
};
#undef QT_MOC_LITERAL
#endif // !QT_MOC_HAS_STRING_DATA
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessManagerENDCLASS[] = {

 // content:
      11,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       4,   46, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   38,    2, 0x06,    5 /* Public */,
       3,    0,   39,    2, 0x06,    6 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       4,    1,   40,    2, 0x0a,    7 /* Public */,
       7,    1,   43,    2, 0x0a,    9 /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 5,    6,
    QMetaType::Void, 0x80000000 | 8,    9,

 // properties: name, type, flags
      10, 0x80000000 | 11, 0x00015809, uint(0), 0,
      12, QMetaType::QColor, 0x00015801, uint(0), 0,
      13, QMetaType::QString, 0x00015801, uint(1), 0,
      14, 0x80000000 | 15, 0x00015809, uint(1), 0,

       0        // eod
};

Q_CONSTINIT static const QMetaObject::SuperData qt_meta_extradata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessManagerENDCLASS[] = {
    QMetaObject::SuperData::link<wangwenx190::FramelessHelper::Global::staticMetaObject>(),
    nullptr
};

Q_CONSTINIT const QMetaObject wangwenx190::FramelessHelper::FramelessManager::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessManagerENDCLASS.offsetsAndSizes,
    qt_meta_data_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessManagerENDCLASS,
    qt_static_metacall,
    qt_meta_extradata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessManagerENDCLASS,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessManagerENDCLASS_t,
        // property 'systemTheme'
        QtPrivate::TypeAndForceComplete<Global::SystemTheme, std::true_type>,
        // property 'systemAccentColor'
        QtPrivate::TypeAndForceComplete<QColor, std::true_type>,
        // property 'wallpaper'
        QtPrivate::TypeAndForceComplete<QString, std::true_type>,
        // property 'wallpaperAspectStyle'
        QtPrivate::TypeAndForceComplete<Global::WallpaperAspectStyle, std::true_type>,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<FramelessManager, std::true_type>,
        // method 'systemThemeChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'wallpaperChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        // method 'addWindow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const SystemParameters *, std::false_type>,
        // method 'removeWindow'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<const WId, std::false_type>
    >,
    nullptr
} };

void wangwenx190::FramelessHelper::FramelessManager::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<FramelessManager *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->systemThemeChanged(); break;
        case 1: _t->wallpaperChanged(); break;
        case 2: _t->addWindow((*reinterpret_cast< std::add_pointer_t<const SystemParameters*>>(_a[1]))); break;
        case 3: _t->removeWindow((*reinterpret_cast< std::add_pointer_t<WId>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (FramelessManager::*)();
            if (_t _q_method = &FramelessManager::systemThemeChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (FramelessManager::*)();
            if (_t _q_method = &FramelessManager::wallpaperChanged; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
    }else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<FramelessManager *>(_o);
        (void)_t;
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< Global::SystemTheme*>(_v) = _t->systemTheme(); break;
        case 1: *reinterpret_cast< QColor*>(_v) = _t->systemAccentColor(); break;
        case 2: *reinterpret_cast< QString*>(_v) = _t->wallpaper(); break;
        case 3: *reinterpret_cast< Global::WallpaperAspectStyle*>(_v) = _t->wallpaperAspectStyle(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
    } else if (_c == QMetaObject::ResetProperty) {
    } else if (_c == QMetaObject::BindableProperty) {
    }
}

const QMetaObject *wangwenx190::FramelessHelper::FramelessManager::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *wangwenx190::FramelessHelper::FramelessManager::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CLASSwangwenx190SCOPEFramelessHelperSCOPEFramelessManagerENDCLASS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int wangwenx190::FramelessHelper::FramelessManager::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 4)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 4;
    }else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::BindableProperty
            || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    }
    return _id;
}

// SIGNAL 0
void wangwenx190::FramelessHelper::FramelessManager::systemThemeChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void wangwenx190::FramelessHelper::FramelessManager::wallpaperChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}
QT_WARNING_POP
